window.MOMO_BUILD = {"version": "2026.10.15.0829", "updates": "https://raw.githubusercontent.com/victorguima12/momo-fit/main"};
