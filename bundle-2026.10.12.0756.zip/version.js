window.MOMO_BUILD = {"version": "2026.10.12.0756", "updates": "https://raw.githubusercontent.com/victorguima12/momo-fit/main"};
