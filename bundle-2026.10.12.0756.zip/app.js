const $ = (s) => document.querySelector(s);
const MEAL_NAMES = { cafe: "Café da manhã", almoco: "Almoço", lanche: "Lanches", jantar: "Jantar" };
const MEAL_ORDER = ["cafe", "almoco", "lanche", "jantar"];

const todayISO = () => {
  const d = new Date();
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 10);
};
let current = todayISO();
let S = null;            // último estado vindo do servidor
let photos = [];         // [{dataUrl, type}] da mensagem que está sendo escrita
const MAX_PHOTOS = 6;
let busy = false;
const localThumbs = {};  // ts -> [dataUrl] (só nesta sessão)

// toda a "API" roda dentro do app (backend.js): dados no aparelho, IA direto na OpenAI
const api = (path, opts = {}) => Backend.request(path, opts);

$("#appVersion").textContent = "Momo · versão " + (window.MOMO_BUILD?.version || "dev");
let firstLoad = true;
async function load() {
  render(await api(`/api/state?date=${current}`));
  if (firstLoad && S.user_missing.length && !sessionStorage.obLater) startOnboarding();
  firstLoad = false;
}

// ---------- render ----------

function fmtDay(iso) {
  const t = todayISO();
  const y = shift(t, -1);
  if (iso === t) return "Hoje";
  if (iso === y) return "Ontem";
  const d = new Date(iso + "T12:00");
  return d.toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "short" });
}
function shift(iso, n) {
  const d = new Date(iso + "T12:00");
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

function render(s) {
  S = s;
  $("#dayLabel").textContent = fmtDay(current);
  $("#daySub").textContent = current === todayISO() ? new Date().toLocaleDateString("pt-BR", { day: "numeric", month: "long" }) : "";
  $("#nextDay").style.visibility = current >= todayISO() ? "hidden" : "visible";

  const g = s.goals, t = s.totals;
  const left = g.kcal - t.kcal;
  $("#kcalLeft").textContent = Math.abs(left).toLocaleString("pt-BR");
  $("#kcalLeftLabel").textContent = left >= 0 ? "restantes" : "acima";
  $("#kcalEaten").textContent = t.kcal.toLocaleString("pt-BR");
  $("#kcalGoal").textContent = g.kcal.toLocaleString("pt-BR");
  $("#goalHint").classList.toggle("hidden", s.goals_source !== "default");
  const frac = Math.min(t.kcal / g.kcal, 1);
  const ring = $("#ringFg");
  ring.style.strokeDashoffset = 314.16 * (1 - frac);
  ring.classList.toggle("over", left < 0);
  for (const k of ["protein", "carbs", "fat"]) {
    const el = document.querySelector(`.macro[data-k=${k}]`);
    el.querySelector("i").style.width = Math.min(100, (t[k] / g[k]) * 100) + "%";
    el.querySelector("b").textContent = `${t[k]}/${g[k]}g`;
  }
  renderChat();
  renderDiary();
  renderCheckin();
  renderProfile();
  if ($("#viewProgress").classList.contains("active")) loadProgress();
}

function renderChat() {
  const box = $("#chat");
  const ids = new Set(S.entries.map((e) => e.id));
  const byId = Object.fromEntries(S.entries.map((e) => [e.id, e]));
  box.innerHTML = "";
  if (!S.chat.length && S.user_missing.length) {
    box.innerHTML = `<div class="msg momo">Oi! Eu sou o Momo 👋 Antes de tudo, me conta um pouco de você pra eu calcular suas metas:
sexo, idade, altura, peso, quanto você treina e se quer perder, manter ou ganhar peso.

Pode ser tudo numa frase só, tipo: <b>"homem, 30 anos, 1,78, 82 kg, treino 4x por semana, quero perder gordura"</b>.
Ou responde o <a href="#" onclick="startOnboarding();return false">questionário rápido</a>.</div>`;
    return;
  }
  if (!S.chat.length) {
    box.innerHTML = `<div class="empty">Me conta o que você comeu.<br><br>
      <b>"Comi 200g de sucrilhos com 100ml de leite"</b><br>
      <b>"O que eu janto pra bater a proteína?"</b><br>
      ou manda uma 📷 do prato/rótulo.</div>`;
    return;
  }
  let lastDay = null;
  for (const m of S.chat) {
    if (m.date !== lastDay) {
      lastDay = m.date;
      box.insertAdjacentHTML("beforeend", `<div class="day-sep">${fmtDay(m.date)}</div>`);
    }
    const div = document.createElement("div");
    div.className = "msg " + m.role;
    if (localThumbs[m.ts] && m.role === "user") {
      const row = document.createElement("div");
      row.className = "thumbs";
      for (const src of localThumbs[m.ts]) {
        const img = document.createElement("img");
        img.className = "thumb";
        img.src = src;
        row.appendChild(img);
      }
      div.appendChild(row);
    }
    div.appendChild(document.createTextNode(m.text));
    if (m.workout) {
      const c = document.createElement("button");
      c.className = "chip workout";
      c.innerHTML = `<span>🏋️ Treino ${esc(m.workout)} registrado</span><span class="k">ver ›</span>`;
      c.onclick = () => switchView("viewTraining");
      const wrap = document.createElement("div");
      wrap.className = "chips";
      wrap.appendChild(c);
      div.appendChild(wrap);
    }
    if (m.added && m.added.length) {
      const chips = document.createElement("div");
      chips.className = "chips";
      for (const id of m.added) {
        const e = byId[id];
        const c = document.createElement("div");
        if (e) {
          c.className = "chip editable";
          c.innerHTML = `<span>${esc(e.name)} <span class="muted">${esc(e.quantity)}</span></span><span class="k">${Math.round(e.kcal)} kcal ✎</span>`;
          c.onclick = () => openEntry(e);
        } else if (m.date === current) {
          c.className = "chip gone";
          c.textContent = "item removido";
        } else continue;
        chips.appendChild(c);
      }
      if (chips.children.length) div.appendChild(chips);
    }
    box.appendChild(div);
  }
  scrollChat();
}

function renderDiary() {
  const box = $("#diary");
  box.innerHTML = "";
  for (const w of S.workouts_today || []) {
    const card = document.createElement("button");
    card.className = "meal workout-card";
    card.innerHTML = `<h4>🏋️ Treino ${esc(w.treino)}<span>${w.series.length} ${w.series.length === 1 ? "exercício" : "exercícios"} ›</span></h4>
      <div class="none">${w.series.map(esc).join("<br>")}</div>`;
    card.onclick = () => switchView("viewTraining");
    box.appendChild(card);
  }
  for (const meal of MEAL_ORDER) {
    const items = S.entries.filter((e) => e.meal === meal);
    const kc = items.reduce((a, e) => a + (+e.kcal || 0), 0);
    const sec = document.createElement("div");
    sec.className = "meal";
    sec.innerHTML = `<h4>${MEAL_NAMES[meal]}<span>${Math.round(kc)} kcal</span></h4>`;
    if (!items.length) sec.insertAdjacentHTML("beforeend", `<div class="none">Nada ainda</div>`);
    for (const e of items) {
      const row = document.createElement("div");
      row.className = "item";
      row.innerHTML = `<div class="info"><div class="name">${esc(e.name)}</div>
        <div class="sub">${esc(e.quantity)} · P ${Math.round(e.protein)} · C ${Math.round(e.carbs)} · G ${Math.round(e.fat)}</div></div>
        <div class="kc">${Math.round(e.kcal)}</div><button class="del" aria-label="Apagar">✕</button>`;
      row.querySelector(".del").onclick = async (ev) => { ev.stopPropagation(); render(await api(`/api/entry/${current}/${e.id}`, { method: "DELETE" })); };
      row.onclick = () => openEntry(e);
      sec.appendChild(row);
    }
    box.appendChild(sec);
  }
}

// ---------- editar um item registrado ----------

const qtyNum = (q) => { const m = String(q || "").match(/\d+(?:[.,]\d+)?/); return m ? parseFloat(m[0].replace(",", ".")) : null; };
let editing = null;

function openEntry(e) {
  // o chat mostra itens de qualquer dia; o diário só do dia aberto
  const d = S.entries.some((x) => x.id === e.id) ? current : (S.chat.find((m) => m.added?.includes(e.id))?.date || current);
  editing = { e: { ...e }, d, baseQty: qtyNum(e.quantity), base: { kcal: e.kcal, protein: e.protein, carbs: e.carbs, fat: e.fat } };
  const f = $("#entryForm");
  f.elements.name.value = e.name;
  f.elements.quantity.value = e.quantity;
  f.elements.meal.value = e.meal;
  for (const k of ["kcal", "protein", "carbs", "fat"]) f.elements[k].value = Math.round(e[k] * 10) / 10;
  $("#entryHint").textContent = editing.baseQty ? "Mudou a quantidade? As calorias e macros acompanham." : "";
  $("#entryDlg").showModal();
}

$("#entryForm").elements.quantity.addEventListener("input", (ev) => {
  const n = qtyNum(ev.target.value), b = editing?.baseQty;
  if (!n || !b) return;
  const f = $("#entryForm"), k = n / b;
  for (const m of ["kcal", "protein", "carbs", "fat"]) f.elements[m].value = Math.round(editing.base[m] * k * 10) / 10;
  $("#entryHint").textContent = `Recalculado: ${Math.round(k * 100)}% da porção original.`;
});
$("#entryCancel").onclick = () => $("#entryDlg").close();
$("#entryDelete").onclick = async () => {
  $("#entryDlg").close();
  await api(`/api/entry/${editing.d}/${editing.e.id}`, { method: "DELETE" });
  load();
};
$("#entryForm").onsubmit = async (ev) => {
  ev.preventDefault();
  const f = ev.target, body = { name: f.elements.name.value.trim(), quantity: f.elements.quantity.value.trim(), meal: f.elements.meal.value };
  for (const k of ["kcal", "protein", "carbs", "fat"]) body[k] = parseFloat(String(f.elements[k].value).replace(",", ".")) || 0;
  $("#entryDlg").close();
  await api(`/api/entry/${editing.d}/${editing.e.id}`, { method: "PUT", body: JSON.stringify(body) });
  await load();
  toast(`${body.name}: ${Math.round(body.kcal)} kcal`);
};

function esc(s) {
  return String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}
function scrollChat() {
  const v = $("#viewChat");
  requestAnimationFrame(() => (v.scrollTop = v.scrollHeight));
}

// ---------- enviar ----------

async function send(textOverride) {
  const text = (textOverride ?? $("#input").value).trim();
  if (busy || (!text && !photos.length)) return;
  busy = true;
  $("#sendBtn").disabled = true;
  switchView("viewChat");

  // mostra a mensagem na hora
  const ts = new Date().toISOString().slice(0, 19);
  S.chat.push({ role: "user", text: text || (photos.length > 1 ? `📷 ${photos.length} fotos` : "📷 foto"), date: current, ts });
  if (photos.length) localThumbs[ts] = photos.map((p) => p.dataUrl);
  renderChat();
  const typing = document.createElement("div");
  typing.className = "msg momo typing";
  typing.textContent = photos.length ? (photos.length > 1 ? "analisando as fotos…" : "analisando a foto…") : "…";
  $("#chat").appendChild(typing);
  scrollChat();

  const body = { text, date: current };
  if (photos.length) body.images = photos.map((p) => p.dataUrl);
  $("#input").value = "";
  autoGrow();
  clearPhoto();
  try {
    const s = await api("/api/chat", { method: "POST", body: JSON.stringify(body) });
    // servidor grava o ts dele; mantém a thumb local na última msg do usuário
    const lastUser = [...s.chat].reverse().find((m) => m.role === "user");
    if (lastUser && localThumbs[ts]) localThumbs[lastUser.ts] = localThumbs[ts];
    render(s);
    if (s.chat[s.chat.length - 1]?.workout) Treino.invalidate();
  } catch (err) {
    typing.textContent = "Erro: " + err.message;
    typing.classList.remove("typing");
  } finally {
    busy = false;
    $("#sendBtn").disabled = false;
  }
}

// ---------- foto ----------

function clearPhoto() {
  photos = [];
  drawPhotos();
}

function drawPhotos() {
  const box = $("#photoPreview");
  box.classList.toggle("hidden", !photos.length);
  box.innerHTML = "";
  photos.forEach((p, i) => {
    const w = document.createElement("div");
    w.className = "pp";
    w.innerHTML = `<img src="${p.dataUrl}" alt=""><button aria-label="Remover foto">✕</button>`;
    w.querySelector("button").onclick = () => { photos.splice(i, 1); drawPhotos(); };
    box.appendChild(w);
  });
  if (photos.length && photos.length < MAX_PHOTOS) {
    const add = document.createElement("button");
    add.className = "pp add";
    add.textContent = "+";
    add.setAttribute("aria-label", "Adicionar outra foto");
    add.onclick = addChatPhotos;
    box.appendChild(add);
  }
}

// abre a escolha câmera/galeria e devolve os arquivos escolhidos
function pickPhotos(multiple = true) {
  return new Promise((resolve) => {
    const dlg = $("#pickDlg");
    const done = (files) => { dlg.close(); resolve(files); };
    const use = (inp) => {
      inp.multiple = multiple && inp.id === "galInput";
      inp.value = "";
      inp.onchange = () => resolve([...inp.files]);
      dlg.close();
      inp.click();
    };
    $("#pickCamera").onclick = () => use($("#camInput"));
    $("#pickGallery").onclick = () => use($("#galInput"));
    $("#pickCancel").onclick = () => done([]);
    dlg.onclick = (e) => { if (e.target === dlg) done([]); };
    dlg.showModal();
  });
}

async function addChatPhotos() {
  const files = await pickPhotos(true);
  for (const f of files.slice(0, MAX_PHOTOS - photos.length)) photos.push(await shrink(f, photos.length + files.length > 2 ? 1280 : 1600));
  if (files.length > MAX_PHOTOS) toast(`No máximo ${MAX_PHOTOS} fotos por mensagem`);
  drawPhotos();
  if (photos.length) $("#input").focus();
}
$("#camBtn").onclick = addChatPhotos;

function shrink(file, max) {
  return new Promise((res, rej) => {
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * k);
      c.height = Math.round(img.height * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(img.src);
      res({ dataUrl: c.toDataURL("image/jpeg", 0.85), type: "image/jpeg" });
    };
    img.onerror = rej;
    img.src = URL.createObjectURL(file);
  });
}

// ---------- microfone (só funciona em https ou localhost) ----------

let rec = null;
if (navigator.mediaDevices && window.MediaRecorder) {
  $("#micBtn").classList.remove("hidden");
  $("#micBtn").onclick = async () => {
    if (rec) return rec.stop();
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const chunks = [];
    rec = new MediaRecorder(stream);
    rec.ondataavailable = (e) => chunks.push(e.data);
    rec.onstop = async () => {
      stream.getTracks().forEach((t) => t.stop());
      rec = null;
      $("#micBtn").classList.remove("rec");
      const fd = new FormData();
      fd.append("file", new Blob(chunks, { type: "audio/webm" }), "fala.webm");
      $("#input").placeholder = "transcrevendo…";
      try {
        const { text } = await api("/api/transcribe", { method: "POST", body: fd });
        $("#input").placeholder = "";
        if (text) send(text);
      } catch (e) {
        alertMsg("Erro na transcrição: " + e.message);
      }
    };
    rec.start();
    $("#micBtn").classList.add("rec");
  };
}
function alertMsg(t) {
  $("#chat").insertAdjacentHTML("beforeend", `<div class="msg momo">${esc(t)}</div>`);
  scrollChat();
}

// ---------- UI ----------

function autoGrow() {
  const t = $("#input");
  t.style.height = "auto";
  t.style.height = Math.min(t.scrollHeight, 120) + "px";
}
$("#input").addEventListener("input", autoGrow);
$("#input").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey && !matchMedia("(pointer: coarse)").matches) {
    e.preventDefault();
    send();
  }
});
$("#sendBtn").onclick = () => send();

function switchView(id) {
  const full = id === "viewProgress" || id === "viewProfile" || id === "viewTraining";
  $("#summary").classList.toggle("hidden", full);
  $("#composer").classList.toggle("hidden", full);
  $(".top").classList.toggle("hidden", id === "viewTraining");
  if (id === "viewProgress") loadProgress();
  if (id === "viewTraining") Treino.show();
  document.querySelectorAll(".view").forEach((v) => v.classList.toggle("active", v.id === id));
  document.querySelectorAll(".tabs button").forEach((b) => b.classList.toggle("active", b.dataset.view === id));
  if (id === "viewChat") scrollChat();
}
document.querySelectorAll(".tabs button").forEach((b) => (b.onclick = () => switchView(b.dataset.view)));

$("#goalHint").onclick = () => switchView("viewProfile");
$("#prevDay").onclick = () => { current = shift(current, -1); load(); };
$("#nextDay").onclick = () => { if (current < todayISO()) { current = shift(current, 1); load(); } };


// ---------- progresso: peso e fotos do dia ----------

const fmtKg = (v) => (+v).toLocaleString("pt-BR", { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const fmtShort = (iso) => new Date(iso + "T12:00").toLocaleDateString("pt-BR", { day: "numeric", month: "short" });

function renderCheckin() {
  $("#checkinTitle").textContent = current === todayISO() ? "Check-in de hoje" : "Check-in · " + fmtDay(current);
  const inp = $("#weightInput");
  if (document.activeElement !== inp) inp.value = S.weight ?? "";
  inp.placeholder = S.user.weight_kg ? fmtKg(S.user.weight_kg) : "—";
  const strip = $("#dayPhotos");
  strip.innerHTML = "";
  for (const name of S.photos) {
    const img = document.createElement("img");
    img.src = Backend.photoURL(name);
    img.onclick = () => openPhoto(current, name);
    strip.appendChild(img);
  }
  const add = document.createElement("button");
  add.className = "add";
  add.innerHTML = "<b>+</b>foto do dia";
  add.onclick = addDayPhotos;
  strip.appendChild(add);
}

$("#saveWeight").onclick = async () => {
  const v = parseFloat($("#weightInput").value.replace(",", "."));
  render(await api(`/api/weight/${current}`, { method: "PUT", body: JSON.stringify({ weight: v || null }) }));
  toast(v ? `Peso salvo: ${fmtKg(v)} kg` : "Peso apagado");
};

async function addDayPhotos() {
  const files = await pickPhotos(true);
  let s = null;
  for (const f of files) {
    const p = await shrink(f, 1600);
    s = await api(`/api/photo/${current}`, { method: "POST", body: JSON.stringify({ image: p.dataUrl }) });
  }
  if (s) { render(s); toast(files.length > 1 ? `${files.length} fotos do dia salvas` : "Foto do dia salva"); }
}

let viewing = null;
function openPhoto(d, name) {
  viewing = { d, name };
  $("#photoBig").src = Backend.photoURL(name);
  $("#photoBigDate").textContent = fmtDay(d);
  $("#photoDlg").showModal();
}
$("#photoBigClose").onclick = () => $("#photoDlg").close();
$("#photoDel").onclick = async () => {
  if (!confirm("Apagar essa foto?")) return;
  const s = await api(`/api/photo/${viewing.d}/${viewing.name}`, { method: "DELETE" });
  $("#photoDlg").close();
  if (viewing.d === current) render(s);
  loadProgress();
};

async function loadProgress() {
  const { days } = await api("/api/progress");
  drawWeightChart(days.filter((d) => d.weight));
  const gal = $("#gallery");
  gal.innerHTML = "";
  const withPhotos = days.filter((d) => d.photos.length).reverse();
  if (!withPhotos.length) {
    gal.innerHTML = `<div class="chart-empty">Nenhuma foto ainda. Tira uma no espelho todo dia (ou toda semana) pra ver a evolução.</div>`;
  }
  for (const d of withPhotos) {
    const sec = document.createElement("div");
    sec.className = "gal-day";
    sec.innerHTML = `<div class="d"><b>${fmtDay(d.date)}</b>${d.weight ? " · " + fmtKg(d.weight) + " kg" : ""}</div><div class="gal-row"></div>`;
    for (const name of d.photos) {
      const img = document.createElement("img");
      img.src = Backend.photoURL(name);
      img.loading = "lazy";
      img.onclick = () => openPhoto(d.date, name);
      sec.querySelector(".gal-row").appendChild(img);
    }
    gal.appendChild(sec);
  }
}

function drawWeightChart(pts) {
  const box = $("#weightChart");
  const hero = $("#weightHero");
  box.innerHTML = "";
  hero.innerHTML = "";
  if (!pts.length) {
    box.innerHTML = `<div class="chart-empty">Registre seu peso pra ver o gráfico.</div>`;
    return;
  }
  const last = pts[pts.length - 1], first = pts[0];
  const delta = last.weight - first.weight;
  hero.innerHTML = `<b>${fmtKg(last.weight)}</b> kg` + (pts.length > 1
    ? `<div class="delta">${delta > 0 ? "+" : delta < 0 ? "−" : ""}${fmtKg(Math.abs(delta))} kg desde ${fmtShort(first.date)}</div>` : "");
  if (pts.length < 2) {
    box.innerHTML = `<div class="chart-empty">Com mais um dia de peso já aparece a linha.</div>`;
    return;
  }

  const W = box.clientWidth || 320, H = 170, L = 34, R = 10, T = 30, B = 22;
  const t = (iso) => new Date(iso + "T12:00").getTime();
  const x0 = t(first.date), x1 = t(last.date);
  const ws = pts.map((p) => p.weight);
  let lo = Math.min(...ws), hi = Math.max(...ws);
  const padY = Math.max(0.5, (hi - lo) * 0.15);
  lo = Math.floor((lo - padY) * 2) / 2;
  hi = Math.ceil((hi + padY) * 2) / 2;
  const X = (iso) => L + ((t(iso) - x0) / (x1 - x0 || 1)) * (W - L - R);
  const Y = (w) => T + (1 - (w - lo) / (hi - lo)) * (H - T - B);

  let g = "";
  for (let i = 0; i <= 3; i++) {
    const v = lo + ((hi - lo) * i) / 3, y = Y(v);
    g += `<line class="grid" x1="${L}" x2="${W - R}" y1="${y}" y2="${y}"/>
      <text class="axis" x="${L - 6}" y="${y + 3}" text-anchor="end">${v.toFixed(1).replace(".", ",")}</text>`;
  }
  g += `<text class="axis" x="${L}" y="${H - 6}">${fmtShort(first.date)}</text>
    <text class="axis" x="${W - R}" y="${H - 6}" text-anchor="end">${fmtShort(last.date)}</text>`;
  const path = pts.map((p, i) => `${i ? "L" : "M"}${X(p.date).toFixed(1)},${Y(p.weight).toFixed(1)}`).join("");
  const dots = pts.map((p) => `<circle class="pt" cx="${X(p.date)}" cy="${Y(p.weight)}" r="4"/>`).join("");
  box.innerHTML = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="Gráfico de peso">
    ${g}<path class="line" d="${path}"/>${dots}
    <line class="cross hidden" y1="${T - 6}" y2="${H - B}"/><circle class="pt hover hidden" r="6"/></svg>
    <div class="tip hidden"></div>`;

  // crosshair + tooltip (mouse e toque)
  const svg = box.querySelector("svg"), cross = svg.querySelector(".cross"), hp = svg.querySelector(".hover"),
    tip = box.querySelector(".tip");
  const show = (ev) => {
    const r = svg.getBoundingClientRect();
    const mx = ((ev.clientX - r.left) / r.width) * W;
    const p = pts.reduce((a, b) => (Math.abs(X(b.date) - mx) < Math.abs(X(a.date) - mx) ? b : a));
    const px = X(p.date), py = Y(p.weight);
    cross.setAttribute("x1", px); cross.setAttribute("x2", px);
    hp.setAttribute("cx", px); hp.setAttribute("cy", py);
    [cross, hp, tip].forEach((e) => e.classList.remove("hidden"));
    tip.innerHTML = `<b>${fmtKg(p.weight)} kg</b> <span class="muted">${fmtShort(p.date)}</span>`;
    tip.style.left = Math.min(Math.max((px / W) * r.width, 50), r.width - 50) + "px";
  };
  svg.addEventListener("pointermove", show);
  svg.addEventListener("pointerdown", show);
  svg.addEventListener("pointerleave", (ev) => {
    if (ev.pointerType === "mouse") [cross, hp, tip].forEach((e) => e.classList.add("hidden"));
  });
}

// ---------- perfil e metas ----------

const FIELD_NAMES = { sex: "sexo", age: "idade", height_cm: "altura", weight_kg: "peso", activity: "atividade", objective: "objetivo" };

document.querySelectorAll(".seg").forEach((seg) =>
  seg.querySelectorAll("button").forEach((b) => (b.onclick = () => setSeg(seg, b.dataset.v))));
function setSeg(seg, v) {
  seg.dataset.value = v || "";
  seg.querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.v === v));
}

function renderProfile() {
  const u = S.user, f = $("#userForm");
  if (!f.contains(document.activeElement)) {
    for (const k of ["age", "height_cm", "weight_kg", "activity"]) f.elements[k].value = u[k] ?? "";
    setSeg(f.querySelector('[data-name="sex"]'), u.sex);
    setSeg(f.querySelector('[data-name="objective"]'), u.objective);
  }
  const g = $("#goalsForm");
  if (!g.contains(document.activeElement))
    for (const k of ["kcal", "protein", "carbs", "fat"]) g.elements[k].value = S.goals[k];
  $("#goalsSource").textContent = {
    auto: "Calculadas pelo seu perfil. Mudou de peso ou objetivo, elas se ajustam sozinhas.",
    manual: "Definidas por você. Toque em “Calcular pelo perfil” pra voltar ao automático.",
    default: "Valores padrão genéricos. Preencha seus dados acima (ou conte pro Momo no chat) que eu calculo as suas.",
  }[S.goals_source];
  renderPantry();
  $("#notesCard").classList.toggle("hidden", !S.profile.length);
  $("#notes").innerHTML = S.profile.map((n) => "• " + esc(n)).join("<br>");
}

function renderPantry() {
  const box = $("#pantry");
  box.innerHTML = S.pantry.length ? "" : `<span class="muted small">Vazio — o Momo vai perguntar o que você tem.</span>`;
  for (const raw of S.pantry) {
    const it = typeof raw === "string" ? { name: raw } : raw;
    const c = document.createElement("span");
    c.className = "pchip" + (it.kcal != null ? " info" : "");
    c.innerHTML = `${esc(it.name)}${it.kcal != null ? ` <small>📋 ${Math.round(it.kcal)} kcal</small>` : ""}<button aria-label="Remover ${esc(it.name)}">✕</button>`;
    if (it.kcal != null) c.onclick = () => toast(`${it.name} · ${it.porcao || "porção"}: ${Math.round(it.kcal)} kcal · P ${it.protein ?? "?"} · C ${it.carbs ?? "?"} · G ${it.fat ?? "?"}`);
    c.querySelector("button").onclick = async (ev) => {
      ev.stopPropagation();
      render(await api(`/api/pantry?date=${current}`, { method: "POST", body: JSON.stringify({ remove: [it.name] }) }));
    };
    box.appendChild(c);
  }
}
$("#pantryForm").onsubmit = async (e) => {
  e.preventDefault();
  const add = $("#pantryInput").value.split(",").map((x) => x.trim()).filter(Boolean);
  if (!add.length) return;
  $("#pantryInput").value = "";
  render(await api(`/api/pantry?date=${current}`, { method: "POST", body: JSON.stringify({ add }) }));
};

function userFields() {
  const f = $("#userForm");
  return {
    sex: f.querySelector('[data-name="sex"]').dataset.value || null,
    objective: f.querySelector('[data-name="objective"]').dataset.value || null,
    age: +f.elements.age.value || null,
    height_cm: +f.elements.height_cm.value || null,
    weight_kg: parseFloat(String(f.elements.weight_kg.value).replace(",", ".")) || null,
    activity: f.elements.activity.value || null,
  };
}

async function saveUser(recalc) {
  const s = await api(`/api/user?date=${current}`, { method: "PUT", body: JSON.stringify({ ...userFields(), recalc }) });
  document.activeElement.blur();
  render(s);
  if (s.user_missing.length) toast("Salvo. Falta: " + s.user_missing.map((k) => FIELD_NAMES[k]).join(", "));
  else toast(s.goals_source === "auto" ? `Metas: ${s.goals.kcal} kcal · ${s.goals.protein} g proteína` : "Perfil salvo");
}
$("#userForm").onsubmit = (e) => { e.preventDefault(); saveUser(false); };
$("#recalcGoals").onclick = () => saveUser(true);

$("#goalsForm").onsubmit = async (e) => {
  e.preventDefault();
  const f = e.target, g = {};
  for (const k of ["kcal", "protein", "carbs", "fat"]) g[k] = +f.elements[k].value || 0;
  await api("/api/goals", { method: "PUT", body: JSON.stringify(g) });
  document.activeElement.blur();
  await load();
  toast("Metas salvas");
};

$("#redoOnboard").onclick = () => startOnboarding(S.user);
$("#resetUser").onclick = async () => {
  if (!confirm("Apagar seu perfil e voltar as metas pro padrão? (diário e fotos continuam)")) return;
  render(await api("/api/user", { method: "DELETE" }));
  startOnboarding();
};
$("#clearChat").onclick = async () => {
  if (!confirm("Apagar toda a conversa? (o diário continua)")) return;
  await api("/api/chat", { method: "DELETE" });
  load();
};

// ---------- calendário ----------

let calMonth = null;
$("#openCal").onclick = () => { calMonth = current.slice(0, 7); drawCal(); $("#calDlg").showModal(); };
$("#calClose").onclick = () => $("#calDlg").close();
$("#calToday").onclick = () => goTo(todayISO());
$("#calPrev").onclick = () => { calMonth = addMonth(calMonth, -1); drawCal(); };
$("#calNext").onclick = () => { calMonth = addMonth(calMonth, 1); drawCal(); };
$("#calDlg").addEventListener("click", (e) => { if (e.target === $("#calDlg")) $("#calDlg").close(); });

function addMonth(ym, n) {
  const [y, m] = ym.split("-").map(Number);
  const d = new Date(y, m - 1 + n, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function goTo(iso) {
  current = iso;
  $("#calDlg").close();
  load();
}

async function drawCal() {
  const ym = calMonth;
  const [y, m] = ym.split("-").map(Number);
  $("#calTitle").textContent = new Date(y, m - 1, 1).toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
  $("#calNext").style.visibility = ym >= todayISO().slice(0, 7) ? "hidden" : "visible";
  const grid = $("#calGrid");
  const { days, goal } = await api(`/api/calendar?month=${ym}`);
  if (ym !== calMonth) return; // trocou de mês enquanto carregava
  grid.innerHTML = "";
  const start = new Date(y, m - 1, 1).getDay(), n = new Date(y, m, 0).getDate(), today = todayISO();
  for (let i = 0; i < start; i++) grid.insertAdjacentHTML("beforeend", `<div class="c empty"></div>`);
  for (let dn = 1; dn <= n; dn++) {
    const iso = `${ym}-${String(dn).padStart(2, "0")}`, info = days[iso];
    const c = document.createElement("button");
    c.className = "c" + (iso > today ? " future" : "") + (iso === today ? " today" : "") + (iso === current ? " sel" : "");
    let html = `<span>${dn}</span>`;
    if (info?.n) {
      html += `<i class="dot ${info.kcal <= goal * 1.05 ? "ok" : "over"}"></i><small>${info.kcal.toLocaleString("pt-BR")}</small>`;
    }
    html += `<span class="marks">${(info?.weight ? "⚖" : "") + (info?.photos ? "📷" : "") + (info?.workout ? "🏋️" : "")}</span>`;
    c.innerHTML = html;
    c.setAttribute("aria-label", `${dn}${info?.n ? `, ${info.kcal} kcal` : ""}`);
    c.onclick = () => goTo(iso);
    grid.appendChild(c);
  }
}

// ---------- toast ----------

let toastT = null;
function toast(msg) {
  let t = $("#toast");
  if (!t) {
    t = document.createElement("div");
    t.id = "toast";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove("show"), 2600);
}

load();
