window.MOMO_BUILD = {"version": "2026.10.13.0804", "updates": "https://raw.githubusercontent.com/victorguima12/momo-fit/main"};
