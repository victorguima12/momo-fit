// Aba Rotina: o dia em 24 horas, estilo agenda do Google. Blocos com início/fim (sono, trabalho, treino...),
// um dia da semana por vez. O despertador é ligado ao bloco de sono (toca no fim dele). Tudo também
// pela conversa na barra de baixo ("trabalho das 9 às 18 de seg a sex").

(() => {
  const DAYS = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"];
  const FACES = ["😫", "😕", "😐", "🙂", "😄"];
  const CATS = {
    sono: ["😴", "Sono", "#5b7cff"], trabalho: ["💼", "Trabalho", "#ffb547"], treino: ["🏋️", "Treino", "#3ddc84"],
    refeicao: ["🍽️", "Refeição", "#ff7ab8"], estudo: ["📚", "Estudo", "#b48cff"], lazer: ["🎮", "Lazer", "#4fd1c5"],
    outro: ["•", "Outro", "#8a9a93"],
  };
  const HOUR = 52;  // px por hora
  const native = () => window.Capacitor?.isNativePlatform?.();
  const P = () => window.Capacitor?.Plugins || {};
  const hasPlugin = (n) => native() && !!P()[n];
  const OLD_APK = "Pra isso, instale o APK novo do Momo (uma vez só)";
  const androidDay = (i) => ((i + 1) % 7) + 1;  // 0=seg → 2 ... 6=dom → 1
  const root = () => $("#viewRoutine");
  const fromMin = (m) => { m = ((Math.round(m) % 1440) + 1440) % 1440; return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`; };
  const fmtH = (h) => { const hh = Math.floor(h), mm = Math.round((h - hh) * 60); return `${hh}h${mm ? String(mm).padStart(2, "0") : ""}`; };
  const nowMin = () => { const n = new Date(); return n.getHours() * 60 + n.getMinutes(); };
  let st = null, viewDay = null, editing = null, quality = null;

  // data (ISO) do dia da semana escolhido, na semana atual
  function dateOf(wdIdx) {
    const t = new Date(todayISO() + "T12:00"), cur = (t.getDay() + 6) % 7;
    t.setDate(t.getDate() + (wdIdx - cur));
    return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`;
  }

  async function show(scroll = true) {
    if (viewDay === null) viewDay = (new Date().getDay() + 6) % 7;
    st = await api(`/api/routine?date=${dateOf(viewDay)}`);
    render(scroll);
    syncReminders();
  }

  function render(scroll) {
    const isToday = st.date === todayISO(), s = st.sleep, last = s.today;
    root().innerHTML = `<div class="rt-head">
      <div class="rt-week">${DAYS.map((d, i) => `<button data-d="${i}" class="${i === viewDay ? "on" : ""} ${dateOf(i) === todayISO() ? "today" : ""}">${d}</button>`).join("")}</div>
      <button class="rt-sleepline" id="rtSleepLine">😴 ${last?.hours ? `Última noite <b>${fmtH(last.hours)}</b>${last.quality ? " " + FACES[last.quality - 1] : ""}` : "Como você dormiu?"}${s.avg7 ? ` · média ${fmtH(s.avg7)}` : ""} <span class="rt-link">${last ? "ver" : "registrar"} ›</span></button>
    </div>
    <div class="rt-cal" id="rtCal" style="height:${24 * HOUR}px">
      ${Array.from({ length: 24 }, (_, hr) => `<div class="rt-hour" style="top:${hr * HOUR}px"><span>${String(hr).padStart(2, "0")}:00</span></div>`).join("")}
      ${layout(st.segs).map(blockHTML).join("")}
      ${st.supps.map((x) => `<button class="rt-supp ${x.done ? "done" : ""}" style="top:${(x.at / 60) * HOUR - 11}px" data-supp="1">💊 ${esc(x.title.replace("Suplementos · ", ""))} · ${x.time}${x.done ? " ✓" : ""}</button>`).join("")}
      ${isToday ? `<div class="rt-now" id="rtNow" style="top:${nowMin() / 60 * HOUR}px"></div>` : ""}
    </div>
    ${!st.all.length ? `<div class="rt-hint muted small">Toque numa hora pra criar um bloco, ou escreve aqui embaixo:<br>"durmo das 23h às 7h e trabalho das 9 às 18 de seg a sex"</div>` : ""}`;
    bind();
    if (scroll) requestAnimationFrame(() => {
      root().scrollTop = Math.max(0, isToday ? nowMin() / 60 * HOUR - 120 : 6 * HOUR);
    });
  }

  // blocos que se sobrepõem dividem a largura (como na agenda do Google)
  function layout(segs) {
    const list = [...segs].sort((a, b) => a.from - b.from || b.to - a.to);
    let cluster = [], end = -1;
    const out = [];
    const flush = () => {
      const cols = [];
      for (const sg of cluster) {
        let c = cols.findIndex((last) => last <= sg.from);
        if (c < 0) { c = cols.length; cols.push(0); }
        cols[c] = sg.to;
        sg.col = c;
      }
      for (const sg of cluster) sg.ncols = cols.length;
      out.push(...cluster);
      cluster = [];
    };
    for (const sg of list) {
      if (sg.from >= end && cluster.length) flush();
      cluster.push(sg);
      end = Math.max(end, sg.to);
    }
    if (cluster.length) flush();
    return out;
  }

  function blockHTML(sg) {
    const [ico, , color] = CATS[sg.cat] || CATS.outro;
    const top = (sg.from / 60) * HOUR, height = Math.max(22, ((sg.to - sg.from) / 60) * HOUR - 2);
    const w = 1 / sg.ncols, short = height < 40;
    return `<button class="rt-block ${short ? "short" : ""}" data-id="${sg.id}"
      style="top:${top}px;height:${height}px;left:calc(54px + (100% - 60px) * ${sg.col * w});width:calc((100% - 60px) * ${w} - 3px);--c:${color}">
      <b>${sg.icon || ico} ${esc(sg.title)}</b> <span>${sg.start} – ${sg.end}${short ? "" : sg.cont === "prev" ? " · desde ontem" : sg.cont === "next" ? " · até amanhã" : ""}</span>
      ${sg.alarm && sg.cat === "sono" && sg.cont !== "next" ? `<i class="rt-tag">⏰ ${sg.end}</i>` : ""}${sg.remind ? `<i class="rt-tag">🔔</i>` : ""}
    </button>`;
  }

  function bind() {
    root().querySelectorAll(".rt-week button").forEach((b) => (b.onclick = () => { viewDay = +b.dataset.d; show(); }));
    $("#rtSleepLine").onclick = openSleep;
    root().querySelectorAll(".rt-block").forEach((b) => (b.onclick = (e) => { e.stopPropagation(); openEditor(st.all.find((r) => r.id === b.dataset.id)); }));
    root().querySelectorAll("[data-supp]").forEach((b) => (b.onclick = (e) => { e.stopPropagation(); switchView("viewSupps"); }));
    $("#rtCal").onclick = (e) => {
      if (e.target.closest(".rt-block, .rt-supp")) return;
      const y = e.clientY - $("#rtCal").getBoundingClientRect().top;
      const start = Math.floor((y / HOUR) * 2) * 30;  // arredonda pra meia hora
      openEditor({ start: fromMin(start), end: fromMin(start + 60), days: Array(7).fill(true), cat: "outro", title: "" });
    };
  }

  /* ---------- editar bloco (folha de baixo) ---------- */

  function openEditor(r) {
    editing = JSON.parse(JSON.stringify(r));
    const dlg = $("#rtSheet");
    const days = editing.days || Array(7).fill(true);
    dlg.innerHTML = `<form id="rtForm" class="sp-form">
      <h4>${editing.id ? "Editar bloco" : "Novo bloco"}</h4>
      <input name="title" placeholder="O quê (ex.: Trabalho)" value="${esc(editing.title || "")}" required>
      <div class="rt-times"><label>Começa<input name="start" type="time" value="${editing.start}" required></label>
        <label>Termina<input name="end" type="time" value="${editing.end}" required></label></div>
      <div class="rt-cats">${Object.entries(CATS).map(([k, [ico, label, color]]) => `<button type="button" data-c="${k}" class="${editing.cat === k ? "on" : ""}" style="--c:${color}">${ico} ${label}</button>`).join("")}</div>
      <div class="rt-days" id="rtFormDays">${DAYS.map((d, i) => `<button type="button" class="${days[i] ? "on" : ""}" data-i="${i}">${d}</button>`).join("")}</div>
      <label class="tr-toggle"><input type="checkbox" name="remind" ${editing.remind ? "checked" : ""}> 🔔 Lembrete na hora de começar</label>
      <label class="tr-toggle rt-alarm-opt ${editing.cat === "sono" ? "" : "hidden"}"><input type="checkbox" name="alarm" ${editing.alarm ? "checked" : ""}> ⏰ Despertador no fim do sono (cria no Relógio)</label>
      <div class="dlg-actions">
        ${editing.id ? `<button type="button" class="btn ghost danger" id="rtDel">Apagar</button>` : ""}
        <button type="button" class="btn ghost" id="rtCancel">Cancelar</button><button class="btn" type="submit">Salvar</button>
      </div></form>`;
    $("#replyPop").classList.add("hidden");
    dlg.showModal();
    const f = $("#rtForm");
    f.querySelectorAll(".rt-cats button").forEach((b) => (b.onclick = () => {
      editing.cat = b.dataset.c;
      f.querySelectorAll(".rt-cats button").forEach((x) => x.classList.toggle("on", x === b));
      f.querySelector(".rt-alarm-opt").classList.toggle("hidden", editing.cat !== "sono");
      if (!f.elements.title.value.trim()) f.elements.title.value = CATS[editing.cat][1];
    }));
    $("#rtFormDays").querySelectorAll("button").forEach((b) => (b.onclick = () => b.classList.toggle("on")));
    $("#rtCancel").onclick = () => dlg.close();
    $("#rtDel")?.addEventListener("click", async () => {
      dlg.close();
      st = await api(`/api/routine/${editing.id}?date=${st.date}`, { method: "DELETE" });
      render(false);
      syncReminders();
    });
    f.onsubmit = async (e) => {
      e.preventDefault();
      const days = [...$("#rtFormDays").querySelectorAll("button")].map((b) => b.classList.contains("on"));
      if (!days.some(Boolean)) return toast("Escolhe pelo menos um dia");
      const remind = f.elements.remind.checked, alarm = editing.cat === "sono" && f.elements.alarm.checked;
      if (remind && !(await askNotify())) return;
      const body = { id: editing.id, title: f.elements.title.value.trim(), start: f.elements.start.value, end: f.elements.end.value,
        cat: editing.cat, days, remind, alarm };
      dlg.close();
      st = await api(`/api/routine?date=${st.date}`, { method: "POST", body: JSON.stringify(body) });
      render(false);
      syncReminders();
      if (alarm) applyPendingAlarm();
    };
  }

  /* ---------- sono de verdade (como dormiu) ---------- */

  function openSleep() {
    const s = st.sleep, last = s.today, sb = st.sleep_block;
    quality = last?.quality ?? null;
    const dlg = $("#rtSheet");
    dlg.innerHTML = `<h4>😴 Como você dormiu?</h4>
      <form class="rt-sleep" id="rtSleep">
        <label><span>Deitei</span><input type="time" name="bed" value="${last?.bed || sb?.start || "23:00"}"></label>
        <label><span>Acordei</span><input type="time" name="wake" value="${last?.wake || sb?.end || "07:00"}"></label>
        <div class="rt-faces">${FACES.map((f, i) => `<button type="button" data-q="${i + 1}" class="${quality === i + 1 ? "on" : ""}">${f}</button>`).join("")}</div>
        <button class="btn" type="submit">${last ? "Atualizar" : "Salvar"}</button>
      </form>
      <div id="rtChart" class="chart"></div>
      <div class="muted small rt-avg">${s.avg7 ? `Média 7 noites: <b>${fmtH(s.avg7)}</b> · meta ` : "Meta "}
        <select id="rtGoal">${[6, 6.5, 7, 7.5, 8, 8.5, 9].map((g) => `<option value="${g}" ${s.goal === g ? "selected" : ""}>${fmtH(g)}</option>`).join("")}</select></div>
      <div class="dlg-actions"><button class="btn ghost" id="rtSleepClose">Fechar</button></div>`;
    $("#replyPop").classList.add("hidden");
    dlg.showModal();
    drawSleepChart();
    dlg.querySelectorAll(".rt-faces button").forEach((b) => (b.onclick = () => {
      quality = +b.dataset.q;
      dlg.querySelectorAll(".rt-faces button").forEach((x) => x.classList.toggle("on", x === b));
    }));
    $("#rtSleepClose").onclick = () => dlg.close();
    $("#rtSleep").onsubmit = async (e) => {
      e.preventDefault();
      const f = e.target;
      const sl = await api(`/api/sleep/${todayISO()}`, { method: "PUT", body: JSON.stringify({ bed: f.elements.bed.value, wake: f.elements.wake.value, quality }) });
      dlg.close();
      toast(`Sono registrado: ${fmtH(sl.today.hours)}`);
      show(false);
    };
    $("#rtGoal").onchange = async (e) => { await api("/api/sleep-goal", { method: "PUT", body: JSON.stringify({ goal: +e.target.value }) }); show(false); };
  }

  function drawSleepChart() {
    const box = $("#rtChart"), s = st.sleep, nights = s.nights;
    if (!nights.some((n) => n.hours)) { box.innerHTML = `<div class="chart-empty">As últimas 2 semanas aparecem aqui.</div>`; return; }
    const W = box.clientWidth || 300, H = 130, L = 26, R = 4, T = 10, B = 18;
    const max = Math.max(10, ...nights.map((n) => n.hours || 0));
    const bw = (W - L - R) / nights.length;
    const Y = (v) => T + (1 - v / max) * (H - T - B);
    let g = "";
    for (const v of [0, 4, 8]) g += `<line class="grid" x1="${L}" x2="${W - R}" y1="${Y(v)}" y2="${Y(v)}"/><text class="axis" x="${L - 5}" y="${Y(v) + 3}" text-anchor="end">${v}h</text>`;
    g += `<line class="goal" x1="${L}" x2="${W - R}" y1="${Y(s.goal)}" y2="${Y(s.goal)}"/>`;
    nights.forEach((n, i) => {
      const x = L + i * bw + 1, w = Math.max(2, bw - 2);  // 2px de respiro entre barras
      if (n.hours) {
        const y = Y(n.hours), r = Math.min(4, w / 2);
        g += `<path class="sbar ${n.hours < s.goal - 0.5 ? "low" : ""}" d="M${x},${H - B} V${y + r} q0,-${r} ${r},-${r} H${x + w - r} q${r},0 ${r},${r} V${H - B} Z"/>`;
      }
      if (i % 2 === 1) g += `<text class="axis" x="${x + w / 2}" y="${H - 5}" text-anchor="middle">${n.date.slice(8)}</text>`;
      g += `<rect class="hit" x="${L + i * bw}" y="${T}" width="${bw}" height="${H - T - B}" data-i="${i}"/>`;
    });
    box.innerHTML = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="Horas de sono por noite">${g}</svg><div class="rt-tip muted small" id="rtTip">Toque numa barra · tracejado = meta</div>`;
    box.querySelectorAll(".hit").forEach((el) => {
      const showTip = () => {
        const n = nights[+el.dataset.i];
        $("#rtTip").innerHTML = n.hours ? `<b>${fmtH(n.hours)}</b> · ${n.date.slice(8)}/${n.date.slice(5, 7)} · ${n.bed}→${n.wake}${n.quality ? " " + FACES[n.quality - 1] : ""}` : `${n.date.slice(8)}/${n.date.slice(5, 7)}: sem registro`;
      };
      el.addEventListener("pointerdown", showTip);
      el.addEventListener("pointerenter", showTip);
    });
  }

  /* ---------- despertador (no Relógio do celular) ---------- */

  async function applyPendingAlarm() {
    const s = await api(`/api/routine?date=${todayISO()}`);
    const a = s.alarm;
    if (!a?.time) return;
    if (!hasPlugin("MomoAlarm")) return toast(native() ? OLD_APK : `⏰ ${a.time}: o despertador é criado no Relógio do celular`);
    const [hour, minute] = a.time.split(":").map(Number);
    try {
      await P().MomoAlarm.setAlarm({ hour, minute, message: "Momo · bom dia ☀️", days: a.days.map((on, i) => (on ? androidDay(i) : null)).filter(Boolean) });
      await api(`/api/alarm?date=${todayISO()}`, { method: "PUT", body: JSON.stringify({ ...a, pending: false }) });
      toast(`⏰ Despertador ${a.time} criado no Relógio`);
    } catch (e) { toast("Não deu pra criar o alarme: " + e.message); }
  }

  /* ---------- lembretes (notificações que repetem toda semana) ---------- */

  async function askNotify() {
    if (!native()) { toast("Lembretes funcionam no app do celular"); return true; }
    if (!hasPlugin("LocalNotifications")) { toast(OLD_APK); return false; }
    const r = await P().LocalNotifications.requestPermissions();
    if (r.display !== "granted") { toast("Sem permissão de notificação: libere nas configurações do celular"); return false; }
    return true;
  }

  let syncing = false;
  async function syncReminders(state) {
    if (!hasPlugin("LocalNotifications") || syncing) return;
    syncing = true;
    try {
      const LN = P().LocalNotifications;
      const s = state || st || (await api(`/api/routine?date=${todayISO()}`));
      const pend = await LN.getPending();
      if (pend.notifications.length) await LN.cancel({ notifications: pend.notifications.map((n) => ({ id: n.id })) });
      const list = [];
      let id = 1000;
      for (const r of s.all.filter((x) => x.remind)) {
        const [hour, minute] = r.start.split(":").map(Number);
        const ico = r.icon || (CATS[r.cat] || CATS.outro)[0];
        r.days.forEach((on, i) => {
          if (on) list.push({ id: id++, title: `${ico} ${r.title}`, body: `${r.start} – ${r.end}`,
            schedule: { on: { weekday: androidDay(i), hour, minute }, allowWhileIdle: true } });
        });
      }
      for (const sl of s.slots.filter((x) => x.time && x.used)) {
        const [hour, minute] = sl.time.split(":").map(Number);
        list.push({ id: id++, title: `💊 Suplementos · ${sl.label}`, body: "Hora de tomar os suplementos", schedule: { on: { hour, minute }, allowWhileIdle: true } });
      }
      if (list.length) await LN.schedule({ notifications: list });
    } catch (e) { console.warn("lembretes:", e); } finally { syncing = false; }
  }

  // a linha do "agora" anda sozinha
  setInterval(() => { const n = $("#rtNow"); if (n) n.style.top = `${nowMin() / 60 * HOUR}px`; }, 60000);

  window.Rotina = {
    show,
    refresh: () => (root().classList.contains("active") ? show(false) : null),
    sync: () => api(`/api/routine?date=${todayISO()}`).then(syncReminders).catch(() => {}),
    applyPendingAlarm,
    setAlarmFromChat: applyPendingAlarm,
  };
})();
