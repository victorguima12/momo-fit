// Backend local do Momo: a mesma API que o server.py tinha, rodando dentro do app.
// Dados no IndexedDB do aparelho; a IA é chamada direto na OpenAI. Na 1ª abertura importa seed/ (dados do PC).

const Backend = (() => {
  // a chave vem no config.js do APK e fica guardada no aparelho; as atualizações OTA não trazem a chave
  let CFG = window.MOMO_CONFIG || {};
  const MEALS = ["cafe", "almoco", "lanche", "jantar"];
  const DEFAULT_GOALS = { kcal: 2200, protein: 150, carbs: 220, fat: 70 };
  const USER_FIELDS = ["sex", "age", "height_cm", "weight_kg", "activity", "objective"];
  const EXTRA_FIELDS = ["name", "target_kg", "pace", "training", "diet", "routine", "despensa"];
  const ACTIVITY = { sedentario: 1.2, leve: 1.375, moderado: 1.55, intenso: 1.725 };
  const OBJECTIVE = { perder: -500, manter: 0, ganhar: 300 };

  let DB = null, TEMPLATE = null, PROMPTS = null;
  const photoURLs = new Map(); // nome → object URL

  /* ---------- IndexedDB ---------- */

  let idbP = null;
  function idb() {
    idbP = idbP || new Promise((res, rej) => {
      const r = indexedDB.open("momo", 1);
      r.onupgradeneeded = () => { r.result.createObjectStore("kv"); r.result.createObjectStore("photos"); };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
    return idbP;
  }
  async function idbDo(store, mode, fn) {
    const db = await idb();
    return new Promise((res, rej) => {
      const tx = db.transaction(store, mode);
      const req = fn(tx.objectStore(store));
      tx.oncomplete = () => res(req?.result);
      tx.onerror = () => rej(tx.error);
    });
  }
  const kvGet = (k) => idbDo("kv", "readonly", (s) => s.get(k));
  const kvSet = (k, v) => idbDo("kv", "readwrite", (s) => s.put(v, k));
  const photoPut = (name, blob) => idbDo("photos", "readwrite", (s) => s.put(blob, name));
  const photoDel = (name) => idbDo("photos", "readwrite", (s) => s.delete(name));

  // grava em sequência (a última versão sempre vence)
  let saving = Promise.resolve();
  function save() {
    const snap = JSON.parse(JSON.stringify(DB));
    saving = saving.then(() => kvSet("db", snap));
    return saving;
  }

  /* ---------- inicialização ---------- */

  async function init() {
    CFG = { ...((await kvGet("config")) || {}), ...Object.fromEntries(Object.entries(CFG).filter(([, v]) => v)) };
    if (CFG.openai_key) await kvSet("config", CFG);
    [TEMPLATE, PROMPTS] = await Promise.all([fetch("plan.json").then((r) => r.json()), fetch("prompts.json").then((r) => r.json())]);
    DB = await kvGet("db");
    if (!DB) DB = await importSeed();
    for (const [k, v] of Object.entries({ goals: { ...DEFAULT_GOALS }, goals_source: "default", user: {}, profile: [],
      pantry: [], days: {}, chat: [], workouts: [], coach_chat: [], supps: [], sleep_goal: 8, routine: [] })) if (DB[k] === undefined) DB[k] = v;
    getPlan();
    pantryNormalize();
    suppMigrate();
    routineMigrate();
    await save();
    // fotos: carrega tudo em object URLs (são poucas)
    const db = await idb();
    await new Promise((res) => {
      const cur = db.transaction("photos").objectStore("photos").openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return res();
        photoURLs.set(c.key, URL.createObjectURL(c.value));
        c.continue();
      };
      cur.onerror = () => res();
    });
  }

  async function importSeed() {
    try {
      const r = await fetch("seed/db.json");
      if (!r.ok) return {};
      const db = await r.json();
      const names = Object.values(db.days || {}).flatMap((d) => d.photos || []);
      for (const n of names) {
        const pr = await fetch("seed/photos/" + n);
        if (pr.ok) await photoPut(n, await pr.blob());
      }
      return db;
    } catch { return {}; }
  }

  /* ---------- utilidades ---------- */

  const pad = (n) => String(n).padStart(2, "0");
  const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const today = () => isoDate(new Date());
  const nowISO = () => { const d = new Date(); return `${isoDate(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`; };
  const hhmm = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
  const uid = (n = 8) => Array.from(crypto.getRandomValues(new Uint8Array(n / 2)), (b) => b.toString(16).padStart(2, "0")).join("");
  const round = (v, k = 0) => { const f = 10 ** k; return Math.round(v * f) / f; };
  const fnum = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : null; };
  const clamp = (v, lo, hi, dflt) => { const n = fnum(v); return n === null ? dflt : Math.min(Math.max(n, lo), hi); };
  const clone = (o) => JSON.parse(JSON.stringify(o));
  class ApiError extends Error {}

  /* ---------- dia, metas, perfil ---------- */

  const day = (d) => (DB.days[d] = DB.days[d] || { entries: [] });
  const missingUser = () => USER_FIELDS.filter((k) => !DB.user[k]);
  function totals(entries) {
    const t = { kcal: 0, protein: 0, carbs: 0, fat: 0 };
    for (const e of entries) for (const k in t) t[k] += parseFloat(e[k] || 0) || 0;
    for (const k in t) t[k] = Math.round(t[k]);
    return t;
  }
  const defaultPlan = (u) => ({ kcal_adjust: OBJECTIVE[u.objective] ?? 0, protein_g_kg: u.objective === "manter" ? 1.6 : 2.0, fat_g_kg: 0.9 });

  function calcGoals(u, explain = false) {
    const w = +u.weight_kg, h = +u.height_cm, a = +u.age;
    const bmr = 10 * w + 6.25 * h - 5 * a + (u.sex === "M" ? 5 : -161);
    const factor = ACTIVITY[u.activity] ?? 1.375;
    const plan = { ...defaultPlan(u), ...(u.plan || {}) };
    const kcal = Math.max(bmr * factor + plan.kcal_adjust, bmr, 1200); // nunca abaixo do basal
    const protein = w * plan.protein_g_kg, fat = w * plan.fat_g_kg;
    const carbs = Math.max((kcal - protein * 4 - fat * 9) / 4, 50);
    const goals = { kcal: Math.round(kcal / 10) * 10, protein: Math.round(protein), carbs: Math.round(carbs), fat: Math.round(fat) };
    if (!explain) return goals;
    return {
      metabolismo_basal_mifflin_st_jeor: Math.round(bmr), fator_atividade: factor, gasto_total_estimado: Math.round(bmr * factor),
      ajuste_objetivo_kcal: plan.kcal_adjust, proteina_g_por_kg: plan.protein_g_kg, gordura_g_por_kg: plan.fat_g_kg,
      carbo: "o que sobra das calorias", justificativa_do_plano: plan.why ?? null, resultado: goals,
    };
  }

  function goalsOrigin() {
    if (DB.goals_source === "auto" && !missingUser().length) return { tipo: "calculada pelo perfil", conta: calcGoals(DB.user, true) };
    if (DB.goals_source === "manual") return { tipo: "definida pelo usuário na mão" };
    return { tipo: "valor padrão genérico (2200 kcal), ainda não personalizado: falta completar o perfil" };
  }

  function setUser(fields) {
    const u = DB.user;
    for (const k of USER_FIELDS) {
      let v = fields[k];
      if (v === null || v === undefined || v === "") continue;
      if (["age", "height_cm", "weight_kg"].includes(k)) {
        v = fnum(v);
        if (v === null) continue;
        v = round(v, 1);
      } else if (k === "sex") v = String(v).toUpperCase().startsWith("F") ? "F" : "M";
      else if ((k === "activity" && !(v in ACTIVITY)) || (k === "objective" && !(v in OBJECTIVE))) continue;
      if (k === "objective" && v !== u.objective) delete u.plan; // plano da IA era pra outro objetivo
      u[k] = v;
    }
    if (!missingUser().length && DB.goals_source !== "manual") {
      DB.goals = calcGoals(u);
      DB.goals_source = "auto";
    }
  }

  function setWeight(d, kg) {
    day(d).weight = round(+kg, 1);
    const latest = Object.keys(DB.days).filter((k) => DB.days[k].weight).sort().pop();
    if (latest === d) setUser({ weight_kg: kg }); // só o peso mais recente vira o do perfil
  }

  // despensa: [{name, porcao?, kcal?, protein?, carbs?, fat?}] — a tabela vem de foto de rótulo
  const pName = (x) => String(typeof x === "string" ? x : x?.name || "").trim().toLowerCase();
  function pantryNormalize() { DB.pantry = (DB.pantry || []).map((x) => (typeof x === "string" ? { name: pName(x) } : x)); }
  function pantryUpdate(add, remove) {
    pantryNormalize();
    for (const it of add || []) {
      const name = pName(it);
      if (!name) continue;
      let cur = DB.pantry.find((x) => x.name === name);
      if (!cur) DB.pantry.push((cur = { name }));
      if (it && typeof it === "object") {
        if (it.porcao) cur.porcao = String(it.porcao).slice(0, 40);
        for (const k of ["kcal", "protein", "carbs", "fat"]) if (fnum(it[k]) !== null) cur[k] = round(fnum(it[k]), 1);
      }
    }
    const gone = new Set((remove || []).map(pName));
    DB.pantry = DB.pantry.filter((x) => !gone.has(x.name));
  }

  async function savePhoto(d, dataUrl) {
    const name = `${d}_${uid(6)}.jpg`;
    const blob = await (await fetch(dataUrl.startsWith("data:") ? dataUrl : "data:image/jpeg;base64," + dataUrl)).blob();
    await photoPut(name, blob);
    photoURLs.set(name, URL.createObjectURL(blob));
    (day(d).photos = day(d).photos || []).push(name);
    return name;
  }

  /* ---------- suplementos ----------
     Horários (slots) são de cada pessoa: começa com Manhã e Noite e dá pra criar outros (Tarde, Shake...).
     Cada suplemento tem a dose por unidade e, por horário, quantas unidades em cada dia (seg→dom).
     Ex.: D3 2000 UI, Manhã [2,1,2,1,2,1,2]. Tomado = "id@slot" no dia. Itens com kcal/proteína (whey,
     colágeno) viram um registro na Dieta quando o horário é marcado como tomado. */

  const FORMS = ["caps", "po", "outro"];
  const norm = (x) => String(x || "").trim().toLowerCase();
  const wd = (d) => (new Date(d + "T12:00").getDay() + 6) % 7;  // 0 = segunda
  const WEEK = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"];
  function suppSlots() {
    if (!DB.supp_slots) DB.supp_slots = [{ id: "am", label: "Manhã", time: "08:00" }, { id: "pm", label: "Noite", time: "21:00" }];
    return DB.supp_slots;
  }
  function slotFind(x, create = false) {
    const k = norm(x);
    let sl = suppSlots().find((y) => y.id === x || norm(y.label) === k);
    if (!sl && create && k) {
      sl = { id: uid(4), label: String(x).trim().slice(0, 24), time: "" };
      sl.label = sl.label[0].toUpperCase() + sl.label.slice(1);
      DB.supp_slots.push(sl);
    }
    return sl || null;
  }
  // migra o formato antigo (dose/when diário) pro novo
  function suppMigrate() {
    suppSlots();
    for (const x of DB.supps || []) {
      if (x.sched) continue;
      x.form = x.form || "outro";
      x.sched = { [x.when === "noite" || x.when === "dormir" ? "pm" : "am"]: [1, 1, 1, 1, 1, 1, 1] };
      delete x.when;
    }
    for (const dd of Object.values(DB.days)) if (dd.supps_taken) dd.supps_taken = dd.supps_taken.map((t) => (t.includes("@") ? t : t + "@am"));
  }
  function suppFind(x) {
    const k = norm(x);
    if (!k) return null;
    return DB.supps.find((y) => y.id === x || norm(y.name) === k)
      || DB.supps.find((y) => norm(y.name).includes(k) || k.includes(norm(y.name))) || null;
  }
  function week7(v, dflt) {
    if (Array.isArray(v)) return Array.from({ length: 7 }, (_, i) => Math.max(0, Math.min(20, Math.trunc(+v[i] || 0))));
    const n = Math.trunc(+v);
    return Array(7).fill(Number.isFinite(n) && n >= 0 ? Math.min(20, n) : dflt);
  }
  function suppAdd(it) {
    const name = String((typeof it === "string" ? it : it?.name) || "").trim().slice(0, 40);
    if (!name) return null;
    // cadastro: só nome exato (a busca aproximada de suppFind confundia "Glicina" com "Zinco bisglicinato")
    let x = DB.supps.find((y) => norm(y.name) === norm(name));
    if (!x) DB.supps.push((x = { id: uid(6), name: name[0].toUpperCase() + name.slice(1), dose: "", form: "outro", sched: {} }));
    if (it && typeof it === "object") {
      if (it.dose !== undefined) x.dose = String(it.dose || "").slice(0, 30);
      if (FORMS.includes(it.form)) x.form = it.form;
      if (it.notes !== undefined) x.notes = String(it.notes || "").slice(0, 80);
      for (const k of ["kcal", "protein", "carbs", "fat"]) if (it[k] !== undefined) x[k] = fnum(it[k]) === null ? undefined : round(fnum(it[k]), 1);
      if (it.sched && typeof it.sched === "object") {
        x.sched = {};
        for (const [slot, v] of Object.entries(it.sched)) {
          const sl = slotFind(slot, true);
          if (sl) x.sched[sl.id] = week7(v, 1);
        }
      }
    }
    if (!Object.keys(x.sched).length) x.sched = { [suppSlots()[0].id]: week7(1, 1) };
    return x;
  }
  const tkey = (id, slot) => `${id}@${slot}`;
  const mealNow = () => { const h = new Date().getHours(); return h < 11 ? "cafe" : h < 15 ? "almoco" : h < 19 ? "lanche" : "jantar"; };
  function suppTaken(d, id, slot, on) {
    const t = new Set(day(d).supps_taken || []);
    on ? t.add(tkey(id, slot)) : t.delete(tkey(id, slot));
    day(d).supps_taken = [...t];
    syncSlotFood(d, slot);
  }
  // o que tem nutriente (whey, colágeno) entra na Dieta quando é tomado; desmarcou, sai
  function syncSlotFood(d, slot) {
    const sl = suppSlots().find((y) => y.id === slot);
    const taken = new Set(day(d).supps_taken || []);
    const items = DB.supps.filter((x) => taken.has(tkey(x.id, slot)) && (x.kcal || x.protein));
    const eid = `supp-${slot}`;
    day(d).entries = day(d).entries.filter((e) => e.id !== eid);
    if (!items.length) return;
    const n = (x) => x.sched[slot]?.[wd(d)] || 1;
    const e = { id: eid, name: `Suplementos · ${sl ? sl.label : slot}`, quantity: items.map((x) => x.name).join(", "),
      meal: mealNow(), time: hhmm(), auto: true };
    for (const k of ["kcal", "protein", "carbs", "fat"]) e[k] = round(items.reduce((a, x) => a + (x[k] || 0) * n(x), 0), 1);
    day(d).entries.push(e);
  }
  function suppToday(d) {
    const i = wd(d), taken = new Set(DB.days[d]?.supps_taken || []);
    return suppSlots().map((sl) => ({
      ...sl,
      items: DB.supps.filter((x) => (x.sched[sl.id]?.[i] || 0) > 0)
        .map((x) => ({ id: x.id, name: x.name, dose: x.dose, form: x.form, count: x.sched[sl.id][i], taken: taken.has(tkey(x.id, sl.id)) })),
    }));
  }
  // limites diários seguros (adultos) pra checar o stack — por palavra no nome
  const UL = [
    { re: /vit(amin[ae])?\.?\s*d|d3/i, label: "Vitamina D", unit: "UI", max: 4000, conv: { ui: 1, iu: 1, mcg: 40 } },
    { re: /vit(amin[ae])?\.?\s*e\b/i, label: "Vitamina E", unit: "mg", max: 1000, conv: { mg: 1, ui: 0.67, iu: 0.67 } },
    { re: /zin[ck]/i, label: "Zinco", unit: "mg", max: 40, conv: { mg: 1 } },
    { re: /sel[eê]n/i, label: "Selênio", unit: "mcg", max: 400, conv: { mcg: 1, µg: 1, mg: 1000 } },
    { re: /magn[eé]s/i, label: "Magnésio (suplemento)", unit: "mg", max: 350, conv: { mg: 1 } },
    { re: /vit(amin[ae])?\.?\s*c\b/i, label: "Vitamina C", unit: "mg", max: 2000, conv: { mg: 1, g: 1000 } },
  ];
  function doseIn(dose, conv) {
    const m = String(dose || "").replace(",", ".").match(/([\d.]+)\s*(ui|iu|mcg|µg|mg|g)\b/i);
    if (!m) return null;
    const f = conv[m[2].toLowerCase()];
    return f ? +m[1] * f : null;
  }
  function suppSafety() {
    const out = [];
    for (const u of UL) {
      const perDay = Array(7).fill(0);
      let found = false;
      for (const x of DB.supps) {
        if (!u.re.test(x.name)) continue;
        const per = doseIn(x.dose, u.conv);
        if (per === null) continue;
        found = true;
        for (const v of Object.values(x.sched)) v.forEach((n, i) => (perDay[i] += n * per));
      }
      if (!found) continue;
      const avg = perDay.reduce((a, b) => a + b, 0) / 7;
      const over = perDay.map((v, i) => (v > u.max ? WEEK[i] : null)).filter(Boolean);
      out.push({ label: u.label, unit: u.unit, max: u.max, avg: Math.round(avg), peak: Math.round(Math.max(...perDay)),
        days: perDay.map(Math.round), over, status: avg > u.max ? "acima" : over.length ? "picos" : "ok" });
    }
    return out;
  }
  function suppState(d) {
    const last7 = Array.from({ length: 7 }, (_, i) => { const x = new Date(d + "T12:00"); x.setDate(x.getDate() - 6 + i); return isoDate(x); });
    return {
      date: d, weekday: wd(d), slots: suppSlots(), today: suppToday(d), safety: suppSafety(),
      supps: DB.supps.map((x) => ({ ...x, week_caps: Object.values(x.sched).reduce((a, v) => a + v.reduce((b, c) => b + c, 0), 0) })),
      // aderência: % do que era pra tomar em cada um dos últimos 7 dias
      adherence: last7.map((dd) => {
        const due = suppToday(dd).flatMap((sl) => sl.items);
        return { date: dd, due: due.length, done: due.filter((it) => it.taken).length };
      }),
    };
  }

  /* ---------- sono (fica no dia em que a pessoa ACORDOU) ---------- */

  const HM = /^([01]?\d|2[0-3])[:h]?([0-5]\d)?$/;
  function hm(x) {
    const m = String(x || "").trim().toLowerCase().replace(/\s/g, "").match(HM);
    return m ? `${pad(+m[1])}:${m[2] || "00"}` : null;
  }
  function sleepSet(d, b) {
    const bed = hm(b.bed), wake = hm(b.wake);
    if (!bed || !wake) throw new ApiError("Horários inválidos (use 23:30 e 07:00)");
    const [bh, bm] = bed.split(":").map(Number), [wh, wm] = wake.split(":").map(Number);
    let mins = wh * 60 + wm - (bh * 60 + bm);
    if (mins <= 0) mins += 24 * 60;  // dormiu antes da meia-noite
    const q = Math.trunc(+b.quality);
    day(d).sleep = { bed, wake, hours: round(mins / 60, 2), quality: q >= 1 && q <= 5 ? q : null };
    return day(d).sleep;
  }
  function sleepState(d) {
    const days = Array.from({ length: 14 }, (_, i) => { const x = new Date(d + "T12:00"); x.setDate(x.getDate() - 13 + i); return isoDate(x); });
    const nights = days.map((dd) => ({ date: dd, ...(DB.days[dd]?.sleep || {}) }));
    const last7 = nights.slice(-7).filter((n) => n.hours);
    return { date: d, goal: DB.sleep_goal, today: DB.days[d]?.sleep || null, nights,
      avg7: last7.length ? round(last7.reduce((a, n) => a + n.hours, 0) / last7.length, 2) : null };
  }

  /* ---------- rotina: blocos do dia (estilo agenda do Google) ----------
     Cada bloco: início/fim, dias da semana em que COMEÇA, categoria (cor). Um bloco que passa da
     meia-noite (sono 23:00→07:00) aparece no fim do dia e no começo do dia seguinte.
     O despertador é ligado ao bloco de sono: toca no fim dele, nos dias em que a pessoa acorda. */

  const CATS = ["sono", "trabalho", "treino", "refeicao", "estudo", "lazer", "outro"];
  function daysMask(v) {
    if (Array.isArray(v)) return Array.from({ length: 7 }, (_, i) => !!v[i]);
    const t = norm(v);
    if (!t || /todo|todos|diari/.test(t)) return Array(7).fill(true);
    if (/fim de semana|fds/.test(t)) return [0, 0, 0, 0, 0, 1, 1].map(Boolean);
    if (/seg\w*\s*(a|-|até)\s*sex|dias? (de semana|úteis|uteis)/.test(t)) return [1, 1, 1, 1, 1, 0, 0].map(Boolean);
    const out = Array(7).fill(false);
    WEEK.forEach((w, i) => { if (t.includes(w.slice(0, 3)) || (w === "sáb" && t.includes("sab"))) out[i] = true; });
    return out.some(Boolean) ? out : Array(7).fill(true);
  }
  const mins = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
  const hhmmOf = (m) => { m = ((m % 1440) + 1440) % 1440; return `${pad(Math.floor(m / 60))}:${pad(m % 60)}`; };
  function guessCat(title) {
    const t = norm(title);
    return /dorm|sono|deitar/.test(t) ? "sono" : /trabalh|expediente|reuni|escrit/.test(t) ? "trabalho"
      : /treino|academia|corrid|muscula/.test(t) ? "treino" : /almo|jant|caf[eé]|lanche|refei/.test(t) ? "refeicao"
      : /estud|aula|faculdade|curso|ler|leitura/.test(t) ? "estudo" : /lazer|jogo|filme|série|serie|passeio/.test(t) ? "lazer" : "outro";
  }
  function routineMigrate() {
    for (const r of DB.routine || []) {
      if (!r.start) { r.start = r.time; r.end = hhmmOf(mins(r.time) + 60); delete r.time; }
      if (!r.cat) r.cat = guessCat(r.title);
    }
  }
  function routineAdd(it) {
    const start = hm(it.start || it.time);
    const title = String(it.title || "").trim().slice(0, 60);
    if (!start || !title) return null;
    let r = it.id ? DB.routine.find((x) => x.id === it.id) : DB.routine.find((x) => norm(x.title) === norm(title));
    if (!r) DB.routine.push((r = { id: uid(6), remind: false }));
    const end = hm(it.end) || r.end || hhmmOf(mins(start) + 60);
    Object.assign(r, { start, end: end === start ? hhmmOf(mins(start) + 30) : end, title,
      days: daysMask(it.days ?? r.days), cat: CATS.includes(it.cat || it.category) ? it.cat || it.category : r.cat || guessCat(title) });
    if (it.remind !== undefined) r.remind = !!it.remind;
    if (it.alarm !== undefined) r.alarm = !!it.alarm && r.cat === "sono";
    if (it.icon !== undefined) r.icon = String(it.icon || "").slice(0, 4);
    DB.routine.sort((a, b) => (a.start < b.start ? -1 : 1));
    if (r.alarm) DB.alarm = { ...alarmOf(r), pending: true };
    return r;
  }
  const crosses = (r) => mins(r.end) <= mins(r.start);
  // dias em que a pessoa ACORDA (fim do bloco de sono)
  const wakeDays = (r) => (crosses(r) ? r.days.map((_, i) => r.days[(i + 6) % 7]) : r.days);
  const alarmOf = (r) => ({ time: r.end, days: wakeDays(r), block: r.id });
  function routineState(d) {
    const i = wd(d), prev = (i + 6) % 7;
    const segs = [];
    for (const r of DB.routine) {
      const a = mins(r.start), b = mins(r.end);
      if (r.days[i]) segs.push({ ...r, from: a, to: crosses(r) ? 1440 : b, cont: crosses(r) ? "next" : null });
      if (crosses(r) && r.days[prev]) segs.push({ ...r, from: 0, to: b, cont: "prev" });
    }
    const supps = suppToday(d).filter((sl) => sl.time && sl.items.length)
      .map((sl) => ({ id: "slot:" + sl.id, title: `Suplementos · ${sl.label}`, at: mins(sl.time), time: sl.time,
        done: sl.items.every((x) => x.taken), n: sl.items.length }));
    const sleepBlock = DB.routine.find((r) => r.cat === "sono");
    return { date: d, weekday: i, segs, supps, all: DB.routine, alarm: DB.alarm || null,
      sleep_block: sleepBlock || null, sleep: sleepState(d),
      slots: suppSlots().map((sl) => ({ ...sl, used: DB.supps.some((x) => (x.sched[sl.id] || []).some(Boolean)) })) };
  }

  /* ---------- treino (port do treino.py) ---------- */

  function getPlan() {
    if (!DB.plan) DB.plan = clone(TEMPLATE);
    for (const [k, v] of Object.entries(TEMPLATE.muscles)) if (!(k in DB.plan.muscles)) DB.plan.muscles[k] = v;
    return DB.plan;
  }
  const planKeys = () => getPlan().plan.map((p) => p.key);
  const planDay = (k) => getPlan().plan.find((p) => p.key === k) || null;
  const exName = (id) => getPlan().exercises[id]?.name || id;
  const sortedWorkouts = () => DB.workouts.filter((w) => planKeys().includes(w.day))
    .sort((a, b) => (a.date + (a.savedAt || "") < b.date + (b.savedAt || "") ? -1 : 1));
  function nextWorkout() {
    const ws = sortedWorkouts(), keys = planKeys();
    return getPlan().plan[ws.length ? (keys.indexOf(ws[ws.length - 1].day) + 1) % keys.length : 0];
  }
  const fmtKg = (w) => (!w ? "PC" : String(+w).replace(".", ","));
  function workoutSummary(w) {
    const p = planDay(w.day);
    return { date: w.date, treino: `${w.day} · ${p ? p.title : ""}`,
      series: w.entries.map((e) => `${exName(e.ex)}: ` + e.sets.map((s) => `${fmtKg(s.w)}×${s.r}`).join(", ")) };
  }
  function saveWorkout(w) {
    DB.workouts = DB.workouts.filter((x) => !(x.day === w.day && x.date === w.date));
    DB.workouts.push(w);
  }

  const exHistory = (id) => sortedWorkouts().flatMap((w) => w.entries.filter((e) => e.ex === id).map((e) => ({ date: w.date, sets: e.sets })));
  function suggest(id, n) {
    const ex = getPlan().exercises[id];
    const [lo, hi] = ex.reps;
    const inc = ex.inc || (ex.name.includes("DB") ? 2 : 2.5);
    const h = exHistory(id);
    if (!h.length) return { meta: `${ex.bw ? "peso corporal" : "carga a escolher"} × ${Math.round(lo + (hi - lo) * 0.4)} reps`, motivo: "primeira vez" };
    const sets = h[h.length - 1].sets.filter((s) => s.r > 0);
    const top = Math.max(0, ...sets.map((s) => s.w || 0));
    const work = sets.filter((s) => (s.w || 0) === top);
    const avg = work.reduce((a, s) => a + s.r, 0) / work.length;
    const last = sets.map((s) => `${fmtKg(s.w)}×${s.r}`).join(" · ");
    if (work.every((s) => s.r >= hi)) return { ultima: last, meta: `${fmtKg(top + inc)} kg × ${Math.max(lo, hi - 3)} reps`, motivo: `bateu ${hi} em tudo: sobe a carga` };
    if (avg < lo - 1 && top > 0) return { ultima: last, meta: `${fmtKg(Math.max(0, top - inc))} kg × ${lo + 1} reps`, motivo: `abaixo de ${lo}: baixa a carga` };
    const reps = Array.from({ length: n }, (_, i) => Math.min(hi, Math.max(lo, work[Math.min(i, work.length - 1)].r + 1)));
    return { ultima: last, meta: `${top ? fmtKg(top) + " kg" : "peso corporal"} × ${reps.join(" · ")}`, motivo: "mesma carga, +1 rep por série" };
  }
  function nextTargets() {
    const d = nextWorkout();
    return { treino: `${d.key} · ${d.title}`, metas: Object.fromEntries(d.ex.map(([e, n]) => [exName(e), suggest(e, n)])) };
  }

  function muscleStats() {
    const plan = getPlan(), days = plan.plan, ex = plan.exercises, n = days.length, out = {};
    for (const [m, label] of Object.entries(plan.muscles)) {
      const direct = days.map((d) => d.ex.reduce((a, [e, s]) => a + (ex[e].p.includes(m) ? s : 0), 0));
      const indirect = days.map((d) => d.ex.reduce((a, [e, s]) => a + ((ex[e].s || []).includes(m) ? s : 0), 0));
      const hit = direct.map((v, i) => (v ? i : -1)).filter((i) => i >= 0);
      const minGap = hit.length > 1 ? Math.min(...hit.map((i, j) => ((hit[(j + 1) % hit.length] - i + n) % n) || n)) : hit.length ? n : null;
      const dates = [...new Set(DB.workouts.filter((w) => w.entries.some((e) => (ex[e.ex]?.p || []).includes(m))).map((w) => w.date))].sort();
      out[label] = { series_por_ciclo: direct.reduce((a, b) => a + b, 0), indiretas_por_ciclo: indirect.reduce((a, b) => a + b, 0),
        treinos: hit.map((i) => days[i].key).join("") || "-", menor_distancia_em_treinos: minGap, ultimo_treino: dates.pop() || null };
    }
    return out;
  }
  function trainingFrequency() {
    const ws = sortedWorkouts(), t = new Date(today() + "T12:00");
    const recent = ws.filter((w) => (t - new Date(w.date + "T12:00")) / 86400000 < 28);
    return { treinos_ultimos_28_dias: recent.length, media_por_semana: round(recent.length / 4, 1), ultimo_treino: ws.length ? ws[ws.length - 1].date : null };
  }

  const SLUG = /^[a-z0-9_]{2,40}$/;
  function cleanDef(d, base) {
    const muscles = getPlan().muscles, out = { ...(base || {}) };
    if (d.name) out.name = String(d.name).slice(0, 60);
    if (Array.isArray(d.reps) && d.reps.length === 2) {
      const [lo, hi] = d.reps.map((x) => Math.trunc(+x)).sort((a, b) => a - b);
      if (lo >= 1 && lo < hi && hi <= 50) out.reps = [lo, hi];
    }
    if (Array.isArray(d.p)) { const p = d.p.filter((m) => m in muscles); if (p.length) out.p = p; }
    if (Array.isArray(d.s)) out.s = d.s.filter((m) => m in muscles && !(out.p || []).includes(m));
    if ("bw" in d) out.bw = !!d.bw;
    if (d.inc) out.inc = Math.max(0.5, Math.min(10, +d.inc));
    if (!out.name || !out.reps || !out.p) throw new Error("definição de exercício incompleta");
    if (!out.s?.length) delete out.s;
    return out;
  }
  const setsN = (v, dflt = 3) => { const n = Math.trunc(+v); return Number.isFinite(n) ? Math.max(1, Math.min(10, n)) : dflt; };

  function applyPlanOps(ops) {
    const plan = getPlan(), before = clone(plan), exs = plan.exercises, done = [];
    for (const op of ops || []) {
      try {
        const kind = op.op, d = op.day ? planDay(op.day) : null, exId = String(op.ex_id || "");
        if (kind === "add_exercise" || kind === "replace_exercise") {
          const newId = kind === "replace_exercise" ? String(op.new_ex_id || exId) : exId;
          if (!SLUG.test(newId) || !d) continue;
          if (!(newId in exs)) exs[newId] = cleanDef(op.def || {});
          else if (op.def) exs[newId] = cleanDef(op.def, exs[newId]);
          if (d.ex.some(([e]) => e === newId)) continue;
          if (kind === "add_exercise") {
            const pos = op.position == null ? d.ex.length : Math.max(0, Math.min(d.ex.length, Math.trunc(+op.position) - 1));
            d.ex.splice(pos, 0, [newId, setsN(op.sets)]);
            done.push(`+ ${exs[newId].name} no Treino ${d.key} (${d.ex[pos][1]} séries)`);
          } else {
            const i = d.ex.findIndex(([e]) => e === exId);
            if (i < 0) continue;
            const sets = setsN(op.sets, d.ex[i][1]);
            done.push(`↔ ${exs[exId].name} → ${exs[newId].name} no Treino ${d.key}`);
            d.ex[i] = [newId, sets];
          }
        } else if (kind === "remove_exercise" && d) {
          if (d.ex.some(([e]) => e === exId)) { d.ex = d.ex.filter(([e]) => e !== exId); done.push(`− ${exName(exId)} saiu do Treino ${d.key}`); }
        } else if (kind === "set_sets" && d) {
          for (const x of d.ex) if (x[0] === exId) { x[1] = setsN(op.sets, x[1]); done.push(`${exName(exId)} no Treino ${d.key}: ${x[1]} séries`); }
        } else if (kind === "move_exercise" && d) {
          const i = d.ex.findIndex(([e]) => e === exId);
          if (i >= 0) {
            const item = d.ex.splice(i, 1)[0];
            const pos = Math.max(0, Math.min(d.ex.length, Math.trunc(+(op.position ?? 1)) - 1));
            d.ex.splice(pos, 0, item);
            done.push(`${exName(exId)} agora é o ${pos + 1}º do Treino ${d.key}`);
          }
        } else if (kind === "edit_exercise" && exs[exId] && op.def) {
          exs[exId] = cleanDef(op.def, exs[exId]);
          done.push(`${exs[exId].name}: faixa ${exs[exId].reps[0]}–${exs[exId].reps[1]} reps`);
        } else if (kind === "rename_day" && d && op.title) {
          d.title = String(op.title).slice(0, 40);
          done.push(`Treino ${d.key} agora se chama “${d.title}”`);
        }
      } catch { /* operação inválida: ignora */ }
    }
    if (done.length) DB.plan_history = [...(DB.plan_history || []), before].slice(-15);
    return done;
  }

  function coachContext() {
    const plan = getPlan(), exs = plan.exercises;
    const used = new Set(plan.plan.flatMap((d) => d.ex.map(([e]) => e)));
    const { plan: _p, ...user } = DB.user;
    return {
      hoje: today(), usuario: user, notas_sobre_usuario: DB.profile, musculos: plan.muscles,
      plano: plan.plan.map((d) => ({ treino: d.key, titulo: d.title, exercicios: d.ex.map(([e, n]) => ({
        id: e, nome: exs[e].name, series: n, faixa: exs[e].reps, principal: exs[e].p, secundario: exs[e].s || [] })) })),
      catalogo_fora_do_plano: Object.fromEntries(Object.entries(exs).filter(([e]) => !used.has(e)).map(([e, v]) => [e, v.name])),
      proximo_treino: nextTargets(), frequencia: trainingFrequency(), musculos_stats: muscleStats(),
      ultimos_treinos: sortedWorkouts().slice(-8).map(workoutSummary),
    };
  }

  /* ---------- estado e contexto da IA ---------- */

  function state(d) {
    const dd = DB.days[d] || { entries: [] };
    return {
      workouts_today: sortedWorkouts().filter((w) => w.date === d).map(workoutSummary),
      date: d, goals: DB.goals, goals_source: DB.goals_source, user: DB.user, user_missing: missingUser(),
      weight: dd.weight ?? null, photos: dd.photos || [], entries: dd.entries, totals: totals(dd.entries),
      chat: DB.chat.slice(-60), profile: DB.profile, pantry: DB.pantry,
    };
  }

  function buildContext(d) {
    const todayEntries = day(d).entries;
    const week = [];
    for (let i = 1; i <= 7; i++) {
      const x = new Date(d + "T12:00");
      x.setDate(x.getDate() - i);
      const dd = isoDate(x), ents = DB.days[dd]?.entries || [];
      if (ents.length) week.push({ date: dd, totals: totals(ents), items: ents.map((e) => e.name) });
    }
    const td = DB.days[today()] || {};
    const weights = Object.entries(DB.days).filter(([, v]) => v.weight).map(([k, v]) => [k, v.weight]).sort().slice(-10);
    const exs = getPlan().exercises, t = totals(todayEntries);
    const agora = new Date();
    return {
      agora: `${today()} ${hhmm()} (${agora.toLocaleDateString("pt-BR", { weekday: "long" })})`,
      dia_aberto_no_app: d, metas: DB.goals, origem_das_metas: goalsOrigin(), usuario: DB.user, perfil_faltando: missingUser(),
      notas_sobre_usuario: DB.profile, despensa: DB.pantry,
      sono: (() => { const s = sleepState(d); return { meta_horas: s.goal, ultima_noite: s.today, media_7_noites: s.avg7 }; })(),
      rotina: { blocos: DB.routine.map((r) => ({ title: r.title, start: r.start, end: r.end, cat: r.cat,
          dias: r.days.every(Boolean) ? "todo dia" : r.days.map((on, i) => (on ? WEEK[i] : null)).filter(Boolean).join(","),
          lembrete: r.remind, despertador: !!r.alarm })),
        despertador: DB.alarm ? `${DB.alarm.time} (${DB.alarm.days.map((on, i) => (on ? WEEK[i] : null)).filter(Boolean).join(", ")})` : null },
      suplementos: {
        horarios: suppSlots().map((sl) => ({ nome: sl.label, hora: sl.time || null })),
        no_dia_aberto: suppToday(d).map((sl) => ({ horario: sl.label, itens: sl.items.map((it) => ({ nome: it.name, dose: it.dose,
          qtd: it.count, tomado: it.taken })) })),
        cadastro: DB.supps.map((x) => ({ nome: x.name, dose: x.dose, forma: x.form,
          agenda_seg_a_dom: Object.fromEntries(Object.entries(x.sched).map(([k, v]) => [slotFind(k)?.label || k, v])),
          ...(x.kcal || x.protein ? { kcal: x.kcal, protein: x.protein } : {}) })),
        seguranca: suppSafety(),
      },
      checkin_hoje: { peso: td.weight ?? null, fotos: (td.photos || []).length,
        pode_perguntar: !td.weight && !td.checkin_asked && !missingUser().length },
      historico_peso: weights,
      treino: {
        proximo: nextTargets(),
        feito_no_dia_aberto: sortedWorkouts().filter((w) => w.date === d).map(workoutSummary),
        ultimos: sortedWorkouts().slice(-6).map(workoutSummary),
        plano: Object.fromEntries(getPlan().plan.map((p) => [p.key, { titulo: p.title, exercicios: Object.fromEntries(
          p.ex.map(([e, n]) => [e, `${exs[e].name} (${n} séries, ${exs[e].reps[0]}-${exs[e].reps[1]} reps)`])) }])),
      },
      registrado_no_dia: todayEntries.map(({ id, name, quantity, meal, kcal, protein, carbs, fat }) => ({ id, name, quantity, meal, kcal, protein, carbs, fat })),
      totais_do_dia: t,
      faltando_para_meta: Object.fromEntries(Object.keys(DB.goals).map((k) => [k, Math.round(DB.goals[k] - t[k])])),
      ultimos_7_dias: week,
    };
  }

  /* ---------- OpenAI ---------- */

  async function openai(path, body, form) {
    if (!CFG.openai_key) throw new ApiError("Sem chave da OpenAI configurada.");
    const r = await fetch("https://api.openai.com/v1" + path, {
      method: "POST",
      headers: form ? { Authorization: "Bearer " + CFG.openai_key } : { Authorization: "Bearer " + CFG.openai_key, "Content-Type": "application/json" },
      body: form || JSON.stringify(body),
    }).catch(() => { throw new ApiError("Sem internet (ou a OpenAI não respondeu)."); });
    if (!r.ok) throw new ApiError(`OpenAI ${r.status}: ${(await r.text()).slice(0, 300)}`);
    return r.json();
  }
  const outputText = (r) => (r.output || []).filter((o) => o.type === "message").flatMap((o) => o.content).map((c) => c.text || "").join("");
  async function askJSON(model, instructions, input, effort = "low") {
    const r = await openai("/responses", { model, instructions, input, text: { format: { type: "json_object" } }, reasoning: { effort }, store: false });
    const out = outputText(r);
    try { return JSON.parse(out); } catch { return { reply: out || "Não entendi, pode repetir?" }; }
  }

  /* ---------- ações do chat da dieta ---------- */

  function applyActions(d, data) {
    const entries = day(d).entries, added = [];
    for (const it of data.add || []) {
      const e = { id: uid(8), name: String(it.name ?? "?"), quantity: String(it.quantity ?? ""), meal: MEALS.includes(it.meal) ? it.meal : "lanche", time: hhmm() };
      for (const k of ["kcal", "protein", "carbs", "fat"]) e[k] = round(fnum(it[k]) || 0, 1);
      entries.push(e);
      added.push(e.id);
    }
    const remove = new Set(data.remove || []);
    if (remove.size) day(d).entries = day(d).entries.filter((e) => !remove.has(e.id));
    for (const up of data.update || []) for (const e of day(d).entries) if (e.id === up.id)
      for (const k of ["name", "quantity", "meal", "kcal", "protein", "carbs", "fat"]) if (up[k] !== undefined && up[k] !== null) e[k] = up[k];
    if (data.goals && typeof data.goals === "object" && Object.keys(DB.goals).some((k) => data.goals[k])) {
      for (const k of Object.keys(DB.goals)) if (data.goals[k]) DB.goals[k] = Math.round(+data.goals[k]);
      DB.goals_source = "manual";
    }
    if (data.profile_note) DB.profile.push(String(data.profile_note));
    pantryUpdate(data.pantry_add, data.pantry_remove);
    if (data.user && typeof data.user === "object") {
      if (data.user.weight_kg && !data.weight_kg && !day(d).weight) data.weight_kg = data.user.weight_kg; // peso do perfil vale pro dia
      setUser(data.user);
    }
    if (fnum(data.weight_kg)) setWeight(d, fnum(data.weight_kg));
    const wl = data.workout_log;
    if (wl && typeof wl === "object" && planKeys().includes(wl.day)) {
      const fresh = {};
      for (const e of wl.entries || []) {
        if (!(e.ex in getPlan().exercises)) continue;
        const sets = (e.sets || []).filter((s) => fnum(s.r) > 0).map((s) => ({ w: round(fnum(s.w) || 0, 2), r: Math.trunc(+s.r) }));
        if (sets.length) fresh[e.ex] = sets;
      }
      if (Object.keys(fresh).length) {
        // junta com o que já foi registrado desse treino no dia (dá pra contar aos poucos)
        const old = DB.workouts.find((w) => w.day === wl.day && w.date === d);
        const merged = { ...Object.fromEntries((old?.entries || []).map((e) => [e.ex, e.sets])), ...fresh };
        const order = planDay(wl.day).ex.map(([e]) => e);
        const ents = Object.keys(merged).sort((a, b) => (order.indexOf(a) + 1 || 99) - (order.indexOf(b) + 1 || 99)).map((ex) => ({ ex, sets: merged[ex] }));
        saveWorkout({ id: `${d}-${wl.day}`, date: d, day: wl.day, entries: ents, savedAt: nowISO() });
        data._workout = wl.day;
      }
    }
    const suppsDone = [];
    for (const sl of data.supp_slot_add || []) {
      const x = slotFind(typeof sl === "string" ? sl : sl?.label, true);
      if (x && sl?.time !== undefined) x.time = hm(sl.time) || "";
      if (x) suppsDone.push(`🕐 Horário ${x.label}${x.time ? " · " + x.time : ""}`);
    }
    for (const it of data.supp_add || []) { const x = suppAdd(it); if (x) suppsDone.push(`+ ${x.name}`); }
    for (const t of data.supp_taken || []) {
      const slotName = typeof t === "object" ? t.slot : null, nm = typeof t === "string" ? t : t?.name;
      const todayList = suppToday(d);
      if (slotName && !nm) {  // "tomei os da manhã"
        const sl = slotFind(slotName);
        const block = sl && todayList.find((y) => y.id === sl.id);
        if (block?.items.length) { block.items.forEach((it) => suppTaken(d, it.id, sl.id, true)); suppsDone.push(`✓ ${sl.label} (${block.items.length})`); }
        continue;
      }
      const x = suppFind(nm) || suppAdd(t);  // "tomei a creatina": aqui a busca aproximada ajuda
      if (!x) continue;
      const sl = slotName ? slotFind(slotName) : null;
      const slots = sl ? [sl.id] : todayList.filter((y) => y.items.some((it) => it.id === x.id && !it.taken)).map((y) => y.id).slice(0, 1);
      for (const sid of slots.length ? slots : [Object.keys(x.sched)[0]]) suppTaken(d, x.id, sid, true);
      suppsDone.push(`✓ ${x.name}`);
    }
    for (const t of data.supp_remove || []) {
      const x = suppFind(typeof t === "string" ? t : t?.name);
      if (x) { DB.supps = DB.supps.filter((y) => y.id !== x.id); suppsDone.push(`− ${x.name}`); }
    }
    if (suppsDone.length) data._supps = suppsDone;
    for (const it of data.routine_add || []) { const r = routineAdd(it); if (r) suppsDone.push(`🗓️ ${r.start}–${r.end} ${r.title}`); }
    for (const t of data.routine_remove || []) {
      const r = DB.routine.find((x) => norm(x.title) === norm(t) || norm(x.title).includes(norm(t)));
      if (r) { DB.routine = DB.routine.filter((x) => x.id !== r.id); suppsDone.push(`− ${r.title}`); }
    }
    if (data.alarm && hm(data.alarm.time)) {
      DB.alarm = { time: hm(data.alarm.time), days: daysMask(data.alarm.days), pending: true };
      // despertador fica ligado ao bloco de sono: ajusta o fim do sono pra hora de acordar
      const sb = DB.routine.find((r) => r.cat === "sono");
      if (sb) { sb.end = DB.alarm.time; sb.alarm = true; }
    }
    if (DB.alarm?.pending && (data.alarm || (data.routine_add || []).some((x) => x.alarm))) suppsDone.push(`⏰ Despertador ${DB.alarm.time}`);
    if (suppsDone.length) data._supps = suppsDone;
    if (data.sleep_log && typeof data.sleep_log === "object") {
      try {
        const sl = sleepSet(data.sleep_log.date || today(), data.sleep_log);
        const h = Math.floor(sl.hours), m = Math.round((sl.hours - h) * 60);
        data._supps = [...(data._supps || []), `😴 Sono: ${h}h${m ? pad(m) : ""}`];
      } catch { /* horário inválido: ignora */ }
    }
    if (data.asked_checkin) day(today()).checkin_asked = true;
    return added;
  }

  /* ---------- rotas ---------- */

  async function chat(b) {
    const d = b.date || today();
    const imgs = (b.images || (b.image ? [b.image] : [])).slice(0, 6)
      .map((x) => (x.startsWith("data:") ? x : `data:image/jpeg;base64,${x}`));
    const img = imgs[0] || null;
    const history = DB.chat.slice(-12).map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.text }));
    const content = [{ type: "input_text", text: b.text || (imgs.length > 1 ? `(${imgs.length} fotos enviadas)` : "(foto enviada)") }];
    for (const u of imgs) content.push({ type: "input_image", image_url: u, detail: imgs.length > 2 ? "auto" : "high" });
    const model = img ? CFG.model_vision : CFG.model_chat;
    const t0 = performance.now();
    const data = await askJSON(model, PROMPTS.chat, [
      { role: "developer", content: "ESTADO ATUAL (responda só com o JSON do formato pedido):\n" + JSON.stringify({ aba_aberta: b.tab || "dieta", ...buildContext(d) }) },
      ...history, { role: "user", content },
    ], imgs.length ? "medium" : "low");
    if (img && data.progress_photo) { data.add = []; for (const u of imgs) await savePhoto(d, u); }
    const gBefore = { ...DB.goals }, srcBefore = DB.goals_source;
    const added = applyActions(d, data);
    const g = DB.goals;
    if (DB.goals_source === "auto" && (srcBefore !== "auto" || Math.abs(g.kcal - gBefore.kcal) >= 50))
      data.reply = `${data.reply || ""}\n\n🎯 Metas novas: ${g.kcal} kcal · ${g.protein} g de proteína por dia.`.trim();
    const now = nowISO();
    DB.chat.push({ role: "user", text: b.text || (imgs.length > 1 ? `📷 ${imgs.length} fotos` : "📷 foto"), ts: now, date: d, photo: imgs.length });
    DB.chat.push({ role: "momo", text: data.reply || "", ts: now, date: d, added, model, workout: data._workout || null, supps: data._supps || null });
    DB.chat = DB.chat.slice(-300);
    await save();
    return { ...state(d), meta: { model, secs: round((performance.now() - t0) / 1000, 1) } };
  }

  async function onboarding(a) {
    DB.user = {};
    DB.goals_source = "auto";
    setUser(a);
    for (const k of EXTRA_FIELDS) if (a[k] !== undefined && a[k] !== null && a[k] !== "" && !(Array.isArray(a[k]) && !a[k].length)) DB.user[k] = a[k];
    if (missingUser().length) throw new ApiError("Faltam dados: " + missingUser().join(", "));
    const u = DB.user, base = calcGoals(u, true);
    const data = await askJSON(CFG.model_chat, PROMPTS.onboard, [{ role: "user", content: "Responda só com o JSON pedido.\n" + JSON.stringify({ respostas: u, calculo_base: base }) }]);
    const p = data.plan || {}, dp = defaultPlan(u);
    DB.user = { ...u, plan: {
      kcal_adjust: Math.round(clamp(p.kcal_adjust, -1000, 600, dp.kcal_adjust)),
      protein_g_kg: round(clamp(p.protein_g_kg, 1.4, 2.4, dp.protein_g_kg), 2),
      fat_g_kg: round(clamp(p.fat_g_kg, 0.6, 1.2, dp.fat_g_kg), 2),
      why: String(p.why || ""),
    } };
    DB.goals_source = "auto";
    const g = (DB.goals = calcGoals(DB.user));
    day(today()).weight = DB.user.weight_kg;
    DB.profile = (data.notes || []).filter(Boolean).map(String);
    DB.pantry = [];
    pantryUpdate(data.pantry);
    const reply = `${(data.reply || "Pronto, perfil criado!").trim()}\n\n🎯 Suas metas: ${g.kcal} kcal · ${g.protein} g de proteína por dia.`;
    DB.chat.push({ role: "momo", text: reply, ts: nowISO(), date: today(), added: [], model: CFG.model_chat });
    await save();
    return state(today());
  }

  const planState = () => ({ plan: getPlan(), coach_chat: DB.coach_chat.slice(-60), can_undo: !!(DB.plan_history || []).length });

  async function coach(b) {
    const history = DB.coach_chat.slice(-12).map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.text }));
    const t0 = performance.now();
    const data = await askJSON(CFG.model_chat, PROMPTS.coach, [
      { role: "developer", content: "ESTADO DO TREINO (responda só com o JSON pedido):\n" + JSON.stringify(coachContext()) },
      ...history, { role: "user", content: b.text },
    ], "medium");
    const changes = applyPlanOps(data.plan_ops);
    if (data.profile_note) DB.profile.push(String(data.profile_note));
    const now = nowISO();
    DB.coach_chat.push({ role: "user", text: b.text, ts: now });
    DB.coach_chat.push({ role: "momo", text: data.reply || "", ts: now, changes, secs: round((performance.now() - t0) / 1000, 1) });
    DB.coach_chat = DB.coach_chat.slice(-200);
    await save();
    return planState();
  }

  async function transcribe(form) {
    const f = new FormData();
    f.append("model", CFG.model_transcribe);
    f.append("language", "pt");
    f.append("file", form.get("file"), "fala.webm");
    return { text: (await openai("/audio/transcriptions", null, f)).text || "" };
  }

  // tabela de rotas: [método, regex do caminho, handler(params, query, body)]
  const ROUTES = [
    ["GET", /^\/api\/state$/, (p, q) => state(q.get("date") || today())],
    ["POST", /^\/api\/chat$/, (p, q, b) => chat(b)],
    ["DELETE", /^\/api\/chat$/, async () => { DB.chat = []; await save(); return { ok: true }; }],
    ["POST", /^\/api\/transcribe$/, (p, q, b) => transcribe(b)],
    ["PUT", /^\/api\/entry\/([^/]+)\/([^/]+)$/, async ([d, id], q, up) => {
      const e = day(d).entries.find((x) => x.id === id);
      if (!e) throw new ApiError("item não encontrado");
      if (up.name) e.name = String(up.name).slice(0, 80);
      if (up.quantity !== undefined) e.quantity = String(up.quantity).slice(0, 40);
      if (MEALS.includes(up.meal)) e.meal = up.meal;
      for (const k of ["kcal", "protein", "carbs", "fat"]) if (fnum(up[k]) !== null) e[k] = round(Math.max(0, fnum(up[k])), 1);
      e.edited = true;
      await save(); return state(d);
    }],
    ["DELETE", /^\/api\/entry\/([^/]+)\/([^/]+)$/, async ([d, id]) => { day(d).entries = day(d).entries.filter((e) => e.id !== id); await save(); return state(d); }],
    ["PUT", /^\/api\/goals$/, async (p, q, g) => {
      DB.goals = Object.fromEntries(["kcal", "protein", "carbs", "fat"].map((k) => [k, Math.round(+g[k] || 0)]));
      DB.goals_source = "manual"; await save(); return DB.goals;
    }],
    ["PUT", /^\/api\/user$/, async (p, q, u) => {
      if (u.weight_kg && u.weight_kg !== DB.user.weight_kg) setWeight(today(), u.weight_kg);
      if (u.recalc) DB.goals_source = "auto";
      setUser(u); await save(); return state(q.get("date") || today());
    }],
    ["DELETE", /^\/api\/user$/, async () => {
      DB.user = {}; DB.profile = []; DB.goals = { ...DEFAULT_GOALS }; DB.goals_source = "default"; await save(); return state(today());
    }],
    ["POST", /^\/api\/onboarding$/, (p, q, b) => onboarding(b)],
    ["POST", /^\/api\/pantry$/, async (p, q, b) => { pantryUpdate(b.add, b.remove); await save(); return state(q.get("date") || today()); }],
    ["GET", /^\/api\/plan$/, () => planState()],
    ["GET", /^\/api\/routine$/, (p, q) => routineState(q.get("date") || today())],
    ["POST", /^\/api\/routine$/, async (p, q, b) => {
      if (!routineAdd(b)) throw new ApiError("Coloca o nome e o horário");
      await save(); return routineState(q.get("date") || today());
    }],
    ["DELETE", /^\/api\/routine\/([^/]+)$/, async ([id], q) => {
      if (DB.alarm?.block === id) DB.alarm = null;
      DB.routine = DB.routine.filter((x) => x.id !== id); await save(); return routineState(q.get("date") || today());
    }],
    ["PUT", /^\/api\/alarm$/, async (p, q, b) => {
      DB.alarm = b.time ? { time: hm(b.time), days: daysMask(b.days), pending: !!b.pending, block: b.block } : null;
      await save(); return routineState(q.get("date") || today());
    }],
    ["GET", /^\/api\/sleep$/, (p, q) => sleepState(q.get("date") || today())],
    ["PUT", /^\/api\/sleep\/([^/]+)$/, async ([d], q, b) => {
      if (b.clear) delete day(d).sleep; else sleepSet(d, b);
      await save(); return sleepState(d);
    }],
    ["PUT", /^\/api\/sleep-goal$/, async (p, q, b) => {
      DB.sleep_goal = Math.max(4, Math.min(12, +b.goal || 8)); await save(); return sleepState(q.get("date") || today());
    }],
    ["GET", /^\/api\/supps$/, (p, q) => suppState(q.get("date") || today())],
    ["POST", /^\/api\/supps$/, async (p, q, b) => {
      const x = b.id ? DB.supps.find((y) => y.id === b.id) : null;
      if (x && b.name) x.name = String(b.name).trim().slice(0, 40);
      suppAdd({ ...b, name: x ? x.name : b.name });
      await save(); return suppState(q.get("date") || today());
    }],
    ["DELETE", /^\/api\/supps\/([^/]+)$/, async ([id], q) => { DB.supps = DB.supps.filter((x) => x.id !== id); await save(); return suppState(q.get("date") || today()); }],
    ["POST", /^\/api\/supps\/([^/]+)\/([^/]+)$/, async ([d, id], q, b) => {
      // id = suplemento, ou "slot:<id>" pra marcar o horário inteiro
      if (id.startsWith("slot:")) {
        const sid = id.slice(5), block = suppToday(d).find((y) => y.id === sid);
        for (const it of block?.items || []) suppTaken(d, it.id, sid, !!b.taken);
      } else suppTaken(d, id, b.slot, !!b.taken);
      await save(); return suppState(d);
    }],
    ["POST", /^\/api\/supp-slots$/, async (p, q, b) => {
      const sl = b.id ? suppSlots().find((y) => y.id === b.id) : slotFind(b.label, true);
      if (sl) { if (b.label) sl.label = String(b.label).trim().slice(0, 24); sl.time = hm(b.time) || ""; }
      await save(); return suppState(q.get("date") || today());
    }],
    ["DELETE", /^\/api\/supp-slots\/([^/]+)$/, async ([id], q) => {
      DB.supp_slots = suppSlots().filter((y) => y.id !== id);
      for (const x of DB.supps) delete x.sched[id];
      await save(); return suppState(q.get("date") || today());
    }],
    ["POST", /^\/api\/coach$/, (p, q, b) => coach(b)],
    ["POST", /^\/api\/coach\/undo$/, async () => {
      const hist = DB.plan_history || [];
      if (hist.length) {
        DB.plan = hist.pop();
        const m = [...DB.coach_chat].reverse().find((x) => x.changes?.length && !x.undone);
        if (m) m.undone = true;
        DB.coach_chat.push({ role: "momo", text: "Desfeito, o plano voltou como estava. ↩", ts: nowISO() });
        await save();
      }
      return planState();
    }],
    ["DELETE", /^\/api\/coach$/, async () => { DB.coach_chat = []; await save(); return planState(); }],
    ["GET", /^\/api\/workouts$/, () => ({ sessions: DB.workouts })],
    ["PUT", /^\/api\/workouts$/, async (p, q, w) => {
      if (!planKeys().includes(w.day) || !w.date || !Array.isArray(w.entries)) throw new ApiError("treino inválido");
      saveWorkout({ ...w, id: `${w.date}-${w.day}`, savedAt: nowISO() }); await save(); return { sessions: DB.workouts };
    }],
    ["DELETE", /^\/api\/workouts\/([^/]+)$/, async ([id]) => { DB.workouts = DB.workouts.filter((w) => w.id !== id); await save(); return { sessions: DB.workouts }; }],
    ["PUT", /^\/api\/weight\/([^/]+)$/, async ([d], q, b) => {
      if (fnum(b.weight)) setWeight(d, fnum(b.weight)); else delete day(d).weight;
      await save(); return state(d);
    }],
    ["POST", /^\/api\/photo\/([^/]+)$/, async ([d], q, b) => { await savePhoto(d, b.image); await save(); return state(d); }],
    ["DELETE", /^\/api\/photo\/([^/]+)\/([^/]+)$/, async ([d, name]) => {
      const ph = day(d).photos || [];
      if (ph.includes(name)) {
        day(d).photos = ph.filter((x) => x !== name);
        await photoDel(name);
        if (photoURLs.has(name)) { URL.revokeObjectURL(photoURLs.get(name)); photoURLs.delete(name); }
      }
      await save(); return state(d);
    }],
    ["GET", /^\/api\/calendar$/, (p, q) => {
      const month = q.get("month") || "", out = {};
      for (const [d, v] of Object.entries(DB.days)) if (d.startsWith(month) && (v.entries?.length || v.weight || v.photos?.length))
        out[d] = { kcal: totals(v.entries || []).kcal, n: (v.entries || []).length, weight: v.weight ?? null, photos: (v.photos || []).length };
      for (const w of DB.workouts) if (w.date.startsWith(month)) (out[w.date] = out[w.date] || { kcal: 0, n: 0, weight: null, photos: 0 }).workout = w.day;
      return { month, goal: DB.goals.kcal, days: out };
    }],
    ["GET", /^\/api\/progress$/, () => ({ days: Object.keys(DB.days).sort().filter((d) => DB.days[d].weight || DB.days[d].photos?.length)
      .map((d) => ({ date: d, weight: DB.days[d].weight ?? null, photos: DB.days[d].photos || [], kcal: totals(DB.days[d].entries || []).kcal })) })],
  ];

  let ready = null;
  async function request(path, opts = {}) {
    ready = ready || init();
    await ready;
    const url = new URL(path, "http://x");
    const method = (opts.method || "GET").toUpperCase();
    let body = opts.body;
    if (typeof body === "string") body = JSON.parse(body);
    for (const [m, re, fn] of ROUTES) {
      const match = method === m && url.pathname.match(re);
      if (match) return clone(await fn(match.slice(1).map(decodeURIComponent), url.searchParams, body || {}));
    }
    throw new ApiError(`rota não encontrada: ${method} ${url.pathname}`);
  }

  return {
    request,
    ready: () => (ready = ready || init()),
    photoURL: (name) => photoURLs.get(name) || "",
  };
})();
