window.MOMO_BUILD = {"version": "2026.10.13.0743", "updates": "https://raw.githubusercontent.com/victorguima12/momo-fit/main"};
