// Aba Suplementos: horários da pessoa (Manhã, Noite, Shake...), o que tomar hoje em cada um,
// a agenda da semana, o checklist e a checagem de segurança das doses.
// Também dá pra fazer tudo conversando com o Momo na Dieta (inclusive mandar print da planilha).

(() => {
  const DAYS = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"];
  const FORM = { caps: "cápsula", po: "pó", outro: "" };
  const icon = (label) => /manh/i.test(label) ? "☀️" : /noite|dorm/i.test(label) ? "🌙" : /tarde/i.test(label) ? "🌤️"
    : /shake|p[oó]/i.test(label) ? "🥤" : /treino/i.test(label) ? "⚡" : "🕐";
  const root = () => $("#viewSupps");
  let st = null, editing = null, editingSlot = null;

  async function show() {
    st = await api(`/api/supps?date=${todayISO()}`);
    render();
  }
  const post = async (path, body, method = "POST") => { st = await api(path, { method, body: body ? JSON.stringify(body) : undefined }); render(); };
  const unitTxt = (it) => it.form === "caps" ? `${it.count} ${it.count === 1 ? "cáps" : "cáps"}${it.dose ? " · " + it.dose : ""}`
    : `${it.count > 1 ? it.count + "× " : ""}${it.dose || ""}`;

  function render() {
    const el = root();
    const due = st.today.flatMap((sl) => sl.items), done = due.filter((it) => it.taken).length;
    const wd = DAYS[st.weekday];
    let h = "";

    if (!st.supps.length && !editing) {
      h += `<section class="card sp-empty">
        <h4>Seus suplementos</h4>
        <p class="muted small">Cadastre o que você toma e em que horário. Cada dia da semana pode ter quantidades diferentes
          (ex.: vitamina D 2 cápsulas na seg, 1 na ter...).</p>
        <p class="small">💬 Atalho: manda um <b>print da sua planilha</b> pro Momo na Dieta, ou fala "tomo creatina 5 g todo dia de manhã".</p>
        <button class="btn wide" id="spNew">+ Adicionar suplemento</button>
      </section>`;
    } else {
      // ---- hoje ----
      h += `<section class="card sp-head">
        <div class="sp-head-top"><div><h4>Hoje · ${wd}</h4>
          <div class="muted small">${due.length ? (done === due.length ? "Tudo tomado ✅" : `${done} de ${due.length} tomados`) : "Nada programado pra hoje"}</div></div>
          <div class="sp-adh" title="últimos 7 dias">${st.adherence.map((a) => {
            const f = a.due ? a.done / a.due : null;
            return `<i class="${f === null ? "none" : f >= 1 ? "full" : f > 0 ? "part" : ""}" title="${a.date}"></i>`;
          }).join("")}</div></div>
        ${due.length ? `<div class="bar sp-bar"><i style="width:${(done / due.length) * 100}%"></i></div>` : ""}
      </section>`;
      for (const sl of st.today) {
        if (!sl.items.length) continue;
        const all = sl.items.every((it) => it.taken);
        const caps = sl.items.filter((it) => it.form === "caps").reduce((a, it) => a + it.count, 0);
        h += `<section class="card sp-slot ${all ? "done" : ""}">
          <div class="sp-slot-head"><b>${icon(sl.label)} ${esc(sl.label)}</b>
            <span class="muted small">${sl.time ? sl.time + " · " : ""}${caps ? caps + " cápsulas" : sl.items.length + " itens"}</span>
            <button class="btn sm ${all ? "ghost" : ""}" data-slot="${sl.id}" data-all="${all ? 0 : 1}">${all ? "✓ Tomado" : "Tomar todos"}</button></div>
          ${sl.items.map((it) => `<div class="sp-row ${it.taken ? "on" : ""}" data-id="${it.id}" data-slot="${sl.id}">
              <span class="sp-check">${it.taken ? "✓" : ""}</span>
              <span class="sp-name">${esc(it.name)}</span><span class="sp-qty">${esc(unitTxt(it))}</span></div>`).join("")}
        </section>`;
      }

      // ---- semana ----
      const slots = st.slots;
      h += `<section class="card"><h4>Sua semana</h4>
        <div class="muted small sp-legend">${slots.map((s, k) => `<span class="c c${k % 4}">●</span> ${esc(s.label)}`).join(" &nbsp; ")}</div>
        <div class="sp-table"><table><thead><tr><th></th>${DAYS.map((d, i) => `<th class="${i === st.weekday ? "cur" : ""}">${d}</th>`).join("")}<th>sem</th></tr></thead><tbody>
        ${st.supps.map((x) => `<tr data-id="${x.id}"><th>${esc(x.name)}<small>${esc(x.dose || "")}</small></th>${DAYS.map((_, i) => {
          // só os horários com dose, cada um na sua cor (como as colunas AM/PM da planilha)
          const v = slots.map((s, k) => [k, x.sched[s.id]?.[i] || 0]).filter(([, n]) => n);
          return `<td class="${i === st.weekday ? "cur" : ""}">${v.map(([k, n]) => `<span class="c c${k % 4}">${n}</span>`).join("")}</td>`;
        }).join("")}<td class="tot">${x.week_caps}</td></tr>`).join("")}
        </tbody></table></div>
        <div class="row-btns"><button class="btn ghost sm" id="spNew">+ Suplemento</button><button class="btn ghost sm" id="spNewSlot">+ Horário</button></div>
        <div class="sp-slots">${slots.map((s) => `<button class="pchip" data-editslot="${s.id}">${icon(s.label)} ${esc(s.label)}${s.time ? " · " + s.time : ""} ✎</button>`).join("")}</div>
        <div class="muted small">Toque num suplemento da tabela pra editar.</div>
      </section>`;

      // ---- segurança ----
      if (st.safety.length) {
        h += `<section class="card"><h4>Segurança das doses</h4>
          <div class="muted small" style="margin-bottom:8px">Média por dia na semana × limite diário seguro pra adultos.</div>
          ${st.safety.map((s) => `<div class="sp-safe">
            <span>${esc(s.label)}</span>
            <span class="v">${s.avg.toLocaleString("pt-BR")} <span class="muted">/ ${s.max.toLocaleString("pt-BR")} ${s.unit}</span></span>
            <span class="pill ${s.status === "ok" ? "good" : s.status === "picos" ? "mid" : "bad"}">${s.status === "ok" ? "OK" : s.status === "picos" ? "picos" : "acima"}</span>
            ${s.over.length ? `<div class="muted small sp-over">Passa do limite na ${s.over.join(", ")} (pico ${s.peak.toLocaleString("pt-BR")} ${s.unit})${s.status === "picos" ? ", mas a média da semana está ok." : "."}</div>` : ""}
          </div>`).join("")}
          <div class="muted small" style="margin-top:6px">Referência geral, não substitui orientação médica.</div>
        </section>`;
      }
    }

    // ---- editores ----
    if (editing) h += editorHTML();
    if (editingSlot) h += slotEditorHTML();
    el.innerHTML = h;
    bind();
  }

  function editorHTML() {
    const x = editing, slots = st.slots;
    return `<section class="card sp-editor" id="spEditor">
      <h4>${x.id ? "Editar" : "Novo"} suplemento</h4>
      <form id="spForm" class="sp-form">
        <input name="name" placeholder="Nome (ex.: Vitamina D3 + K2)" value="${esc(x.name || "")}" required>
        <div class="sp-2"><input name="dose" placeholder="Dose por unidade (ex.: 2000 UI)" value="${esc(x.dose || "")}">
          <select name="form">${Object.entries({ caps: "Cápsula", po: "Pó", outro: "Outro" }).map(([k, v]) => `<option value="${k}" ${x.form === k ? "selected" : ""}>${v}</option>`).join("")}</select></div>
        ${slots.map((s) => `<div class="sp-sched" data-slot="${s.id}">
          <div class="sp-sched-head"><b>${icon(s.label)} ${esc(s.label)}</b>
            <button type="button" class="muted small" data-fill="1">todo dia 1</button><button type="button" class="muted small" data-fill="0">limpar</button></div>
          <div class="sp-days">${DAYS.map((d, i) => `<label><span>${d}</span><input inputmode="numeric" data-i="${i}" value="${x.sched?.[s.id]?.[i] || ""}" placeholder="0"></label>`).join("")}</div>
        </div>`).join("")}
        <details ${x.kcal || x.protein ? "open" : ""}><summary class="muted small">Tem calorias? (whey, colágeno…) — entra na Dieta quando tomar</summary>
          <div class="entry-macros">${["kcal", "protein", "carbs", "fat"].map((k) => `<label><span>${{ kcal: "kcal", protein: "Proteína", carbs: "Carbo", fat: "Gordura" }[k]}</span><input name="${k}" inputmode="decimal" value="${x[k] ?? ""}"></label>`).join("")}</div>
        </details>
        <div class="row-btns">
          ${x.id ? `<button type="button" class="btn ghost danger" id="spDel">Apagar</button>` : ""}
          <button type="button" class="btn ghost" id="spCancel">Cancelar</button>
          <button class="btn" type="submit">Salvar</button>
        </div>
      </form></section>`;
  }

  function slotEditorHTML() {
    const s = editingSlot;
    return `<section class="card sp-editor" id="spSlotEditor"><h4>${s.id ? "Editar" : "Novo"} horário</h4>
      <form id="spSlotForm" class="sp-form">
        <div class="sp-2"><input name="label" placeholder="Nome (ex.: Tarde, Shake, Pré-treino)" value="${esc(s.label || "")}" required>
          <input name="time" type="time" value="${esc(s.time || "")}"></div>
        <div class="row-btns">
          ${s.id ? `<button type="button" class="btn ghost danger" id="slDel">Apagar</button>` : ""}
          <button type="button" class="btn ghost" id="slCancel">Cancelar</button><button class="btn" type="submit">Salvar</button>
        </div>
      </form></section>`;
  }

  function bind() {
    const el = root(), d = todayISO();
    el.querySelectorAll(".sp-row").forEach((row) => (row.onclick = () => {
      navigator.vibrate?.(10);
      const on = !row.classList.contains("on");
      post(`/api/supps/${d}/${row.dataset.id}`, { slot: row.dataset.slot, taken: on }).then(allDoneToast);
    }));
    el.querySelectorAll("[data-all]").forEach((b) => (b.onclick = () => {
      navigator.vibrate?.(15);
      post(`/api/supps/${d}/slot:${b.dataset.slot}`, { taken: b.dataset.all === "1" }).then(allDoneToast);
    }));
    el.querySelectorAll(".sp-table tr[data-id]").forEach((tr) => (tr.onclick = () => openEditor(st.supps.find((x) => x.id === tr.dataset.id))));
    el.querySelectorAll("[data-editslot]").forEach((b) => (b.onclick = () => { editingSlot = st.slots.find((s) => s.id === b.dataset.editslot); editing = null; render(); scrollTo("#spSlotEditor"); }));
    el.querySelectorAll("#spNew").forEach((b) => (b.onclick = () => openEditor({ form: "caps", sched: {} })));
    el.querySelector("#spNewSlot")?.addEventListener("click", () => { editingSlot = { label: "", time: "" }; editing = null; render(); scrollTo("#spSlotEditor"); });

    const f = $("#spForm");
    if (f) {
      f.querySelectorAll("[data-fill]").forEach((b) => (b.onclick = () => {
        b.closest(".sp-sched").querySelectorAll("input").forEach((i) => (i.value = b.dataset.fill === "1" ? 1 : ""));
      }));
      f.onsubmit = async (e) => {
        e.preventDefault();
        const sched = {};
        f.querySelectorAll(".sp-sched").forEach((box) => {
          const v = [...box.querySelectorAll("input")].map((i) => +i.value || 0);
          if (v.some(Boolean)) sched[box.dataset.slot] = v;
        });
        if (!Object.keys(sched).length) return toast("Coloca em pelo menos um dia/horário");
        const body = { id: editing.id, name: f.elements.name.value.trim(), dose: f.elements.dose.value.trim(), form: f.elements.form.value, sched };
        for (const k of ["kcal", "protein", "carbs", "fat"]) body[k] = f.elements[k].value === "" ? null : parseFloat(f.elements[k].value.replace(",", "."));
        editing = null;
        await post(`/api/supps?date=${d}`, body);
        toast("Suplemento salvo");
      };
      $("#spCancel").onclick = () => { editing = null; render(); };
      $("#spDel")?.addEventListener("click", async () => {
        if (!confirm(`Apagar ${editing.name}?`)) return;
        const id = editing.id;
        editing = null;
        await post(`/api/supps/${id}?date=${d}`, null, "DELETE");
      });
    }
    const sf = $("#spSlotForm");
    if (sf) {
      sf.onsubmit = async (e) => {
        e.preventDefault();
        const body = { id: editingSlot.id, label: sf.elements.label.value.trim(), time: sf.elements.time.value };
        editingSlot = null;
        await post(`/api/supp-slots?date=${d}`, body);
      };
      $("#slCancel").onclick = () => { editingSlot = null; render(); };
      $("#slDel")?.addEventListener("click", async () => {
        if (!confirm(`Apagar o horário ${editingSlot.label}? Os suplementos dele saem desse horário.`)) return;
        const id = editingSlot.id;
        editingSlot = null;
        await post(`/api/supp-slots/${id}?date=${d}`, null, "DELETE");
      });
    }
  }

  function openEditor(x) { editing = JSON.parse(JSON.stringify(x)); editingSlot = null; render(); scrollTo("#spEditor"); }
  function scrollTo(sel) { requestAnimationFrame(() => $(sel)?.scrollIntoView({ behavior: "smooth", block: "start" })); }
  function allDoneToast() {
    const due = st.today.flatMap((sl) => sl.items);
    if (due.length && due.every((it) => it.taken)) toast("Todos os suplementos de hoje ✅");
  }

  window.Supps = { show };
})();
