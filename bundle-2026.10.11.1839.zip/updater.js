// Atualização automática (OTA) do código do app, sem reinstalar o APK.
// Ao abrir: confirma que esta versão funciona (ready), procura latest.json no repositório de atualizações,
// baixa a versão nova em segundo plano e oferece aplicar. Se uma versão nova não chegar ao ready() em 10 s,
// o plugin volta sozinho pra anterior. Os dados (IndexedDB) não são tocados.

(() => {
  const C = window.Capacitor;
  const BUILD = window.MOMO_BUILD || {};
  if (!C?.isNativePlatform?.() || !C.Plugins?.LiveUpdate) return;
  const LU = C.Plugins.LiveUpdate;
  const base = (BUILD.updates || "").replace(/\/$/, "");

  async function start() {
    // APK novo instalado por cima: volta pro código que veio dentro dele (pode ser mais novo que o baixado)
    const { versionCode } = await LU.getVersionCode();
    if (localStorage.getItem("momo.versionCode") !== String(versionCode)) {
      localStorage.setItem("momo.versionCode", String(versionCode));
      const { bundleId } = await LU.getCurrentBundle();
      if (bundleId) { await LU.reset(); await LU.reload(); return; }
    }
    await Backend.ready();  // o app abriu e leu os dados: esta versão está boa
    await LU.ready();
    if (base) check().catch((e) => console.warn("atualização:", e));
  }

  async function check() {
    const r = await C.Plugins.CapacitorHttp.get({ url: `${base}/latest.json?t=${Date.now()}`, responseType: "json" });
    const latest = typeof r.data === "string" ? JSON.parse(r.data) : r.data;
    if (!latest?.version || latest.version <= (BUILD.version || "")) return;
    const { bundleIds } = await LU.getBundles();
    if (!bundleIds.includes(latest.version)) {
      await LU.downloadBundle({ url: latest.url, bundleId: latest.version, artifactType: "zip" });
    }
    await LU.setNextBundle({ bundleId: latest.version }); // aplica no próximo início, ou já se tocar no aviso
    offer(latest);
  }

  function offer(latest) {
    const bar = document.createElement("button");
    bar.className = "update-bar";
    bar.innerHTML = `<b>✨ Atualização pronta</b><span>${latest.notes ? String(latest.notes).replace(/[<>&]/g, "") : "Toque pra aplicar"}</span>`;
    bar.onclick = () => { bar.textContent = "Aplicando…"; LU.reload(); };
    document.body.appendChild(bar);
  }

  start().catch((e) => console.warn("atualizador:", e));
})();
