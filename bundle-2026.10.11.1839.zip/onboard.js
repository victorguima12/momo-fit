// Questionário inicial: uma pergunta por tela; no fim a IA monta o plano e as metas.

const OB_STEPS = [
  { k: "name", q: "Oi! Eu sou o Momo 👋\nComo posso te chamar?", type: "text", optional: true, placeholder: "Seu nome" },
  { k: "sex", q: "Qual seu sexo biológico?", hint: "Entra na conta do seu metabolismo.", type: "choice",
    options: [["M", "Masculino"], ["F", "Feminino"]] },
  { k: "age", q: "Quantos anos você tem?", type: "number", unit: "anos", min: 12, max: 100 },
  { k: "height_cm", q: "Qual sua altura?", type: "number", unit: "cm", min: 120, max: 230, placeholder: "169",
    parse: (v) => (v < 3 ? v * 100 : v) }, // aceita "1,69"
  { k: "weight_kg", q: "Quanto você pesa hoje?", type: "number", unit: "kg", min: 30, max: 300, step: 0.1, placeholder: "70" },
  { k: "objective", q: "Qual seu objetivo?", type: "choice", options: [
    ["perder", "Perder peso", "queimar gordura"],
    ["manter", "Manter", "comer melhor, recomposição"],
    ["ganhar", "Ganhar massa", "hipertrofia"]] },
  { k: "target_kg", q: "Tem um peso-meta?", hint: "Me ajuda a estimar o tempo.", type: "number", unit: "kg", step: 0.1,
    min: 30, max: 300, optional: true, when: (a) => a.objective !== "manter" },
  { k: "pace", q: "Em que ritmo?", type: "choice", when: (a) => a.objective !== "manter", options: [
    ["tranquilo", "Tranquilo", "mais fácil de sustentar"],
    ["moderado", "Moderado", "o equilíbrio (recomendado)"],
    ["acelerado", "Acelerado", "mais rápido, mais fome"]] },
  { k: "activity", q: "Quanto você se movimenta?", hint: "Contando treino + dia a dia.", type: "choice", options: [
    ["sedentario", "Sedentário", "trabalho sentado, quase não treino"],
    ["leve", "Leve", "treino 1 a 3x por semana"],
    ["moderado", "Moderado", "treino 3 a 5x por semana"],
    ["intenso", "Intenso", "treino 6 a 7x ou trabalho físico"]] },
  { k: "training", q: "Que tipo de treino você faz?", type: "text", optional: true,
    placeholder: "Ex.: musculação 4x, corrida no domingo" },
  { k: "diet", q: "Alguma restrição ou preferência?", type: "multi", optional: true,
    options: ["Vegetariano", "Vegano", "Sem lactose", "Sem glúten", "Low carb", "Não gosto de peixe"],
    placeholder: "Outra? Escreve aqui" },
  { k: "despensa", q: "O que você costuma ter em casa?", hint: "Assim eu só sugiro o que dá pra fazer de verdade.",
    type: "multi", optional: true,
    options: ["Ovo", "Frango", "Carne", "Atum", "Leite", "Iogurte", "Queijo", "Whey", "Pão", "Arroz", "Feijão",
      "Aveia", "Macarrão", "Batata", "Banana", "Frutas", "Legumes"],
    placeholder: "Mais alguma coisa? (ex.: sucrilhos, pasta de amendoim)" },
  { k: "routine", q: "Algo mais que eu deva saber?", type: "textarea", optional: true,
    placeholder: "Horários, quantas refeições faz, o que costuma comer, onde acha mais difícil…" },
];

let ob = null; // { answers, i }

function startOnboarding(prefill = {}) {
  ob = { answers: { ...prefill }, i: 0 };
  let el = $("#onboard");
  if (!el) {
    el = document.createElement("div");
    el.id = "onboard";
    document.body.appendChild(el);
  }
  el.classList.remove("hidden");
  obRender();
}
window.startOnboarding = startOnboarding;

const obVisible = () => OB_STEPS.filter((s) => !s.when || s.when(ob.answers));

function obRender() {
  const steps = obVisible();
  const st = steps[ob.i];
  const el = $("#onboard");
  const v = ob.answers[st.k];
  let body = "";
  if (st.type === "choice") {
    body = `<div class="ob-opts">${st.options.map(([val, label, sub]) =>
      `<button class="ob-opt${v === val ? " on" : ""}" data-v="${val}"><b>${label}</b>${sub ? `<span>${sub}</span>` : ""}</button>`).join("")}</div>`;
  } else if (st.type === "multi") {
    const sel = v?.chips || [];
    body = `<div class="ob-chips">${st.options.map((o) =>
      `<button class="ob-chip${sel.includes(o) ? " on" : ""}">${o}</button>`).join("")}</div>
      <input class="ob-input" id="obText" type="text" placeholder="${st.placeholder}" value="${esc(v?.text || "")}">`;
  } else if (st.type === "textarea") {
    body = `<textarea class="ob-input" id="obText" rows="4" placeholder="${st.placeholder}">${esc(v || "")}</textarea>`;
  } else {
    const num = st.type === "number";
    body = `<div class="ob-field"><input class="ob-input${num ? " num" : ""}" id="obText"
      type="text" ${num ? `inputmode="decimal"` : ""}
      placeholder="${st.placeholder || ""}" value="${esc(v ?? "")}">${st.unit ? `<span>${st.unit}</span>` : ""}</div>`;
  }
  const needsNext = st.type !== "choice";
  el.innerHTML = `<div class="ob-top">
      <button class="icon-btn" id="obBack" aria-label="Voltar">‹</button>
      <div class="ob-bar"><i style="width:${(ob.i / steps.length) * 100}%"></i></div>
      <button class="ob-skip" id="obLater">${ob.i === 0 ? "Agora não" : ""}</button>
    </div>
    <div class="ob-body">
      <h2>${esc(st.q).replace(/\n/g, "<br>")}</h2>
      ${st.hint ? `<p class="muted">${st.hint}</p>` : ""}
      ${body}
      <div class="ob-err" id="obErr"></div>
    </div>
    <div class="ob-foot">
      ${st.optional ? `<button class="btn ghost" id="obSkip">Pular</button>` : ""}
      ${needsNext ? `<button class="btn" id="obNext">Continuar</button>` : ""}
    </div>`;

  $("#obBack").style.visibility = ob.i ? "visible" : "hidden";
  $("#obBack").onclick = () => { ob.i--; obRender(); };
  $("#obLater").onclick = () => { if (ob.i === 0) { sessionStorage.obLater = 1; obClose(); } };
  el.querySelectorAll(".ob-opt").forEach((b) => (b.onclick = () => { ob.answers[st.k] = b.dataset.v; obNext(); }));
  el.querySelectorAll(".ob-chip").forEach((b) => (b.onclick = () => b.classList.toggle("on")));
  if ($("#obSkip")) $("#obSkip").onclick = () => { delete ob.answers[st.k]; obNext(); };
  if ($("#obNext")) $("#obNext").onclick = () => obCommit(st) && obNext();
  const inp = $("#obText");
  if (inp) {
    if (inp.tagName === "INPUT") inp.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); $("#obNext").click(); } };
    setTimeout(() => inp.focus(), 50);
  }
}

function obCommit(st) {
  const raw = $("#obText")?.value.trim() ?? "";
  const err = (m) => { $("#obErr").textContent = m; return false; };
  if (st.type === "multi") {
    const chips = [...document.querySelectorAll(".ob-chip.on")].map((b) => b.textContent);
    if (chips.length || raw) ob.answers[st.k] = { chips, text: raw };
    else delete ob.answers[st.k];
    return true;
  }
  if (!raw) {
    if (st.optional) { delete ob.answers[st.k]; return true; }
    return err("Preenche aqui pra eu conseguir calcular 🙂");
  }
  if (st.type === "number") {
    let n = parseFloat(raw.replace(",", "."));
    if (st.parse) n = st.parse(n);
    if (!(n >= st.min && n <= st.max)) return err(`Hmm, esse valor parece estranho (${st.min}–${st.max} ${st.unit}).`);
    ob.answers[st.k] = Math.round(n * 10) / 10;
  } else ob.answers[st.k] = raw;
  return true;
}

function obNext() {
  if (ob.i < obVisible().length - 1) {
    ob.i++;
    obRender();
  } else obFinish();
}

async function obFinish() {
  const a = { ...ob.answers };
  if (a.objective === "manter") { delete a.target_kg; delete a.pace; }
  for (const k of ["diet", "despensa"]) if (a[k]) a[k] = [...a[k].chips, a[k].text].filter(Boolean).join(", ");
  $("#onboard").innerHTML = `<div class="ob-body ob-wait"><div class="spinner"></div>
    <h2>Montando seu plano…</h2><p class="muted">Calculando seu gasto e definindo as metas.</p></div>`;
  try {
    const s = await api("/api/onboarding", { method: "POST", body: JSON.stringify(a) });
    obClose();
    switchView("viewChat");
    render(s);
  } catch (e) {
    $("#onboard").innerHTML = `<div class="ob-body ob-wait"><h2>Deu erro 😕</h2><p class="muted">${esc(e.message)}</p>
      <button class="btn" id="obRetry">Tentar de novo</button></div>`;
    $("#obRetry").onclick = obFinish;
  }
}

function obClose() {
  $("#onboard").classList.add("hidden");
}
