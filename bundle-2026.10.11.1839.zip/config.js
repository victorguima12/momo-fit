window.MOMO_CONFIG = {"model_chat": "gpt-6-luna", "model_vision": "gpt-6-astra", "model_transcribe": "gpt-transcribe"};
