// Backend local do Momo: a mesma API que o server.py tinha, rodando dentro do app.
// Dados no IndexedDB do aparelho; a IA é chamada direto na OpenAI. Na 1ª abertura importa seed/ (dados do PC).

const Backend = (() => {
  // a chave vem no config.js do APK e fica guardada no aparelho; as atualizações OTA não trazem a chave
  let CFG = window.MOMO_CONFIG || {};
  const MEALS = ["cafe", "almoco", "lanche", "jantar"];
  const DEFAULT_GOALS = { kcal: 2200, protein: 150, carbs: 220, fat: 70 };
  const USER_FIELDS = ["sex", "age", "height_cm", "weight_kg", "activity", "objective"];
  const EXTRA_FIELDS = ["name", "target_kg", "pace", "training", "diet", "routine", "despensa"];
  const ACTIVITY = { sedentario: 1.2, leve: 1.375, moderado: 1.55, intenso: 1.725 };
  const OBJECTIVE = { perder: -500, manter: 0, ganhar: 300 };

  let DB = null, TEMPLATE = null, PROMPTS = null;
  const photoURLs = new Map(); // nome → object URL

  /* ---------- IndexedDB ---------- */

  let idbP = null;
  function idb() {
    idbP = idbP || new Promise((res, rej) => {
      const r = indexedDB.open("momo", 1);
      r.onupgradeneeded = () => { r.result.createObjectStore("kv"); r.result.createObjectStore("photos"); };
      r.onsuccess = () => res(r.result);
      r.onerror = () => rej(r.error);
    });
    return idbP;
  }
  async function idbDo(store, mode, fn) {
    const db = await idb();
    return new Promise((res, rej) => {
      const tx = db.transaction(store, mode);
      const req = fn(tx.objectStore(store));
      tx.oncomplete = () => res(req?.result);
      tx.onerror = () => rej(tx.error);
    });
  }
  const kvGet = (k) => idbDo("kv", "readonly", (s) => s.get(k));
  const kvSet = (k, v) => idbDo("kv", "readwrite", (s) => s.put(v, k));
  const photoPut = (name, blob) => idbDo("photos", "readwrite", (s) => s.put(blob, name));
  const photoDel = (name) => idbDo("photos", "readwrite", (s) => s.delete(name));

  // grava em sequência (a última versão sempre vence)
  let saving = Promise.resolve();
  function save() {
    const snap = JSON.parse(JSON.stringify(DB));
    saving = saving.then(() => kvSet("db", snap));
    return saving;
  }

  /* ---------- inicialização ---------- */

  async function init() {
    CFG = { ...((await kvGet("config")) || {}), ...Object.fromEntries(Object.entries(CFG).filter(([, v]) => v)) };
    if (CFG.openai_key) await kvSet("config", CFG);
    [TEMPLATE, PROMPTS] = await Promise.all([fetch("plan.json").then((r) => r.json()), fetch("prompts.json").then((r) => r.json())]);
    DB = await kvGet("db");
    if (!DB) DB = await importSeed();
    for (const [k, v] of Object.entries({ goals: { ...DEFAULT_GOALS }, goals_source: "default", user: {}, profile: [],
      pantry: [], days: {}, chat: [], workouts: [], coach_chat: [] })) if (DB[k] === undefined) DB[k] = v;
    getPlan();
    pantryNormalize();
    await save();
    // fotos: carrega tudo em object URLs (são poucas)
    const db = await idb();
    await new Promise((res) => {
      const cur = db.transaction("photos").objectStore("photos").openCursor();
      cur.onsuccess = () => {
        const c = cur.result;
        if (!c) return res();
        photoURLs.set(c.key, URL.createObjectURL(c.value));
        c.continue();
      };
      cur.onerror = () => res();
    });
  }

  async function importSeed() {
    try {
      const r = await fetch("seed/db.json");
      if (!r.ok) return {};
      const db = await r.json();
      const names = Object.values(db.days || {}).flatMap((d) => d.photos || []);
      for (const n of names) {
        const pr = await fetch("seed/photos/" + n);
        if (pr.ok) await photoPut(n, await pr.blob());
      }
      return db;
    } catch { return {}; }
  }

  /* ---------- utilidades ---------- */

  const pad = (n) => String(n).padStart(2, "0");
  const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const today = () => isoDate(new Date());
  const nowISO = () => { const d = new Date(); return `${isoDate(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`; };
  const hhmm = () => { const d = new Date(); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
  const uid = (n = 8) => Array.from(crypto.getRandomValues(new Uint8Array(n / 2)), (b) => b.toString(16).padStart(2, "0")).join("");
  const round = (v, k = 0) => { const f = 10 ** k; return Math.round(v * f) / f; };
  const fnum = (v) => { const n = parseFloat(v); return Number.isFinite(n) ? n : null; };
  const clamp = (v, lo, hi, dflt) => { const n = fnum(v); return n === null ? dflt : Math.min(Math.max(n, lo), hi); };
  const clone = (o) => JSON.parse(JSON.stringify(o));
  class ApiError extends Error {}

  /* ---------- dia, metas, perfil ---------- */

  const day = (d) => (DB.days[d] = DB.days[d] || { entries: [] });
  const missingUser = () => USER_FIELDS.filter((k) => !DB.user[k]);
  function totals(entries) {
    const t = { kcal: 0, protein: 0, carbs: 0, fat: 0 };
    for (const e of entries) for (const k in t) t[k] += parseFloat(e[k] || 0) || 0;
    for (const k in t) t[k] = Math.round(t[k]);
    return t;
  }
  const defaultPlan = (u) => ({ kcal_adjust: OBJECTIVE[u.objective] ?? 0, protein_g_kg: u.objective === "manter" ? 1.6 : 2.0, fat_g_kg: 0.9 });

  function calcGoals(u, explain = false) {
    const w = +u.weight_kg, h = +u.height_cm, a = +u.age;
    const bmr = 10 * w + 6.25 * h - 5 * a + (u.sex === "M" ? 5 : -161);
    const factor = ACTIVITY[u.activity] ?? 1.375;
    const plan = { ...defaultPlan(u), ...(u.plan || {}) };
    const kcal = Math.max(bmr * factor + plan.kcal_adjust, bmr, 1200); // nunca abaixo do basal
    const protein = w * plan.protein_g_kg, fat = w * plan.fat_g_kg;
    const carbs = Math.max((kcal - protein * 4 - fat * 9) / 4, 50);
    const goals = { kcal: Math.round(kcal / 10) * 10, protein: Math.round(protein), carbs: Math.round(carbs), fat: Math.round(fat) };
    if (!explain) return goals;
    return {
      metabolismo_basal_mifflin_st_jeor: Math.round(bmr), fator_atividade: factor, gasto_total_estimado: Math.round(bmr * factor),
      ajuste_objetivo_kcal: plan.kcal_adjust, proteina_g_por_kg: plan.protein_g_kg, gordura_g_por_kg: plan.fat_g_kg,
      carbo: "o que sobra das calorias", justificativa_do_plano: plan.why ?? null, resultado: goals,
    };
  }

  function goalsOrigin() {
    if (DB.goals_source === "auto" && !missingUser().length) return { tipo: "calculada pelo perfil", conta: calcGoals(DB.user, true) };
    if (DB.goals_source === "manual") return { tipo: "definida pelo usuário na mão" };
    return { tipo: "valor padrão genérico (2200 kcal), ainda não personalizado: falta completar o perfil" };
  }

  function setUser(fields) {
    const u = DB.user;
    for (const k of USER_FIELDS) {
      let v = fields[k];
      if (v === null || v === undefined || v === "") continue;
      if (["age", "height_cm", "weight_kg"].includes(k)) {
        v = fnum(v);
        if (v === null) continue;
        v = round(v, 1);
      } else if (k === "sex") v = String(v).toUpperCase().startsWith("F") ? "F" : "M";
      else if ((k === "activity" && !(v in ACTIVITY)) || (k === "objective" && !(v in OBJECTIVE))) continue;
      if (k === "objective" && v !== u.objective) delete u.plan; // plano da IA era pra outro objetivo
      u[k] = v;
    }
    if (!missingUser().length && DB.goals_source !== "manual") {
      DB.goals = calcGoals(u);
      DB.goals_source = "auto";
    }
  }

  function setWeight(d, kg) {
    day(d).weight = round(+kg, 1);
    const latest = Object.keys(DB.days).filter((k) => DB.days[k].weight).sort().pop();
    if (latest === d) setUser({ weight_kg: kg }); // só o peso mais recente vira o do perfil
  }

  // despensa: [{name, porcao?, kcal?, protein?, carbs?, fat?}] — a tabela vem de foto de rótulo
  const pName = (x) => String(typeof x === "string" ? x : x?.name || "").trim().toLowerCase();
  function pantryNormalize() { DB.pantry = (DB.pantry || []).map((x) => (typeof x === "string" ? { name: pName(x) } : x)); }
  function pantryUpdate(add, remove) {
    pantryNormalize();
    for (const it of add || []) {
      const name = pName(it);
      if (!name) continue;
      let cur = DB.pantry.find((x) => x.name === name);
      if (!cur) DB.pantry.push((cur = { name }));
      if (it && typeof it === "object") {
        if (it.porcao) cur.porcao = String(it.porcao).slice(0, 40);
        for (const k of ["kcal", "protein", "carbs", "fat"]) if (fnum(it[k]) !== null) cur[k] = round(fnum(it[k]), 1);
      }
    }
    const gone = new Set((remove || []).map(pName));
    DB.pantry = DB.pantry.filter((x) => !gone.has(x.name));
  }

  async function savePhoto(d, dataUrl) {
    const name = `${d}_${uid(6)}.jpg`;
    const blob = await (await fetch(dataUrl.startsWith("data:") ? dataUrl : "data:image/jpeg;base64," + dataUrl)).blob();
    await photoPut(name, blob);
    photoURLs.set(name, URL.createObjectURL(blob));
    (day(d).photos = day(d).photos || []).push(name);
    return name;
  }

  /* ---------- treino (port do treino.py) ---------- */

  function getPlan() {
    if (!DB.plan) DB.plan = clone(TEMPLATE);
    for (const [k, v] of Object.entries(TEMPLATE.muscles)) if (!(k in DB.plan.muscles)) DB.plan.muscles[k] = v;
    return DB.plan;
  }
  const planKeys = () => getPlan().plan.map((p) => p.key);
  const planDay = (k) => getPlan().plan.find((p) => p.key === k) || null;
  const exName = (id) => getPlan().exercises[id]?.name || id;
  const sortedWorkouts = () => DB.workouts.filter((w) => planKeys().includes(w.day))
    .sort((a, b) => (a.date + (a.savedAt || "") < b.date + (b.savedAt || "") ? -1 : 1));
  function nextWorkout() {
    const ws = sortedWorkouts(), keys = planKeys();
    return getPlan().plan[ws.length ? (keys.indexOf(ws[ws.length - 1].day) + 1) % keys.length : 0];
  }
  const fmtKg = (w) => (!w ? "PC" : String(+w).replace(".", ","));
  function workoutSummary(w) {
    const p = planDay(w.day);
    return { date: w.date, treino: `${w.day} · ${p ? p.title : ""}`,
      series: w.entries.map((e) => `${exName(e.ex)}: ` + e.sets.map((s) => `${fmtKg(s.w)}×${s.r}`).join(", ")) };
  }
  function saveWorkout(w) {
    DB.workouts = DB.workouts.filter((x) => !(x.day === w.day && x.date === w.date));
    DB.workouts.push(w);
  }

  const exHistory = (id) => sortedWorkouts().flatMap((w) => w.entries.filter((e) => e.ex === id).map((e) => ({ date: w.date, sets: e.sets })));
  function suggest(id, n) {
    const ex = getPlan().exercises[id];
    const [lo, hi] = ex.reps;
    const inc = ex.inc || (ex.name.includes("DB") ? 2 : 2.5);
    const h = exHistory(id);
    if (!h.length) return { meta: `${ex.bw ? "peso corporal" : "carga a escolher"} × ${Math.round(lo + (hi - lo) * 0.4)} reps`, motivo: "primeira vez" };
    const sets = h[h.length - 1].sets.filter((s) => s.r > 0);
    const top = Math.max(0, ...sets.map((s) => s.w || 0));
    const work = sets.filter((s) => (s.w || 0) === top);
    const avg = work.reduce((a, s) => a + s.r, 0) / work.length;
    const last = sets.map((s) => `${fmtKg(s.w)}×${s.r}`).join(" · ");
    if (work.every((s) => s.r >= hi)) return { ultima: last, meta: `${fmtKg(top + inc)} kg × ${Math.max(lo, hi - 3)} reps`, motivo: `bateu ${hi} em tudo: sobe a carga` };
    if (avg < lo - 1 && top > 0) return { ultima: last, meta: `${fmtKg(Math.max(0, top - inc))} kg × ${lo + 1} reps`, motivo: `abaixo de ${lo}: baixa a carga` };
    const reps = Array.from({ length: n }, (_, i) => Math.min(hi, Math.max(lo, work[Math.min(i, work.length - 1)].r + 1)));
    return { ultima: last, meta: `${top ? fmtKg(top) + " kg" : "peso corporal"} × ${reps.join(" · ")}`, motivo: "mesma carga, +1 rep por série" };
  }
  function nextTargets() {
    const d = nextWorkout();
    return { treino: `${d.key} · ${d.title}`, metas: Object.fromEntries(d.ex.map(([e, n]) => [exName(e), suggest(e, n)])) };
  }

  function muscleStats() {
    const plan = getPlan(), days = plan.plan, ex = plan.exercises, n = days.length, out = {};
    for (const [m, label] of Object.entries(plan.muscles)) {
      const direct = days.map((d) => d.ex.reduce((a, [e, s]) => a + (ex[e].p.includes(m) ? s : 0), 0));
      const indirect = days.map((d) => d.ex.reduce((a, [e, s]) => a + ((ex[e].s || []).includes(m) ? s : 0), 0));
      const hit = direct.map((v, i) => (v ? i : -1)).filter((i) => i >= 0);
      const minGap = hit.length > 1 ? Math.min(...hit.map((i, j) => ((hit[(j + 1) % hit.length] - i + n) % n) || n)) : hit.length ? n : null;
      const dates = [...new Set(DB.workouts.filter((w) => w.entries.some((e) => (ex[e.ex]?.p || []).includes(m))).map((w) => w.date))].sort();
      out[label] = { series_por_ciclo: direct.reduce((a, b) => a + b, 0), indiretas_por_ciclo: indirect.reduce((a, b) => a + b, 0),
        treinos: hit.map((i) => days[i].key).join("") || "-", menor_distancia_em_treinos: minGap, ultimo_treino: dates.pop() || null };
    }
    return out;
  }
  function trainingFrequency() {
    const ws = sortedWorkouts(), t = new Date(today() + "T12:00");
    const recent = ws.filter((w) => (t - new Date(w.date + "T12:00")) / 86400000 < 28);
    return { treinos_ultimos_28_dias: recent.length, media_por_semana: round(recent.length / 4, 1), ultimo_treino: ws.length ? ws[ws.length - 1].date : null };
  }

  const SLUG = /^[a-z0-9_]{2,40}$/;
  function cleanDef(d, base) {
    const muscles = getPlan().muscles, out = { ...(base || {}) };
    if (d.name) out.name = String(d.name).slice(0, 60);
    if (Array.isArray(d.reps) && d.reps.length === 2) {
      const [lo, hi] = d.reps.map((x) => Math.trunc(+x)).sort((a, b) => a - b);
      if (lo >= 1 && lo < hi && hi <= 50) out.reps = [lo, hi];
    }
    if (Array.isArray(d.p)) { const p = d.p.filter((m) => m in muscles); if (p.length) out.p = p; }
    if (Array.isArray(d.s)) out.s = d.s.filter((m) => m in muscles && !(out.p || []).includes(m));
    if ("bw" in d) out.bw = !!d.bw;
    if (d.inc) out.inc = Math.max(0.5, Math.min(10, +d.inc));
    if (!out.name || !out.reps || !out.p) throw new Error("definição de exercício incompleta");
    if (!out.s?.length) delete out.s;
    return out;
  }
  const setsN = (v, dflt = 3) => { const n = Math.trunc(+v); return Number.isFinite(n) ? Math.max(1, Math.min(10, n)) : dflt; };

  function applyPlanOps(ops) {
    const plan = getPlan(), before = clone(plan), exs = plan.exercises, done = [];
    for (const op of ops || []) {
      try {
        const kind = op.op, d = op.day ? planDay(op.day) : null, exId = String(op.ex_id || "");
        if (kind === "add_exercise" || kind === "replace_exercise") {
          const newId = kind === "replace_exercise" ? String(op.new_ex_id || exId) : exId;
          if (!SLUG.test(newId) || !d) continue;
          if (!(newId in exs)) exs[newId] = cleanDef(op.def || {});
          else if (op.def) exs[newId] = cleanDef(op.def, exs[newId]);
          if (d.ex.some(([e]) => e === newId)) continue;
          if (kind === "add_exercise") {
            const pos = op.position == null ? d.ex.length : Math.max(0, Math.min(d.ex.length, Math.trunc(+op.position) - 1));
            d.ex.splice(pos, 0, [newId, setsN(op.sets)]);
            done.push(`+ ${exs[newId].name} no Treino ${d.key} (${d.ex[pos][1]} séries)`);
          } else {
            const i = d.ex.findIndex(([e]) => e === exId);
            if (i < 0) continue;
            const sets = setsN(op.sets, d.ex[i][1]);
            done.push(`↔ ${exs[exId].name} → ${exs[newId].name} no Treino ${d.key}`);
            d.ex[i] = [newId, sets];
          }
        } else if (kind === "remove_exercise" && d) {
          if (d.ex.some(([e]) => e === exId)) { d.ex = d.ex.filter(([e]) => e !== exId); done.push(`− ${exName(exId)} saiu do Treino ${d.key}`); }
        } else if (kind === "set_sets" && d) {
          for (const x of d.ex) if (x[0] === exId) { x[1] = setsN(op.sets, x[1]); done.push(`${exName(exId)} no Treino ${d.key}: ${x[1]} séries`); }
        } else if (kind === "move_exercise" && d) {
          const i = d.ex.findIndex(([e]) => e === exId);
          if (i >= 0) {
            const item = d.ex.splice(i, 1)[0];
            const pos = Math.max(0, Math.min(d.ex.length, Math.trunc(+(op.position ?? 1)) - 1));
            d.ex.splice(pos, 0, item);
            done.push(`${exName(exId)} agora é o ${pos + 1}º do Treino ${d.key}`);
          }
        } else if (kind === "edit_exercise" && exs[exId] && op.def) {
          exs[exId] = cleanDef(op.def, exs[exId]);
          done.push(`${exs[exId].name}: faixa ${exs[exId].reps[0]}–${exs[exId].reps[1]} reps`);
        } else if (kind === "rename_day" && d && op.title) {
          d.title = String(op.title).slice(0, 40);
          done.push(`Treino ${d.key} agora se chama “${d.title}”`);
        }
      } catch { /* operação inválida: ignora */ }
    }
    if (done.length) DB.plan_history = [...(DB.plan_history || []), before].slice(-15);
    return done;
  }

  function coachContext() {
    const plan = getPlan(), exs = plan.exercises;
    const used = new Set(plan.plan.flatMap((d) => d.ex.map(([e]) => e)));
    const { plan: _p, ...user } = DB.user;
    return {
      hoje: today(), usuario: user, notas_sobre_usuario: DB.profile, musculos: plan.muscles,
      plano: plan.plan.map((d) => ({ treino: d.key, titulo: d.title, exercicios: d.ex.map(([e, n]) => ({
        id: e, nome: exs[e].name, series: n, faixa: exs[e].reps, principal: exs[e].p, secundario: exs[e].s || [] })) })),
      catalogo_fora_do_plano: Object.fromEntries(Object.entries(exs).filter(([e]) => !used.has(e)).map(([e, v]) => [e, v.name])),
      proximo_treino: nextTargets(), frequencia: trainingFrequency(), musculos_stats: muscleStats(),
      ultimos_treinos: sortedWorkouts().slice(-8).map(workoutSummary),
    };
  }

  /* ---------- estado e contexto da IA ---------- */

  function state(d) {
    const dd = DB.days[d] || { entries: [] };
    return {
      workouts_today: sortedWorkouts().filter((w) => w.date === d).map(workoutSummary),
      date: d, goals: DB.goals, goals_source: DB.goals_source, user: DB.user, user_missing: missingUser(),
      weight: dd.weight ?? null, photos: dd.photos || [], entries: dd.entries, totals: totals(dd.entries),
      chat: DB.chat.slice(-60), profile: DB.profile, pantry: DB.pantry,
    };
  }

  function buildContext(d) {
    const todayEntries = day(d).entries;
    const week = [];
    for (let i = 1; i <= 7; i++) {
      const x = new Date(d + "T12:00");
      x.setDate(x.getDate() - i);
      const dd = isoDate(x), ents = DB.days[dd]?.entries || [];
      if (ents.length) week.push({ date: dd, totals: totals(ents), items: ents.map((e) => e.name) });
    }
    const td = DB.days[today()] || {};
    const weights = Object.entries(DB.days).filter(([, v]) => v.weight).map(([k, v]) => [k, v.weight]).sort().slice(-10);
    const exs = getPlan().exercises, t = totals(todayEntries);
    const agora = new Date();
    return {
      agora: `${today()} ${hhmm()} (${agora.toLocaleDateString("pt-BR", { weekday: "long" })})`,
      dia_aberto_no_app: d, metas: DB.goals, origem_das_metas: goalsOrigin(), usuario: DB.user, perfil_faltando: missingUser(),
      notas_sobre_usuario: DB.profile, despensa: DB.pantry,
      checkin_hoje: { peso: td.weight ?? null, fotos: (td.photos || []).length,
        pode_perguntar: !td.weight && !td.checkin_asked && !missingUser().length },
      historico_peso: weights,
      treino: {
        proximo: nextTargets(),
        feito_no_dia_aberto: sortedWorkouts().filter((w) => w.date === d).map(workoutSummary),
        ultimos: sortedWorkouts().slice(-6).map(workoutSummary),
        plano: Object.fromEntries(getPlan().plan.map((p) => [p.key, { titulo: p.title, exercicios: Object.fromEntries(
          p.ex.map(([e, n]) => [e, `${exs[e].name} (${n} séries, ${exs[e].reps[0]}-${exs[e].reps[1]} reps)`])) }])),
      },
      registrado_no_dia: todayEntries.map(({ id, name, quantity, meal, kcal, protein, carbs, fat }) => ({ id, name, quantity, meal, kcal, protein, carbs, fat })),
      totais_do_dia: t,
      faltando_para_meta: Object.fromEntries(Object.keys(DB.goals).map((k) => [k, Math.round(DB.goals[k] - t[k])])),
      ultimos_7_dias: week,
    };
  }

  /* ---------- OpenAI ---------- */

  async function openai(path, body, form) {
    if (!CFG.openai_key) throw new ApiError("Sem chave da OpenAI configurada.");
    const r = await fetch("https://api.openai.com/v1" + path, {
      method: "POST",
      headers: form ? { Authorization: "Bearer " + CFG.openai_key } : { Authorization: "Bearer " + CFG.openai_key, "Content-Type": "application/json" },
      body: form || JSON.stringify(body),
    }).catch(() => { throw new ApiError("Sem internet (ou a OpenAI não respondeu)."); });
    if (!r.ok) throw new ApiError(`OpenAI ${r.status}: ${(await r.text()).slice(0, 300)}`);
    return r.json();
  }
  const outputText = (r) => (r.output || []).filter((o) => o.type === "message").flatMap((o) => o.content).map((c) => c.text || "").join("");
  async function askJSON(model, instructions, input, effort = "low") {
    const r = await openai("/responses", { model, instructions, input, text: { format: { type: "json_object" } }, reasoning: { effort }, store: false });
    const out = outputText(r);
    try { return JSON.parse(out); } catch { return { reply: out || "Não entendi, pode repetir?" }; }
  }

  /* ---------- ações do chat da dieta ---------- */

  function applyActions(d, data) {
    const entries = day(d).entries, added = [];
    for (const it of data.add || []) {
      const e = { id: uid(8), name: String(it.name ?? "?"), quantity: String(it.quantity ?? ""), meal: MEALS.includes(it.meal) ? it.meal : "lanche", time: hhmm() };
      for (const k of ["kcal", "protein", "carbs", "fat"]) e[k] = round(fnum(it[k]) || 0, 1);
      entries.push(e);
      added.push(e.id);
    }
    const remove = new Set(data.remove || []);
    if (remove.size) day(d).entries = day(d).entries.filter((e) => !remove.has(e.id));
    for (const up of data.update || []) for (const e of day(d).entries) if (e.id === up.id)
      for (const k of ["name", "quantity", "meal", "kcal", "protein", "carbs", "fat"]) if (up[k] !== undefined && up[k] !== null) e[k] = up[k];
    if (data.goals && typeof data.goals === "object" && Object.keys(DB.goals).some((k) => data.goals[k])) {
      for (const k of Object.keys(DB.goals)) if (data.goals[k]) DB.goals[k] = Math.round(+data.goals[k]);
      DB.goals_source = "manual";
    }
    if (data.profile_note) DB.profile.push(String(data.profile_note));
    pantryUpdate(data.pantry_add, data.pantry_remove);
    if (data.user && typeof data.user === "object") {
      if (data.user.weight_kg && !data.weight_kg && !day(d).weight) data.weight_kg = data.user.weight_kg; // peso do perfil vale pro dia
      setUser(data.user);
    }
    if (fnum(data.weight_kg)) setWeight(d, fnum(data.weight_kg));
    const wl = data.workout_log;
    if (wl && typeof wl === "object" && planKeys().includes(wl.day)) {
      const fresh = {};
      for (const e of wl.entries || []) {
        if (!(e.ex in getPlan().exercises)) continue;
        const sets = (e.sets || []).filter((s) => fnum(s.r) > 0).map((s) => ({ w: round(fnum(s.w) || 0, 2), r: Math.trunc(+s.r) }));
        if (sets.length) fresh[e.ex] = sets;
      }
      if (Object.keys(fresh).length) {
        // junta com o que já foi registrado desse treino no dia (dá pra contar aos poucos)
        const old = DB.workouts.find((w) => w.day === wl.day && w.date === d);
        const merged = { ...Object.fromEntries((old?.entries || []).map((e) => [e.ex, e.sets])), ...fresh };
        const order = planDay(wl.day).ex.map(([e]) => e);
        const ents = Object.keys(merged).sort((a, b) => (order.indexOf(a) + 1 || 99) - (order.indexOf(b) + 1 || 99)).map((ex) => ({ ex, sets: merged[ex] }));
        saveWorkout({ id: `${d}-${wl.day}`, date: d, day: wl.day, entries: ents, savedAt: nowISO() });
        data._workout = wl.day;
      }
    }
    if (data.asked_checkin) day(today()).checkin_asked = true;
    return added;
  }

  /* ---------- rotas ---------- */

  async function chat(b) {
    const d = b.date || today();
    const imgs = (b.images || (b.image ? [b.image] : [])).slice(0, 6)
      .map((x) => (x.startsWith("data:") ? x : `data:image/jpeg;base64,${x}`));
    const img = imgs[0] || null;
    const history = DB.chat.slice(-12).map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.text }));
    const content = [{ type: "input_text", text: b.text || (imgs.length > 1 ? `(${imgs.length} fotos enviadas)` : "(foto enviada)") }];
    for (const u of imgs) content.push({ type: "input_image", image_url: u, detail: imgs.length > 2 ? "auto" : "high" });
    const model = img ? CFG.model_vision : CFG.model_chat;
    const t0 = performance.now();
    const data = await askJSON(model, PROMPTS.chat, [
      { role: "developer", content: "ESTADO ATUAL (responda só com o JSON do formato pedido):\n" + JSON.stringify(buildContext(d)) },
      ...history, { role: "user", content },
    ]);
    if (img && data.progress_photo) { data.add = []; for (const u of imgs) await savePhoto(d, u); }
    const gBefore = { ...DB.goals }, srcBefore = DB.goals_source;
    const added = applyActions(d, data);
    const g = DB.goals;
    if (DB.goals_source === "auto" && (srcBefore !== "auto" || Math.abs(g.kcal - gBefore.kcal) >= 50))
      data.reply = `${data.reply || ""}\n\n🎯 Metas novas: ${g.kcal} kcal · ${g.protein} g proteína · ${g.carbs} g carbo · ${g.fat} g gordura.`.trim();
    const now = nowISO();
    DB.chat.push({ role: "user", text: b.text || (imgs.length > 1 ? `📷 ${imgs.length} fotos` : "📷 foto"), ts: now, date: d, photo: imgs.length });
    DB.chat.push({ role: "momo", text: data.reply || "", ts: now, date: d, added, model, workout: data._workout || null });
    DB.chat = DB.chat.slice(-300);
    await save();
    return { ...state(d), meta: { model, secs: round((performance.now() - t0) / 1000, 1) } };
  }

  async function onboarding(a) {
    DB.user = {};
    DB.goals_source = "auto";
    setUser(a);
    for (const k of EXTRA_FIELDS) if (a[k] !== undefined && a[k] !== null && a[k] !== "" && !(Array.isArray(a[k]) && !a[k].length)) DB.user[k] = a[k];
    if (missingUser().length) throw new ApiError("Faltam dados: " + missingUser().join(", "));
    const u = DB.user, base = calcGoals(u, true);
    const data = await askJSON(CFG.model_chat, PROMPTS.onboard, [{ role: "user", content: "Responda só com o JSON pedido.\n" + JSON.stringify({ respostas: u, calculo_base: base }) }]);
    const p = data.plan || {}, dp = defaultPlan(u);
    DB.user = { ...u, plan: {
      kcal_adjust: Math.round(clamp(p.kcal_adjust, -1000, 600, dp.kcal_adjust)),
      protein_g_kg: round(clamp(p.protein_g_kg, 1.4, 2.4, dp.protein_g_kg), 2),
      fat_g_kg: round(clamp(p.fat_g_kg, 0.6, 1.2, dp.fat_g_kg), 2),
      why: String(p.why || ""),
    } };
    DB.goals_source = "auto";
    const g = (DB.goals = calcGoals(DB.user));
    day(today()).weight = DB.user.weight_kg;
    DB.profile = (data.notes || []).filter(Boolean).map(String);
    DB.pantry = [];
    pantryUpdate(data.pantry);
    const reply = `${(data.reply || "Pronto, perfil criado!").trim()}\n\n🎯 Suas metas: ${g.kcal} kcal · ${g.protein} g proteína · ${g.carbs} g carbo · ${g.fat} g gordura.`;
    DB.chat.push({ role: "momo", text: reply, ts: nowISO(), date: today(), added: [], model: CFG.model_chat });
    await save();
    return state(today());
  }

  const planState = () => ({ plan: getPlan(), coach_chat: DB.coach_chat.slice(-60), can_undo: !!(DB.plan_history || []).length });

  async function coach(b) {
    const history = DB.coach_chat.slice(-12).map((m) => ({ role: m.role === "user" ? "user" : "assistant", content: m.text }));
    const t0 = performance.now();
    const data = await askJSON(CFG.model_chat, PROMPTS.coach, [
      { role: "developer", content: "ESTADO DO TREINO (responda só com o JSON pedido):\n" + JSON.stringify(coachContext()) },
      ...history, { role: "user", content: b.text },
    ], "medium");
    const changes = applyPlanOps(data.plan_ops);
    if (data.profile_note) DB.profile.push(String(data.profile_note));
    const now = nowISO();
    DB.coach_chat.push({ role: "user", text: b.text, ts: now });
    DB.coach_chat.push({ role: "momo", text: data.reply || "", ts: now, changes, secs: round((performance.now() - t0) / 1000, 1) });
    DB.coach_chat = DB.coach_chat.slice(-200);
    await save();
    return planState();
  }

  async function transcribe(form) {
    const f = new FormData();
    f.append("model", CFG.model_transcribe);
    f.append("language", "pt");
    f.append("file", form.get("file"), "fala.webm");
    return { text: (await openai("/audio/transcriptions", null, f)).text || "" };
  }

  // tabela de rotas: [método, regex do caminho, handler(params, query, body)]
  const ROUTES = [
    ["GET", /^\/api\/state$/, (p, q) => state(q.get("date") || today())],
    ["POST", /^\/api\/chat$/, (p, q, b) => chat(b)],
    ["DELETE", /^\/api\/chat$/, async () => { DB.chat = []; await save(); return { ok: true }; }],
    ["POST", /^\/api\/transcribe$/, (p, q, b) => transcribe(b)],
    ["PUT", /^\/api\/entry\/([^/]+)\/([^/]+)$/, async ([d, id], q, up) => {
      const e = day(d).entries.find((x) => x.id === id);
      if (!e) throw new ApiError("item não encontrado");
      if (up.name) e.name = String(up.name).slice(0, 80);
      if (up.quantity !== undefined) e.quantity = String(up.quantity).slice(0, 40);
      if (MEALS.includes(up.meal)) e.meal = up.meal;
      for (const k of ["kcal", "protein", "carbs", "fat"]) if (fnum(up[k]) !== null) e[k] = round(Math.max(0, fnum(up[k])), 1);
      e.edited = true;
      await save(); return state(d);
    }],
    ["DELETE", /^\/api\/entry\/([^/]+)\/([^/]+)$/, async ([d, id]) => { day(d).entries = day(d).entries.filter((e) => e.id !== id); await save(); return state(d); }],
    ["PUT", /^\/api\/goals$/, async (p, q, g) => {
      DB.goals = Object.fromEntries(["kcal", "protein", "carbs", "fat"].map((k) => [k, Math.round(+g[k] || 0)]));
      DB.goals_source = "manual"; await save(); return DB.goals;
    }],
    ["PUT", /^\/api\/user$/, async (p, q, u) => {
      if (u.weight_kg && u.weight_kg !== DB.user.weight_kg) setWeight(today(), u.weight_kg);
      if (u.recalc) DB.goals_source = "auto";
      setUser(u); await save(); return state(q.get("date") || today());
    }],
    ["DELETE", /^\/api\/user$/, async () => {
      DB.user = {}; DB.profile = []; DB.goals = { ...DEFAULT_GOALS }; DB.goals_source = "default"; await save(); return state(today());
    }],
    ["POST", /^\/api\/onboarding$/, (p, q, b) => onboarding(b)],
    ["POST", /^\/api\/pantry$/, async (p, q, b) => { pantryUpdate(b.add, b.remove); await save(); return state(q.get("date") || today()); }],
    ["GET", /^\/api\/plan$/, () => planState()],
    ["POST", /^\/api\/coach$/, (p, q, b) => coach(b)],
    ["POST", /^\/api\/coach\/undo$/, async () => {
      const hist = DB.plan_history || [];
      if (hist.length) {
        DB.plan = hist.pop();
        const m = [...DB.coach_chat].reverse().find((x) => x.changes?.length && !x.undone);
        if (m) m.undone = true;
        DB.coach_chat.push({ role: "momo", text: "Desfeito, o plano voltou como estava. ↩", ts: nowISO() });
        await save();
      }
      return planState();
    }],
    ["DELETE", /^\/api\/coach$/, async () => { DB.coach_chat = []; await save(); return planState(); }],
    ["GET", /^\/api\/workouts$/, () => ({ sessions: DB.workouts })],
    ["PUT", /^\/api\/workouts$/, async (p, q, w) => {
      if (!planKeys().includes(w.day) || !w.date || !Array.isArray(w.entries)) throw new ApiError("treino inválido");
      saveWorkout({ ...w, id: `${w.date}-${w.day}`, savedAt: nowISO() }); await save(); return { sessions: DB.workouts };
    }],
    ["DELETE", /^\/api\/workouts\/([^/]+)$/, async ([id]) => { DB.workouts = DB.workouts.filter((w) => w.id !== id); await save(); return { sessions: DB.workouts }; }],
    ["PUT", /^\/api\/weight\/([^/]+)$/, async ([d], q, b) => {
      if (fnum(b.weight)) setWeight(d, fnum(b.weight)); else delete day(d).weight;
      await save(); return state(d);
    }],
    ["POST", /^\/api\/photo\/([^/]+)$/, async ([d], q, b) => { await savePhoto(d, b.image); await save(); return state(d); }],
    ["DELETE", /^\/api\/photo\/([^/]+)\/([^/]+)$/, async ([d, name]) => {
      const ph = day(d).photos || [];
      if (ph.includes(name)) {
        day(d).photos = ph.filter((x) => x !== name);
        await photoDel(name);
        if (photoURLs.has(name)) { URL.revokeObjectURL(photoURLs.get(name)); photoURLs.delete(name); }
      }
      await save(); return state(d);
    }],
    ["GET", /^\/api\/calendar$/, (p, q) => {
      const month = q.get("month") || "", out = {};
      for (const [d, v] of Object.entries(DB.days)) if (d.startsWith(month) && (v.entries?.length || v.weight || v.photos?.length))
        out[d] = { kcal: totals(v.entries || []).kcal, n: (v.entries || []).length, weight: v.weight ?? null, photos: (v.photos || []).length };
      for (const w of DB.workouts) if (w.date.startsWith(month)) (out[w.date] = out[w.date] || { kcal: 0, n: 0, weight: null, photos: 0 }).workout = w.day;
      return { month, goal: DB.goals.kcal, days: out };
    }],
    ["GET", /^\/api\/progress$/, () => ({ days: Object.keys(DB.days).sort().filter((d) => DB.days[d].weight || DB.days[d].photos?.length)
      .map((d) => ({ date: d, weight: DB.days[d].weight ?? null, photos: DB.days[d].photos || [], kcal: totals(DB.days[d].entries || []).kcal })) })],
  ];

  let ready = null;
  async function request(path, opts = {}) {
    ready = ready || init();
    await ready;
    const url = new URL(path, "http://x");
    const method = (opts.method || "GET").toUpperCase();
    let body = opts.body;
    if (typeof body === "string") body = JSON.parse(body);
    for (const [m, re, fn] of ROUTES) {
      const match = method === m && url.pathname.match(re);
      if (match) return clone(await fn(match.slice(1).map(decodeURIComponent), url.searchParams, body || {}));
    }
    throw new ApiError(`rota não encontrada: ${method} ${url.pathname}`);
  }

  return {
    request,
    ready: () => (ready = ready || init()),
    photoURL: (name) => photoURLs.get(name) || "",
  };
})();
