// Aba Treino: rotação A→F, registro de séries com progressão dupla, cargas e recuperação.
// Portado do momo-fit (desktop) para o layout de celular. Plano em plan.json.

(() => {
  const q = (s, r = document) => r.querySelector(s);
  const qa = (s, r = document) => [...r.querySelectorAll(s)];
  const ls = (k, fb) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : fb; } catch { return fb; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* ok */ } };
  const fmtD = (s) => { const [, m, d] = s.split("-"); return `${d}/${m}`; };
  const daysBetween = (a, b) => Math.round((new Date(b + "T00:00") - new Date(a + "T00:00")) / 86400000);
  const num = (v) => { const n = parseFloat(String(v).replace(",", ".")); return Number.isFinite(n) ? n : null; };
  const kg = (n) => (Math.round(n * 100) / 100).toString().replace(".", ",");
  const sinceTxt = (d) => (d === 0 ? "hoje" : d === 1 ? "ontem" : `há ${d} dias`);
  const plural = (n, a, b) => `${n} ${n === 1 ? a : b}`;

  let MUSCLES = {}, EX = {}, PLAN = [], N = 0, LOADS = [];
  const T = {
    ready: false,
    sessions: [],
    sub: ls("tr.sub", "treinos"),  // treinos | cargas | recup
    selected: null,                // key do treino aberto
    drafts: ls("tr.drafts", {}),
    progEx: null,
    recSec: ls("tr.recSec", false),
    recMuscle: null,
    armDelete: null,
  };
  const root = () => q("#viewTraining");

  function applyPlan(ps) {
    const p = ps.plan;
    MUSCLES = p.muscles; EX = p.exercises; PLAN = p.plan; N = PLAN.length;
    LOADS = PLAN.map(dayLoad);
    T.coach = ps.coach_chat;
    T.canUndo = ps.can_undo;
  }

  async function init() {
    applyPlan(await api("/api/plan"));
    T.sessions = (await api("/api/workouts")).sessions;
    T.ready = true;
  }

  /* ---------- cálculos (iguais ao momo-fit) ---------- */

  const idxOf = (key) => PLAN.findIndex((d) => d.key === key);
  const order = (a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : (a.savedAt || "") < (b.savedAt || "") ? -1 : 1);
  const sorted = () => T.sessions.filter((s) => idxOf(s.day) >= 0).sort(order);
  const nextIdx = () => { const s = sorted(); return s.length ? (idxOf(s[s.length - 1].day) + 1) % N : 0; };
  const daySets = (day) => day.ex.reduce((a, [, n]) => a + n, 0);

  function dayLoad(day) {
    const p = {}, s = {};
    for (const [id, n] of day.ex) {
      EX[id].p.forEach((m) => (p[m] = (p[m] || 0) + n));
      (EX[id].s || []).forEach((m) => (s[m] = (s[m] || 0) + n));
    }
    return { p, s };
  }
  const muscleDays = (m, withSec) => PLAN.map((_, i) => i).filter((i) => LOADS[i].p[m] || (withSec && LOADS[i].s[m]));
  function gaps(days) {
    if (!days.length) return [];
    if (days.length === 1) return [{ from: days[0], to: days[0], d: N }];
    return days.map((d, i) => { const nx = days[(i + 1) % days.length]; return { from: d, to: nx, d: ((nx - d + N) % N) || N }; });
  }
  function muscleDates(m) {
    const set = new Set();
    for (const s of T.sessions) if (s.entries.some((e) => EX[e.ex]?.p.includes(m))) set.add(s.date);
    return [...set].sort();
  }
  const lastTrained = (m, before) => { const d = muscleDates(m).filter((x) => !before || x < before); return d.length ? d[d.length - 1] : null; };
  function realGaps(m) {
    const d = muscleDates(m).slice(-9);
    const g = d.slice(1).map((x, i) => daysBetween(d[i], x));
    return g.length ? { avg: g.reduce((a, b) => a + b, 0) / g.length, min: Math.min(...g) } : null;
  }
  function exHistory(exId) {
    const out = [];
    for (const s of sorted()) for (const e of s.entries) if (e.ex === exId) out.push({ date: s.date, day: s.day, sets: e.sets });
    return out;
  }
  const e1rm = (w, r) => w * (1 + r / 30);
  function sessionMetric(sets) {
    const top = Math.max(0, ...sets.map((s) => s.w || 0));
    if (top > 0) return { v: Math.max(...sets.map((s) => e1rm(s.w || 0, s.r))), unit: "kg e1RM" };
    return { v: sets.reduce((a, s) => a + s.r, 0), unit: "reps totais" };
  }
  const lastSessionOf = (key) => sorted().filter((x) => x.day === key).pop() || null;

  /* Progressão dupla: dentro da faixa +1 rep; topo em tudo → sobe carga; bem abaixo → baixa. */
  function suggest(exId, n, before) {
    const ex = EX[exId];
    const [lo, hi] = ex.reps;
    const inc = ex.inc ?? (/DB/.test(ex.name) ? 2 : 2.5);
    const h = exHistory(exId).filter((x) => !before || x.date < before);
    const fill = (r) => Array.from({ length: n }, (_, i) => (Array.isArray(r) ? r[i] : r));
    if (!h.length) {
      const start = Math.round(lo + (hi - lo) * 0.4);
      return { first: true, w: ex.bw ? 0 : null, reps: fill(start),
        msg: ex.bw ? `Peso corporal · mira ${start} reps com 1–2 na reserva` : `Escolhe uma carga que dê ~${start} reps com 1–2 na reserva` };
    }
    const last = h[h.length - 1];
    const sets = last.sets.filter((s) => s.r > 0);
    const top = Math.max(0, ...sets.map((s) => s.w || 0));
    const work = sets.filter((s) => (s.w || 0) === top);
    const avg = work.reduce((a, s) => a + s.r, 0) / work.length;
    const lastR = (i) => (work[i] || work[work.length - 1]).r;
    if (work.every((s) => s.r >= hi)) {
      const w = top + inc, r = Math.max(lo, hi - 3);
      return { last, top, w, reps: fill(r), up: true, msg: `Bateu ${hi} em tudo → ${kg(w)} kg, volta pra ${r} reps e sobe de novo` };
    }
    if (avg < lo - 1 && top > 0) {
      const w = Math.max(0, top - inc);
      return { last, top, w, reps: fill(lo + 1), down: true, msg: `Ficou abaixo de ${lo} → baixa pra ${kg(w)} kg e reconstrói` };
    }
    const reps = fill(Array.from({ length: n }, (_, i) => Math.min(hi, Math.max(lo, lastR(i) + 1))));
    return { last, top, w: top, reps, msg: top ? `Mesma carga, +1 rep por série (topo = ${hi})` : `Peso corporal, +1 rep por série (topo = ${hi})` };
  }

  /* ---------- figura muscular (mesmo desenho do momo-fit) ---------- */

  const WIDTH_CURVE = [[0, 1], [48, 1], [66, 1.5], [120, 1.46], [150, 1.34], [200, 1.24], [245, 1.36], [330, 1.34], [440, 1.3]];
  function kAt(y) {
    for (let i = 1; i < WIDTH_CURVE.length; i++) {
      const [y0, k0] = WIDTH_CURVE[i - 1], [y1, k1] = WIDTH_CURVE[i];
      if (y <= y1) return k0 + ((k1 - k0) * (y - y0)) / (y1 - y0);
    }
    return WIDTH_CURVE[WIDTH_CURVE.length - 1][1];
  }
  const warpX = (x, y) => 100 + (x - 100) * kAt(y);
  const warp = (d) => d.replace(/(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)/g, (_, x, y) => `${warpX(+x, +y).toFixed(1)},${y}`);
  const SIL = "M100,12 C88,12 84,22 84,33 C84,44 87,50 92,54 L92,60 C84,66 72,68 62,70 C50,72 44,82 43,96 C42,110 42,128 43,146 C38,166 34,190 32,212 C28,222 26,236 30,244 C34,247 37,241 38,234 L40,222 C44,200 52,176 58,150 C60,140 62,126 64,118 C66,140 66,172 68,200 C64,214 62,232 64,250 C62,280 62,306 66,324 C62,346 62,372 70,400 C70,410 64,420 70,428 L92,428 C94,420 88,410 88,400 C92,376 94,352 90,330 C94,300 96,274 98,252 L100,250 Z";
  const SIDE_DELT = "M62,71 C51,72 45,81 44,95 C45,101 47,105 50,106 C51,94 55,83 63,76 Z";
  const FRONT_DELT = "M63,76 C55,83 51,94 50,106 C55,105 59,99 61,92 C63,85 67,80 72,78 Z";
  const FOREARM = "M44,150 C40,166 36,188 34,208 L40,210 C44,190 50,170 56,152 C52,147 47,147 44,150 Z";
  const FRONT = [
    ["neck", "M93,55 C95,57 97,58 99.5,58 L99.5,66 C97,66 95,65 93,63 Z"],
    ["traps", "M92,60 C87,65 78,68 68,70 L78,75 C85,72 90,68 95,65 Z"],
    ["chest", "M98,76 L98,118 C90,122 78,121 69,116 C63,110 61,100 63,91 C65,84 71,79 79,77 C87,75 93,75 98,76 Z"],
    ["side_delt", SIDE_DELT], ["front_delt", FRONT_DELT],
    ["biceps", "M53,107 C48,117 46,130 47,142 C50,148 55,148 58,142 C60,130 60,117 57,106 Z"],
    ["triceps", "M46,107 C43,118 42,132 44,144 L46.5,143 C46,130 47,118 51,108 Z"],
    ["forearms", FOREARM],
    ["obliques", "M69,121 C75,125 81,126 85,125 L85,194 C80,198 75,202 70,205 C69,186 67,150 69,121 Z"],
    ["quads", "M68,232 C63,254 62,284 66,312 C70,322 79,324 86,318 C90,300 92,272 92,248 C88,238 79,233 68,232 Z"],
    ["adductors", "M93,244 C96,247 98,252 98,258 L95,292 C93,280 92,262 92,250 Z"],
    ["calves", "M70,336 C66,352 67,374 72,396 L79,397 C81,376 82,354 80,337 C77,333 73,333 70,336 Z"],
    ["calves", "M82,338 C86,346 88,360 86,378 L82,380 C83,364 83,350 82,338 Z"],
  ];
  const ABS = [[124, 16], [142, 16], [160, 16], [178, 20]];
  const BACK = [
    ["upper_back", "M73,84 C81,87 88,97 92,110 C88,118 80,121 72,117 C66,111 65,99 67,90 Z"],
    ["lower_back", "M92,150 L98,150 L98,208 L89,208 C89,188 90,166 92,150 Z"],
    ["lats", "M64,106 C71,119 84,128 95,135 C93,152 89,168 82,186 C76,180 72,168 70,154 C67,139 63,122 64,106 Z"],
    ["traps", "M100,50 L100,124 C96,113 90,99 82,87 C76,79 70,74 63,71 C75,68 85,62 92,55 Z"],
    ["neck", "M93,51 C95,52.5 97.5,53 99.5,53 L99.5,60 C97,60 95,59 93.5,57.5 Z"],
    ["side_delt", SIDE_DELT], ["rear_delt", FRONT_DELT],
    ["triceps", "M50,106 C44,118 42,132 45,146 C51,151 57,147 59,139 C61,126 60,113 57,105 Z"],
    ["forearms", FOREARM],
    ["glutes", "M98,212 L98,258 C88,264 77,262 71,254 C65,243 66,227 72,217 C80,211 90,209 98,212 Z"],
    ["hamstrings", "M69,264 C65,282 65,302 69,318 L94,318 C96,300 96,282 96,266 C88,270 78,270 69,264 Z"],
    ["calves", "M69,332 C62,348 64,368 71,381 C76,385 81,381 83,372 C85,356 84,342 81,332 C77,328 72,328 69,332 Z"],
    ["calves", "M84,332 C89,340 91,356 88,372 C86,378 84,378 84,372 C86,356 86,342 84,332 Z"],
  ];
  function figure(view) {
    const list = view === "front" ? FRONT : BACK;
    let half = list.map(([m, d]) => `<path class="m" data-m="${m}" d="${warp(d)}"/>`).join("");
    if (view === "front") half += ABS.map(([y, h]) => {
      const yc = y + h / 2, x0 = warpX(87.5, yc), x1 = warpX(98, yc);
      return `<rect class="m" data-m="abs" x="${x0.toFixed(1)}" y="${y}" width="${(x1 - x0).toFixed(1)}" height="${h}" rx="3"/>`;
    }).join("");
    const mirror = (x) => `<g transform="translate(200,0) scale(-1,1)">${x}</g>`;
    const s = warp(SIL);
    const sil = `<path class="sil" d="${s}"/><path class="silo" d="${s.slice(0, -2)}"/>`;
    return `<svg class="fig" viewBox="-2 4 204 430">${sil}${mirror(sil)}${half}${mirror(half)}</svg>`;
  }
  const figuresHTML = (size = "") => `<div class="tr-figs ${size}">
    <div><div class="tr-figwrap">${figure("front")}</div><span>frente</span></div>
    <div><div class="tr-figwrap">${figure("back")}</div><span>costas</span></div></div>`;
  function paint(scope, p = {}, s = {}, hl = null) {
    qa(".m", scope).forEach((el) => {
      const m = el.dataset.m;
      el.classList.toggle("on", !!p[m]);
      el.classList.toggle("sec", !p[m] && !!s[m]);
      el.classList.toggle("hl", hl === m);
    });
  }
  function exLoad(id) {
    const p = {}, s = {};
    EX[id].p.forEach((m) => (p[m] = 1));
    (EX[id].s || []).forEach((m) => (s[m] = 1));
    return { p, s };
  }
  // tocar num músculo mostra quando ele é treinado
  function bindFigure(scope, capEl, onReset) {
    qa(".m", scope).forEach((el) => (el.onclick = (ev) => {
      ev.stopPropagation();
      const m = el.dataset.m;
      const days = muscleDays(m, false), lt = lastTrained(m);
      const g = gaps(days), minGap = g.length ? Math.min(...g.map((x) => x.d)) : null;
      paint(scope, { [m]: 1 }, {}, m);
      capEl.innerHTML = `<b>${esc(MUSCLES[m])}</b> · treinos ${days.map((i) => PLAN[i].key).join(" · ") || "—"}
        ${minGap ? ` · menor distância ${plural(minGap, "treino", "treinos")}` : ""}
        <br><span class="muted">Último: ${lt ? `${sinceTxt(daysBetween(lt, todayISO()))} (${fmtD(lt)})` : "sem registro"}</span>`;
      clearTimeout(bindFigure.t);
      bindFigure.t = setTimeout(onReset, 4000);
    }));
  }
  const chips = (ms, cls = "") => ms.map((m) => `<span class="tchip ${cls}">${esc(MUSCLES[m])}</span>`).join("");

  /* ---------- render ---------- */

  async function show() {
    const el = root();
    if (!T.ready) {
      el.innerHTML = `<div class="chart-empty">Carregando treinos…</div>`;
      try { await init(); } catch (e) { el.innerHTML = `<div class="chart-empty">Erro: ${esc(e.message)}</div>`; return; }
    }
    render();
  }

  function render() {
    const el = root();
    if (T.selected) return renderDetail();
    el.innerHTML = `<div class="seg tr-subnav">
        <button data-s="treinos">Treinos</button><button data-s="cargas">Cargas</button><button data-s="recup">Recuperação</button><button data-s="coach">💬 Coach</button>
      </div><div id="trBody"></div>`;
    qa(".tr-subnav button", el).forEach((b) => {
      b.classList.toggle("on", b.dataset.s === T.sub);
      b.onclick = () => { T.sub = b.dataset.s; lsSet("tr.sub", T.sub); render(); el.scrollTop = 0; };
    });
    ({ treinos: renderHome, cargas: renderCargas, recup: renderRecup, coach: renderCoach })[T.sub]();
  }

  function renderHome() {
    const body = q("#trBody");
    const nx = PLAN[nextIdx()];
    const today = todayISO();
    const doneToday = sorted().filter((s) => s.date === today);
    const lastNx = lastSessionOf(nx.key);
    body.innerHTML = `<section class="card tr-hero">
        ${doneToday.length ? `<div class="tr-done">✓ Hoje: Treino ${doneToday.map((s) => s.day).join(" + ")} feito</div>` : ""}
        <div class="muted small">Próximo na sua sequência</div>
        <h2><span class="letter">${nx.key}</span>${esc(nx.title)}</h2>
        <div class="muted small">${nx.ex.length} exercícios · ${daySets(nx)} séries${lastNx ? ` · último ${nx.key}: ${sinceTxt(daysBetween(lastNx.date, today))}` : ""}</div>
        <div class="tr-rot">${PLAN.map((d) => `<span class="${d.key === nx.key ? "cur" : ""}">${d.key}</span>`).join("")}<small>A → F, no seu ritmo</small></div>
        <button class="btn wide" id="trStart">${T.drafts[nx.key] ? "Continuar" : "Começar"} treino ${nx.key}</button>
      </section>
      <section class="card tr-mapcard">
        ${figuresHTML()}
        <div class="tr-cap" id="trCap"></div>
        <div class="tr-legend"><span><i class="on"></i>principal</span><span><i class="sec"></i>secundário</span><span class="muted">toque num músculo</span></div>
      </section>
      <h4 class="tr-h">Seus treinos</h4>
      <div class="tr-cards">${PLAN.map((d) => {
        const last = lastSessionOf(d.key);
        const isNext = d.key === nx.key;
        return `<button class="tr-card ${isNext ? "next" : ""}" data-day="${d.key}">
          <span class="letter">${d.key}</span>
          <div class="tr-cinfo">
            <div class="tr-ctitle">${esc(d.title)}${isNext ? `<span class="badge">próximo</span>` : ""}</div>
            <div class="muted small">${daySets(d)} séries · ${d.ex.length} exercícios · ${last ? `${fmtD(last.date)} (${sinceTxt(daysBetween(last.date, today))})` : "ainda não feito"}</div>
            <div class="tr-chips">${chips(Object.keys(LOADS[idxOf(d.key)].p))}</div>
          </div><span class="tr-go">›</span></button>`;
      }).join("")}</div>`;
    const map = q(".tr-mapcard", body), cap = q("#trCap");
    const reset = () => { const L = LOADS[nextIdx()]; paint(map, L.p, L.s); cap.innerHTML = `<span class="muted">Próximo:</span> <b>Treino ${nx.key}</b> · ${esc(nx.title)}`; };
    reset();
    bindFigure(map, cap, reset);
    q("#trStart").onclick = () => openDay(nx.key);
    qa(".tr-card", body).forEach((c) => (c.onclick = () => openDay(c.dataset.day)));
  }

  function openDay(key) {
    T.selected = key;
    render();
    root().scrollTop = 0;
  }

  /* ---------- registrar treino ---------- */

  const rest = { elapsed: 0, startedAt: null, interval: null };
  const restElapsed = () => rest.elapsed + (rest.startedAt === null ? 0 : Date.now() - rest.startedAt);
  function updateRest() {
    const b = q("#trRest");
    if (!b) return;
    const s = Math.floor(restElapsed() / 1000), running = rest.startedAt !== null;
    q("#trRestTime").textContent = `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
    q("#trRestAct").textContent = running ? "Pausar" : rest.elapsed > 0 ? "Continuar" : "Iniciar";
    b.classList.toggle("running", running);
  }
  function toggleRest() {
    if (rest.startedAt === null) { rest.startedAt = Date.now(); rest.interval = setInterval(updateRest, 250); }
    else { rest.elapsed = restElapsed(); rest.startedAt = null; clearInterval(rest.interval); }
    updateRest();
  }
  function resetRest() { rest.elapsed = 0; if (rest.startedAt !== null) rest.startedAt = Date.now(); updateRest(); }

  function fillFromSession(day, d) {
    const s = T.sessions.find((x) => x.day === day.key && x.date === d.date);
    d.ex = {};
    if (s) for (const e of s.entries) d.ex[e.ex] = e.sets.map((x) => ({ w: x.w ? String(x.w) : "", r: String(x.r) }));
  }
  function getDraft(day) {
    let d = T.drafts[day.key];
    if (!d) { d = { date: todayISO(), ex: {} }; fillFromSession(day, d); }
    for (const [id, n] of day.ex) {
      if (!d.ex[id]) d.ex[id] = [];
      while (d.ex[id].length < n) d.ex[id].push({ w: "", r: "" });
    }
    return d;
  }
  const saveDrafts = () => lsSet("tr.drafts", T.drafts);

  // barra da faixa de reps: onde você parou (○) e a meta de hoje (●)
  function rangeBar(sg, lo, hi) {
    const pos = (r) => Math.min(100, Math.max(0, ((r - lo) / (hi - lo)) * 100));
    const avg = (a) => a.reduce((x, y) => x + y, 0) / a.length;
    const lastAvg = sg.last ? avg(sg.last.sets.filter((s) => (s.w || 0) === sg.top).map((s) => s.r)) : null;
    return `<div class="tr-range" title="faixa de reps">
      <span>${lo}</span>
      <div class="track">
        ${lastAvg !== null && !sg.up ? `<i class="mk last" style="left:${pos(lastAvg)}%"></i>` : ""}
        <i class="mk goal" style="left:${pos(avg(sg.reps))}%"></i>
      </div>
      <span>${hi}</span>
    </div>`;
  }

  // compara cada série digitada com a meta de hoje e com o último treino (carga de trabalho)
  function setFeedback(row, id, sg) {
    const [lo, hi] = EX[id].reps;
    qa(".tr-set", row).forEach((set, i) => {
      const fb = q(".fb", set);
      const r = num(q("input.r", set).value);
      const w = num(q("input.w", set).value) ?? sg.w ?? 0;
      fb.className = "fb";
      if (!r) { fb.textContent = ""; return; }
      const target = sg.reps[i] ?? lo;
      const prev = sg.last?.sets[i];
      let txt = "", cls = "same";
      if (r > hi) { txt = "↑ carga"; cls = "good"; }
      else if (sg.last && w > sg.top) { txt = `▲ +${kg(w - sg.top)}kg`; cls = "good"; }
      else if (r >= target && (sg.w === null || w >= sg.w)) { txt = "✓ meta"; cls = "good"; }
      else if (prev && w === (prev.w || 0) && r > prev.r) { txt = `+${r - prev.r} rep`; cls = "good"; }
      else if (r < lo) { txt = "abaixo"; cls = "bad"; }
      else txt = `meta ${target}`;
      fb.textContent = txt;
      fb.classList.add(cls);
    });
  }

  /* ---------- recompensa: exercício melhor que o último ---------- */

  const PRAISE = ["Evoluiu! 🔥", "Mais forte que da última vez 💪", "Progresso é isso 📈", "Subiu o nível ⚡",
    "Bateu o último treino 👊", "Tá ficando monstro 🦍", "Constância pagando 🏆"];
  const volume = (sets) => sets.reduce((a, s) => a + (s.w ? s.w * s.r : s.r), 0);

  // séries completas de hoje (com a carga sugerida onde ficou em branco) ou null se ainda falta série
  function todaySets(id, n, draft, sg) {
    const out = [];
    for (const s of draft.ex[id].slice(0, n)) {
      const r = num(s.r);
      if (!r) return null;
      const w = num(s.w) ?? (EX[id].bw ? sg.w || 0 : sg.w);
      if (w === null) return null;
      out.push({ w, r });
    }
    return out;
  }

  function improved(id, n, draft) {
    const sg = suggest(id, n, draft.date);
    if (!sg.last) return false;
    const now = todaySets(id, n, draft, sg);
    if (!now) return false;
    const last = sg.last.sets.filter((s) => s.r > 0);
    return volume(now) > volume(last) + 0.01 || sessionMetric(now).v > sessionMetric(last).v + 0.05;
  }

  let audio = null;
  function chime() {
    if (!ls("tr.sound", true)) return;
    try {
      audio = audio || new (window.AudioContext || window.webkitAudioContext)();
      const t0 = audio.currentTime;
      [[784, 0], [1175, 0.09]].forEach(([f, dt]) => {  // sol → ré, curtinho e baixo
        const o = audio.createOscillator(), g = audio.createGain();
        o.type = "sine";
        o.frequency.value = f;
        g.gain.setValueAtTime(0, t0 + dt);
        g.gain.linearRampToValueAtTime(0.07, t0 + dt + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + dt + 0.35);
        o.connect(g).connect(audio.destination);
        o.start(t0 + dt);
        o.stop(t0 + dt + 0.4);
      });
    } catch { /* sem áudio, tudo bem */ }
    navigator.vibrate?.(25);
  }

  // fim do treino: acorde curto e grave (tipo "fase concluída") + cartão de parabéns que some sozinho
  function victory() {
    if (!ls("tr.sound", true)) return;
    try {
      audio = audio || new (window.AudioContext || window.webkitAudioContext)();
      const t0 = audio.currentTime + 0.02;
      const out = audio.createGain();
      const lp = audio.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.value = 2600;
      out.gain.value = 0.9;
      lp.connect(out).connect(audio.destination);
      const note = (f, at, dur, vol, type = "triangle") => {
        const o = audio.createOscillator(), g = audio.createGain();
        o.type = type;
        o.frequency.value = f;
        g.gain.setValueAtTime(0, t0 + at);
        g.gain.linearRampToValueAtTime(vol, t0 + at + 0.015);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + dur);
        o.connect(g).connect(lp);
        o.start(t0 + at);
        o.stop(t0 + at + dur + 0.05);
      };
      // subida rápida sol–si–ré e um acorde de sol que fica soando
      [[392, 0], [494, 0.07], [587, 0.14]].forEach(([f, at]) => note(f, at, 0.25, 0.05));
      [196, 392, 494, 587, 784].forEach((f, i) => note(f, 0.22, 1.3, i ? 0.035 : 0.05, i ? "triangle" : "sine"));
    } catch { /* sem áudio */ }
    navigator.vibrate?.([18, 50, 28]);
  }

  function finishCelebration(day, evolved, total, records) {
    victory();
    const el = document.createElement("div");
    el.className = "tr-finish";
    el.innerHTML = `<div class="box">
        <svg viewBox="0 0 52 52" class="ck"><circle cx="26" cy="26" r="23"/><path d="M15 27 l7 7 l15 -16"/></svg>
        <h3>Treino ${day.key} concluído</h3>
        <p>${evolved ? `${evolved} de ${total} exercícios evoluíram 💪` : "Mais um na conta. Constância é o que dá resultado."}</p>
        ${records.length ? `<p class="rec">🏆 Recorde: ${records.map(esc).join(", ")}</p>` : ""}
        <p class="muted small">Próximo: Treino ${PLAN[nextIdx()].key} · ${esc(PLAN[nextIdx()].title)}</p>
      </div>`;
    el.onclick = () => el.remove();
    document.body.appendChild(el);
    setTimeout(() => el.classList.add("out"), 3600);
    setTimeout(() => el.remove(), 4000);
  }

  // mostra/tira o selo; a festa (brilho + som) só na primeira vez de cada exercício no treino
  function checkReward(row, id, n, draft, dayKey) {
    const ok = improved(id, n, draft);
    const badge = q(".tr-badge", row);
    badge.classList.toggle("hidden", !ok);
    if (!ok) return;
    draft.cheered = draft.cheered || {};
    if (draft.cheered[id]) return;
    draft.cheered[id] = PRAISE[Math.floor(Math.random() * PRAISE.length)];
    T.drafts[dayKey] = draft; saveDrafts();
    badge.textContent = draft.cheered[id];
    row.classList.remove("cheer");
    void row.offsetWidth;  // reinicia a animação
    row.classList.add("cheer");
    chime();
  }

  function exBlock(id, n, k, draft) {
    const ex = EX[id], sg = suggest(id, n, draft.date), [lo, hi] = ex.reps;
    const wPh = sg.w === null ? "kg?" : sg.w ? kg(sg.w) : "PC";
    const meta = `${sg.w === null ? "? kg" : sg.w ? kg(sg.w) + " kg" : "PC"} × ${sg.reps.join(" · ")}`;
    return `<div class="tr-ex" data-ex="${id}">
      <button class="tr-exhead" type="button">
        <span class="exn">${k + 1}</span>
        <div><div class="tr-exname">${esc(ex.name)}</div>
          <div class="muted small">${n} séries · faixa ${lo}–${hi}</div></div>
        <span class="tr-badge hidden">${esc(draft.cheered?.[id] || PRAISE[0])}</span>
      </button>
      <div class="tr-prog">
        <div class="col"><span>${sg.last ? `Última · ${fmtD(sg.last.date)}` : "Última"}</span>
          <b>${sg.last ? sg.last.sets.map((s) => `${s.w ? kg(s.w) : "PC"}×${s.r}`).join(" · ") : "—"}</b></div>
        <div class="arrow">→</div>
        <div class="col today ${sg.up ? "up" : ""} ${sg.down ? "down" : ""}"><span>Hoje</span><b>${meta}</b>
          <em>${sg.first ? "1ª vez" : sg.up ? `▲ +${kg(sg.w - sg.top)} kg` : sg.down ? `▼ −${kg(sg.top - sg.w)} kg` : "+1 rep"}</em></div>
      </div>
      ${rangeBar(sg, lo, hi)}
      <div class="tr-msg">${esc(sg.msg)}</div>
      <div class="tr-sets">${draft.ex[id].slice(0, n).map((s, i) => `<label class="tr-set">
          <span class="sn">S${i + 1}</span>
          <input class="w" data-i="${i}" inputmode="decimal" placeholder="${wPh}" value="${esc(s.w)}" aria-label="${esc(ex.name)} série ${i + 1} carga"><span class="u">kg</span>
          <span class="x">×</span>
          <input class="r" data-i="${i}" inputmode="numeric" placeholder="${sg.reps[i]}" value="${esc(s.r)}" aria-label="${esc(ex.name)} série ${i + 1} reps"><span class="u">reps</span>
          <span class="fb" data-i="${i}"></span>
        </label>`).join("")}</div>
      <button class="btn ghost tr-usegoal" type="button" ${sg.w === null ? "disabled" : ""}>Bati a meta</button>
    </div>`;
  }

  function renderDetail() {
    const el = root();
    const day = PLAN[idxOf(T.selected)], idx = idxOf(day.key);
    const draft = getDraft(day);
    const existing = T.sessions.find((x) => x.day === day.key && x.date === draft.date);
    el.innerHTML = `<div class="tr-dhead">
        <button class="icon-btn" id="trBack" aria-label="Voltar">‹</button>
        <div class="tr-dtitle"><span class="letter">${day.key}</span>${esc(day.title)}</div>
        <button class="icon-btn tr-sound" id="trSound" aria-label="Som da recompensa">${ls("tr.sound", true) ? "🔔" : "🔕"}</button>
        <input type="date" id="trDate" value="${draft.date}" max="${todayISO()}" aria-label="Data do treino">
      </div>
      <div class="tr-restbar">
        <div id="trRest" class="tr-rest" role="group" aria-label="Cronômetro de descanso">
          <button id="trRestReset" class="side left">Zerar</button>
          <button id="trRestMid" class="mid" aria-label="Iniciar ou pausar"><span class="muted small">Descanso</span><b id="trRestTime">00:00</b></button>
          <button id="trRestAct" class="side right">Iniciar</button>
        </div>
      </div>
      ${existing ? `<div class="tr-notice">Já tem um Treino ${day.key} salvo em ${fmtD(draft.date)}. Salvar substitui.</div>` : ""}
      <section class="card tr-mapcard small">${figuresHTML("small")}<div class="tr-cap" id="trCap"></div></section>
      <div class="muted small tr-help">Preencha carga e reps de cada série. Os números apagados são a meta de hoje.</div>
      ${day.ex.map(([id, n], k) => exBlock(id, n, k, draft)).join("")}
      <div class="tr-foot"><button class="btn ghost" id="trClear">Limpar</button><button class="btn" id="trSave">Salvar treino ${day.key}</button></div>
      <ul class="tr-tips muted small">
        <li>Séries com <b>1–2 reps na reserva</b>; a última pode ir perto da falha.</li>
        <li>Topo da faixa em todas as séries → a carga sobe no próximo treino.</li>
        <li>Descanso: <b>2–3 min</b> nos compostos, <b>1–2 min</b> nos isoladores.</li>
      </ul>`;

    const map = q(".tr-mapcard", el), cap = q("#trCap");
    const reset = () => { paint(map, LOADS[idx].p, LOADS[idx].s); cap.innerHTML = `<b>Treino ${day.key}</b> · ${esc(day.title)} <span class="muted">· toque num exercício</span>`; };
    reset();
    bindFigure(map, cap, reset);

    q("#trBack").onclick = () => { T.selected = null; render(); };
    q("#trSound").onclick = (e) => {
      const on = !ls("tr.sound", true);
      lsSet("tr.sound", on);
      e.currentTarget.textContent = on ? "🔔" : "🔕";
      toast(on ? "Som da recompensa ligado" : "Som da recompensa desligado");
      if (on) chime();
    };
    q("#trRestMid").onclick = toggleRest;
    q("#trRestAct").onclick = toggleRest;
    q("#trRestReset").onclick = resetRest;
    updateRest();
    q("#trDate").onchange = (e) => {
      draft.date = e.target.value || todayISO();
      fillFromSession(day, draft);
      T.drafts[day.key] = draft; saveDrafts();
      renderDetail();
    };
    q("#trClear").onclick = () => { delete T.drafts[day.key]; saveDrafts(); renderDetail(); };
    q("#trSave").onclick = () => saveSession(day, draft);

    qa(".tr-ex", el).forEach((row) => {
      const id = row.dataset.ex, n = day.ex.find(([e]) => e === id)[1];
      q(".tr-exhead", row).onclick = () => {
        const L = exLoad(id);
        paint(map, L.p, L.s);
        cap.innerHTML = `<b>${esc(EX[id].name)}</b> · ${chips(EX[id].p)}${chips(EX[id].s || [], "sec")}`;
        map.scrollIntoView({ behavior: "smooth", block: "nearest" });
        clearTimeout(bindFigure.t);
        bindFigure.t = setTimeout(reset, 5000);
      };
      qa("input", row).forEach((inp) => inp.addEventListener("input", () => {
        const i = +inp.dataset.i, field = inp.classList.contains("w") ? "w" : "r";
        draft.ex[id][i][field] = inp.value;
        if (field === "w" && i === 0) {
          // a carga da 1ª série preenche as outras que ainda não foram mexidas
          qa("input.w", row).forEach((o, j) => { if (j > 0 && !o.dataset.touched) { o.value = inp.value; draft.ex[id][j].w = inp.value; } });
        } else if (field === "w") inp.dataset.touched = "1";
        T.drafts[day.key] = draft; saveDrafts();
        setFeedback(row, id, suggest(id, n, draft.date));
        checkReward(row, id, n, draft, day.key);
      }));
      setFeedback(row, id, suggest(id, n, draft.date));
      q(".tr-badge", row).classList.toggle("hidden", !improved(id, n, draft));
      q(".tr-usegoal", row).onclick = () => {
        const sg = suggest(id, n, draft.date);
        qa("input.w", row).forEach((o, j) => { if (!o.value) { o.value = sg.w ? kg(sg.w) : ""; draft.ex[id][j].w = o.value; } });
        qa("input.r", row).forEach((o, j) => { o.value = sg.reps[j]; draft.ex[id][j].r = String(sg.reps[j]); });
        T.drafts[day.key] = draft; saveDrafts();
        setFeedback(row, id, sg);
        checkReward(row, id, n, draft, day.key);
      };
    });
  }

  async function saveSession(day, draft) {
    const entries = [];
    let missing = null;
    for (const [id, n] of day.ex) {
      const ex = EX[id], sg = suggest(id, n, draft.date), sets = [];
      for (const s of draft.ex[id]) {
        const r = num(s.r);
        if (!r) continue;
        let w = num(s.w);
        if (w === null) w = ex.bw ? sg.w || 0 : sg.w;
        if (w === null) { missing = ex.name; continue; }
        sets.push({ w, r });
      }
      if (sets.length) entries.push({ ex: id, sets });
    }
    if (missing) return toast(`Coloca a carga de "${missing}"`);
    if (!entries.length) return toast("Nenhuma série preenchida (reps)");
    const evolved = day.ex.filter(([id, n]) => improved(id, n, draft)).length;
    const records = [];
    for (const e of entries) {
      const prev = exHistory(e.ex).filter((h) => h.date !== draft.date);
      if (!prev.length) continue;
      const best = Math.max(...prev.map((h) => sessionMetric(h.sets).v));
      const now = sessionMetric(e.sets);
      if (now.v > best + 0.05) records.push(`${EX[e.ex].name} (${kg(Math.round(best * 10) / 10)} → ${kg(Math.round(now.v * 10) / 10)})`);
    }
    try {
      T.sessions = (await api("/api/workouts", { method: "PUT", body: JSON.stringify({ date: draft.date, day: day.key, entries }) })).sessions;
      delete T.drafts[day.key]; saveDrafts();
      finishCelebration(day, evolved, entries.length, records);
      T.selected = null;
      render();
      if (typeof load === "function") load(); // atualiza diário/calendário do app de calorias
    } catch (e) {
      toast("Erro ao salvar: " + e.message);
    }
  }

  /* ---------- cargas (progresso por exercício) ---------- */

  function planExercises() {
    const seen = new Set(), out = [];
    PLAN.forEach((d) => d.ex.forEach(([id, n]) => {
      if (seen.has(id)) return;
      seen.add(id);
      out.push({ id, n, days: PLAN.filter((x) => x.ex.some(([e]) => e === id)).map((x) => x.key) });
    }));
    return out;
  }

  function renderCargas() {
    const body = q("#trBody");
    const list = planExercises();
    if (!T.progEx) {
      const withHist = list.find((e) => exHistory(e.id).length);
      T.progEx = (withHist || list[0]).id;
    }
    const item = list.find((e) => e.id === T.progEx) || list[0];
    const id = item.id, ex = EX[id], hist = exHistory(id), sg = suggest(id, item.n);
    const best = hist.length ? Math.max(...hist.flatMap((h) => h.sets.map((s) => s.w || 0))) : 0;
    const bestE = hist.length ? Math.max(...hist.map((h) => sessionMetric(h.sets).v)) : 0;
    const unit = hist.length ? sessionMetric(hist[0].sets).unit : "";
    const sessions = sorted().reverse();

    body.innerHTML = `<section class="card">
        <select id="trExSel" class="tr-select">${PLAN.map((d) => `<optgroup label="Treino ${d.key} · ${esc(d.title)}">${d.ex.map(([e]) =>
          `<option value="${e}" ${e === id ? "selected" : ""}>${esc(EX[e].name)}${exHistory(e).length ? "" : " (sem registro)"}</option>`).join("")}</optgroup>`).join("")}</select>
        <div class="tr-chips" style="margin-top:8px">faixa ${ex.reps[0]}–${ex.reps[1]} reps · ${chips(ex.p)}${chips(ex.s || [], "sec")}</div>
        <div class="tr-tiles">
          <div><span>Sessões</span><b>${hist.length}</b></div>
          <div><span>Maior carga</span><b>${best ? kg(best) + " kg" : "—"}</b></div>
          <div><span>Melhor ${unit.includes("e1RM") ? "e1RM" : "volume"}</span><b>${bestE ? kg(Math.round(bestE * 10) / 10) : "—"}</b></div>
          <div class="accent"><span>Meta do próximo</span><b>${sg.w === null ? "? kg" : sg.w ? kg(sg.w) + " kg" : "PC"} × ${sg.reps.join("·")}</b></div>
        </div>
        <div class="tr-msg">${esc(sg.msg)}</div>
      </section>
      <section class="card">
        <h4>${unit.includes("e1RM") || !unit ? "Força estimada (e1RM, kg)" : "Volume (reps totais)"}</h4>
        <div id="trChart" class="chart"></div>
        ${unit.includes("e1RM") ? `<div class="muted small">e1RM = carga × (1 + reps/30), melhor série do dia.</div>` : ""}
      </section>
      <section class="card">
        <h4>Histórico</h4>
        ${hist.length ? [...hist].reverse().map((h) => `<div class="tr-hrow"><span><b>${fmtD(h.date)}</b> <span class="muted">· ${h.day}</span></span>
          <span>${h.sets.map((s) => `${s.w ? kg(s.w) : "PC"}×${s.r}`).join(" · ")}</span></div>`).join("")
          : `<div class="chart-empty">As séries salvas desse exercício aparecem aqui.</div>`}
      </section>
      <section class="card">
        <h4>Treinos salvos</h4>
        ${sessions.length ? sessions.map((s) => `<div class="tr-srow">
          <span class="letter sm">${s.day}</span>
          <div class="tr-sinfo"><b>${fmtD(s.date)}</b><div class="muted small">${plural(s.entries.length, "exercício", "exercícios")} · ${s.entries.reduce((a, e) => a + e.sets.length, 0)} séries</div></div>
          <button class="btn ghost sm" data-open="${s.id}">Abrir</button>
          <button class="btn ghost sm danger ${T.armDelete === s.id ? "armed" : ""}" data-del="${s.id}">${T.armDelete === s.id ? "Confirmar" : "Apagar"}</button>
        </div>`).join("") : `<div class="chart-empty">Nenhum treino salvo.</div>`}
      </section>`;

    q("#trExSel").onchange = (e) => { T.progEx = e.target.value; renderCargas(); };
    drawChart(q("#trChart"), hist.map((h) => ({ date: h.date, ...sessionMetric(h.sets) })));
    qa("[data-del]", body).forEach((b) => (b.onclick = async () => {
      const sid = b.dataset.del;
      if (T.armDelete !== sid) { T.armDelete = sid; return renderCargas(); }
      T.armDelete = null;
      T.sessions = (await api(`/api/workouts/${sid}`, { method: "DELETE" })).sessions;
      toast("Treino apagado");
      renderCargas();
      if (typeof load === "function") load();
    }));
    qa("[data-open]", body).forEach((b) => (b.onclick = () => {
      const s = T.sessions.find((x) => x.id === b.dataset.open);
      if (!s || idxOf(s.day) < 0) return;
      const d = { date: s.date, ex: {} };
      fillFromSession(PLAN[idxOf(s.day)], d);
      T.drafts[s.day] = d; saveDrafts();
      openDay(s.day);
    }));
  }

  function drawChart(box, pts) {
    if (!pts.length) { box.innerHTML = `<div class="chart-empty">Sem registros ainda. Salva um treino com esse exercício pra ver a curva.</div>`; return; }
    if (pts.length < 2) { box.innerHTML = `<div class="chart-empty">${kg(Math.round(pts[0].v * 10) / 10)} em ${fmtD(pts[0].date)}. Com mais um treino já aparece a linha.</div>`; return; }
    const W = box.clientWidth || 340, H = 170, L = 38, R = 10, Tp = 30, B = 22;
    const vs = pts.map((p) => p.v);
    let lo = Math.min(...vs), hi = Math.max(...vs);
    if (lo === hi) { lo -= 5; hi += 5; }
    const pad = (hi - lo) * 0.15; lo -= pad; hi += pad;
    const X = (i) => L + (i * (W - L - R)) / (pts.length - 1);
    const Y = (v) => Tp + (1 - (v - lo) / (hi - lo)) * (H - Tp - B);
    let g = "";
    for (let i = 0; i <= 3; i++) {
      const v = lo + ((hi - lo) * i) / 3;
      g += `<line class="grid" x1="${L}" x2="${W - R}" y1="${Y(v)}" y2="${Y(v)}"/><text class="axis" x="${L - 6}" y="${Y(v) + 3}" text-anchor="end">${Math.round(v)}</text>`;
    }
    g += `<text class="axis" x="${L}" y="${H - 6}">${fmtD(pts[0].date)}</text><text class="axis" x="${W - R}" y="${H - 6}" text-anchor="end">${fmtD(pts[pts.length - 1].date)}</text>`;
    const path = pts.map((p, i) => `${i ? "L" : "M"}${X(i).toFixed(1)},${Y(p.v).toFixed(1)}`).join("");
    box.innerHTML = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="Gráfico de evolução">${g}
      <path class="line" d="${path}"/>${pts.map((p, i) => `<circle class="pt" cx="${X(i)}" cy="${Y(p.v)}" r="4"/>`).join("")}
      <line class="cross hidden" y1="${Tp - 6}" y2="${H - B}"/><circle class="pt hover hidden" r="6"/></svg><div class="tip hidden"></div>`;
    const svg = q("svg", box), cross = q(".cross", svg), hp = q(".hover", svg), tip = q(".tip", box);
    const showTip = (ev) => {
      const r = svg.getBoundingClientRect(), mx = ((ev.clientX - r.left) / r.width) * W;
      let bi = 0;
      pts.forEach((_, i) => { if (Math.abs(X(i) - mx) < Math.abs(X(bi) - mx)) bi = i; });
      const p = pts[bi], px = X(bi);
      cross.setAttribute("x1", px); cross.setAttribute("x2", px);
      hp.setAttribute("cx", px); hp.setAttribute("cy", Y(p.v));
      [cross, hp, tip].forEach((e) => e.classList.remove("hidden"));
      tip.innerHTML = `<b>${kg(Math.round(p.v * 10) / 10)}</b> <span class="muted">${p.unit} · ${fmtD(p.date)}</span>`;
      tip.style.left = Math.min(Math.max((px / W) * r.width, 70), r.width - 70) + "px";
    };
    svg.addEventListener("pointermove", showTip);
    svg.addEventListener("pointerdown", showTip);
    svg.addEventListener("pointerleave", (ev) => { if (ev.pointerType === "mouse") [cross, hp, tip].forEach((e) => e.classList.add("hidden")); });
  }

  /* ---------- recuperação ---------- */

  function renderRecup() {
    const body = q("#trBody");
    const withSec = T.recSec, nx = nextIdx();
    const rows = Object.keys(MUSCLES).map((m) => {
      const days = muscleDays(m, withSec), g = gaps(days);
      const minGap = g.length ? Math.min(...g.map((x) => x.d)) : null;
      const perCycle = PLAN.reduce((a, _, i) => a + (LOADS[i].p[m] || 0) + (withSec ? (LOADS[i].s[m] || 0) / 2 : 0), 0);
      const lt = lastTrained(m), rg = realGaps(m);
      const cls = minGap === null ? "" : minGap <= 1 ? "bad" : minGap === 2 ? "mid" : "good";
      const cells = PLAN.map((_, i) => {
        const p = LOADS[i].p[m] || 0, s = LOADS[i].s[m] || 0;
        if (p) return `<span class="rc p" style="--a:${Math.min(1, 0.35 + p / 8)}">${p}</span>`;
        if (s) return `<span class="rc s">${withSec ? "½" : "·"}</span>`;
        return `<span class="rc"></span>`;
      }).join("");
      return `<button class="tr-rrow ${T.recMuscle === m ? "sel" : ""}" data-m="${m}">
        <div class="tr-rtop"><b>${esc(MUSCLES[m])}</b><span class="pill ${cls}" title="menor distância entre treinos">${minGap ?? "—"}</span></div>
        <div class="tr-rcells">${cells}</div>
        <div class="muted small">${perCycle ? `${kg(Math.round(perCycle * 10) / 10)} séries/ciclo` : "não treinado"} · último ${lt ? sinceTxt(daysBetween(lt, todayISO())) : "—"}${rg ? ` · intervalo real ${kg(Math.round(rg.avg * 10) / 10)}d` : ""}</div>
      </button>`;
    }).join("");
    body.innerHTML = `<section class="card tr-mapcard sticky">${figuresHTML("small")}<div class="tr-cap" id="trCap"></div></section>
      <div class="card">
        <div class="muted small">Número = séries do músculo em cada treino (A→F). A bolinha mostra a <b>menor distância</b> entre dois estímulos:
          <span class="pill bad">1</span> treinos seguidos, <span class="pill mid">2</span>, <span class="pill good">3+</span>.</div>
        <label class="tr-toggle"><input type="checkbox" id="trSec" ${withSec ? "checked" : ""}> Contar trabalho indireto (½ série)</label>
        <div class="tr-rhead">${PLAN.map((d, i) => `<span class="${i === nx ? "cur" : ""}">${d.key}</span>`).join("")}</div>
      </div>
      <div class="tr-rlist">${rows}</div>`;
    const map = q(".tr-mapcard", body), cap = q("#trCap");
    const showMuscle = () => {
      const m = T.recMuscle;
      if (!m) { paint(map); cap.innerHTML = `<span class="muted">Toque num músculo da lista</span>`; return; }
      paint(map, { [m]: 1 }, {}, m);
      cap.innerHTML = `<b>${esc(MUSCLES[m])}</b> · treinos ${muscleDays(m, withSec).map((i) => PLAN[i].key).join(" · ") || "—"}`;
    };
    showMuscle();
    q("#trSec").onchange = (e) => { T.recSec = e.target.checked; lsSet("tr.recSec", T.recSec); renderRecup(); };
    qa(".tr-rrow", body).forEach((r) => (r.onclick = () => {
      T.recMuscle = T.recMuscle === r.dataset.m ? null : r.dataset.m;
      qa(".tr-rrow", body).forEach((x) => x.classList.toggle("sel", x.dataset.m === T.recMuscle));
      showMuscle();
    }));
  }

  /* ---------- coach: conversa que analisa e edita o plano ---------- */

  const COACH_SUGGESTIONS = [
    "O que você acha que eu tenho que melhorar no meu treino?",
    "Meu volume por músculo tá bom?",
    "Qual o melhor dia pra colocar treino de pescoço? Tenho uma faixa pra usar no cabo.",
    "Troca algum exercício que tá estagnado",
  ];
  let coachBusy = false;

  function renderCoach() {
    const body = q("#trBody");
    // a conversa usa a barra de baixo do app (a mesma das outras abas)
    body.innerHTML = `<div class="chat tr-coachchat" id="coachChat"></div>`;
    drawCoach();
  }

  function drawCoach(pending) {
    const box = q("#coachChat");
    if (!box) return;
    box.innerHTML = "";
    if (!T.coach.length && !pending) {
      box.innerHTML = `<div class="msg momo">Fala! Aqui eu cuido do seu treino 🏋️ Vejo seu plano A→F, as cargas que você registrou e a recuperação de cada músculo.
Pode pedir análise ou mudança, tipo "adiciona um exercício de pescoço" ou "troca o RDL por stiff". Toda mudança tem botão de desfazer.</div>
        <div class="tr-sugs">${COACH_SUGGESTIONS.map((s) => `<button class="tr-sug">${esc(s)}</button>`).join("")}</div>`;
      qa(".tr-sug", box).forEach((b) => (b.onclick = () => sendCoach(b.textContent)));
      return;
    }
    const lastChange = T.coach.map((m, i) => (m.changes?.length && !m.undone ? i : -1)).reduce((a, b) => Math.max(a, b), -1);
    T.coach.forEach((m, i) => {
      const div = document.createElement("div");
      div.className = "msg " + (m.role === "user" ? "user" : "momo");
      div.appendChild(document.createTextNode(m.text));
      if (m.changes?.length) {
        const c = document.createElement("div");
        c.className = "chips";
        c.innerHTML = m.changes.map((t) => `<div class="chip plan ${m.undone ? "gone" : ""}"><span>${esc(t)}</span></div>`).join("");
        if (i === lastChange && T.canUndo) {
          const u = document.createElement("button");
          u.className = "btn ghost sm tr-undo";
          u.textContent = "↩ Desfazer";
          u.onclick = undoCoach;
          c.appendChild(u);
        }
        div.appendChild(c);
      }
      box.appendChild(div);
    });
    if (pending) {
      box.insertAdjacentHTML("beforeend", `<div class="msg user">${esc(pending)}</div><div class="msg momo typing">analisando seu treino…</div>`);
    }
    requestAnimationFrame(() => (root().scrollTop = root().scrollHeight));
  }

  async function sendCoach(textOverride) {
    const text = String(textOverride || "").trim();
    if (!text || coachBusy) return;
    coachBusy = true;
    if (!q("#coachChat")) { T.sub = "coach"; lsSet("tr.sub", T.sub); T.selected = null; render(); }
    drawCoach(text);
    try {
      const ps = await api("/api/coach", { method: "POST", body: JSON.stringify({ text }) });
      const changed = ps.coach_chat[ps.coach_chat.length - 1]?.changes?.length;
      applyPlan(ps);
      drawCoach();
      if (changed) toast("Plano atualizado");
    } catch (e) {
      const t = q("#coachChat .typing");
      if (t) { t.textContent = "Erro: " + e.message; t.classList.remove("typing"); }
    } finally {
      coachBusy = false;
    }
  }

  async function undoCoach() {
    applyPlan(await api("/api/coach/undo", { method: "POST" }));
    drawCoach();
    toast("Mudança desfeita");
  }

  window.Treino = {
    show,
    // o chat pode registrar treino: recarrega as sessões na próxima vez que abrir a aba
    invalidate: async () => { if (T.ready) T.sessions = (await api("/api/workouts")).sessions; },
    open: (key) => { T.selected = key; },
    sendFromComposer: async (text) => { if (!T.ready) await show(); return sendCoach(text); },
  };
})();
