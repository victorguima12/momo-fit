window.MOMO_BUILD = {"version": "2026.10.14.0848", "updates": "https://raw.githubusercontent.com/victorguima12/momo-fit/main"};
