// Aba Rotina: sono (registro + 14 noites), despertador no Relógio do celular e a agenda do dia
// (uma "planilha" simples: horário → o que fazer), com lembretes por notificação.

(() => {
  const DAYS = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"];
  const FACES = ["😫", "😕", "😐", "🙂", "😄"];
  const native = () => window.Capacitor?.isNativePlatform?.();
  const P = () => window.Capacitor?.Plugins || {};
  // o despertador e os lembretes vêm do APK; quem ainda está com o APK antigo recebe um aviso
  const hasPlugin = (n) => native() && !!P()[n];
  const OLD_APK = "Pra isso, instale o APK novo do Momo (uma vez só)";
  const androidDay = (i) => ((i + 1) % 7) + 1;  // 0=seg → 2 ... 6=dom → 1 (padrão do Android/Capacitor)
  const root = () => $("#viewRoutine");
  let st = null, editing = null, quality = null;

  async function show() {
    st = await api(`/api/routine?date=${todayISO()}`);
    render();
    syncReminders();
  }
  const post = async (path, body, method = "POST") => { st = await api(path, { method, body: body ? JSON.stringify(body) : undefined }); render(); syncReminders(); };
  const fmtH = (h) => { const hh = Math.floor(h), mm = Math.round((h - hh) * 60); return `${hh}h${mm ? String(mm).padStart(2, "0") : ""}`; };
  const toMin = (t) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
  const fromMin = (m) => { m = ((m % 1440) + 1440) % 1440; return `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`; };

  function render() {
    const s = st.sleep, last = s.today, now = new Date(), nowMin = now.getHours() * 60 + now.getMinutes();
    const nextIdx = st.today.findIndex((r) => toMin(r.time) >= nowMin);
    const alarm = st.alarm, wake = alarm?.time || last?.wake || "07:00";
    quality = quality ?? last?.quality ?? null;
    let h = "";

    // ---- sono ----
    h += `<section class="card">
      <div class="chart-head"><h4>😴 Sono</h4>
        <div class="hero">${last?.hours ? `<b>${fmtH(last.hours)}</b><div class="delta">última noite${last.quality ? " · " + FACES[last.quality - 1] : ""}</div>` : `<span class="muted small">registre a noite de hoje</span>`}</div></div>
      <form class="rt-sleep" id="rtSleep">
        <label><span>Deitei</span><input type="time" name="bed" value="${last?.bed || "23:00"}"></label>
        <label><span>Acordei</span><input type="time" name="wake" value="${last?.wake || wake}"></label>
        <div class="rt-faces">${FACES.map((f, i) => `<button type="button" data-q="${i + 1}" class="${quality === i + 1 ? "on" : ""}" aria-label="qualidade ${i + 1}">${f}</button>`).join("")}</div>
        <button class="btn sm" type="submit">${last ? "Atualizar" : "Salvar"}</button>
      </form>
      <div id="rtChart" class="chart"></div>
      <div class="muted small rt-avg">${s.avg7 ? `Média 7 noites: <b>${fmtH(s.avg7)}</b> · meta ` : "Meta "}
        <select id="rtGoal">${[6, 6.5, 7, 7.5, 8, 8.5, 9].map((g) => `<option value="${g}" ${s.goal === g ? "selected" : ""}>${fmtH(g)}</option>`).join("")}</select></div>
    </section>`;

    // ---- despertador ----
    const days = alarm?.days || [true, true, true, true, true, false, false];
    h += `<section class="card ${alarm?.pending ? "rt-pending" : ""}">
      <h4>⏰ Despertador</h4>
      <div class="rt-alarm">
        <input type="time" id="rtAlarmTime" value="${wake}">
        <div class="rt-days" id="rtAlarmDays">${DAYS.map((d, i) => `<button type="button" class="${days[i] ? "on" : ""}" data-i="${i}">${d[0].toUpperCase()}</button>`).join("")}</div>
      </div>
      <div class="muted small" id="rtBed"></div>
      <div class="row-btns">
        <button class="btn ghost sm" id="rtShowAlarms">Ver alarmes</button>
        <button class="btn sm" id="rtSetAlarm">${alarm?.pending ? "Criar alarme pedido no chat" : "Criar no Relógio"}</button>
      </div>
    </section>`;

    // ---- agenda do dia ----
    h += `<section class="card">
      <div class="chart-head"><h4>🗓️ Seu dia · ${DAYS[st.weekday]}</h4><button class="btn ghost sm" id="rtNew">+ Item</button></div>
      ${st.today.length ? `<div class="rt-list">${st.today.map((r, i) => `<div class="rt-row ${i === nextIdx ? "next" : ""} ${toMin(r.time) < nowMin && i !== nextIdx ? "past" : ""} ${r.done ? "done" : ""}" data-id="${r.id}" data-kind="${r.kind}">
          <span class="t">${r.time}</span>
          <span class="ti">${r.icon || "•"} ${esc(r.title)}${r.detail ? ` <small class="muted">${esc(r.detail)}</small>` : ""}${i === nextIdx ? ' <span class="badge">próximo</span>' : ""}</span>
          ${r.kind === "item" ? `<button class="rt-bell ${r.remind ? "on" : ""}" aria-label="lembrete">${r.remind ? "🔔" : "🔕"}</button>` : `<span class="muted small">${r.done ? "✓" : "›"}</span>`}
        </div>`).join("")}</div>`
        : `<div class="chart-empty">Monte o seu dia: acordar, treino, refeições, trabalho, dormir…<br>Ou fala pro Momo: "minha rotina é acordar 6h30, treino 7h, almoço 12h…"</div>`}
      ${st.all.length ? `<details class="rt-all"><summary class="muted small">Todos os itens (${st.all.length})</summary>
        ${st.all.map((r) => `<div class="rt-row" data-id="${r.id}" data-kind="item"><span class="t">${r.time}</span>
          <span class="ti">${r.icon || "•"} ${esc(r.title)} <small class="muted">${r.days.every(Boolean) ? "todo dia" : r.days.map((on, i) => (on ? DAYS[i] : "")).filter(Boolean).join(" ")}</small></span></div>`).join("")}
      </details>` : ""}
      <div id="rtExact"></div>
    </section>`;
    if (editing) h += editorHTML();
    root().innerHTML = h;
    drawSleepChart();
    bind();
    bedHint();
  }

  function editorHTML() {
    const r = editing;
    const days = r.days || Array(7).fill(true);
    return `<section class="card sp-editor" id="rtEditor"><h4>${r.id ? "Editar" : "Novo"} item</h4>
      <form id="rtForm" class="sp-form">
        <div class="sp-2"><input name="title" placeholder="O quê (ex.: Treino)" value="${esc(r.title || "")}" required>
          <input name="time" type="time" value="${r.time || "08:00"}" required></div>
        <div class="sp-2"><input name="icon" placeholder="Emoji (opcional)" value="${esc(r.icon || "")}" maxlength="4">
          <label class="tr-toggle"><input type="checkbox" name="remind" ${r.remind ? "checked" : ""}> Lembrete 🔔</label></div>
        <div class="rt-days" id="rtFormDays">${DAYS.map((d, i) => `<button type="button" class="${days[i] ? "on" : ""}" data-i="${i}">${d}</button>`).join("")}</div>
        <div class="row-btns">
          ${r.id ? `<button type="button" class="btn ghost danger" id="rtDel">Apagar</button>` : ""}
          <button type="button" class="btn ghost" id="rtCancel">Cancelar</button><button class="btn" type="submit">Salvar</button>
        </div></form></section>`;
  }

  function bedHint() {
    const t = $("#rtAlarmTime")?.value, goal = st.sleep.goal;
    if (!t) return;
    $("#rtBed").textContent = `Pra dormir ${fmtH(goal)}, deite por volta de ${fromMin(toMin(t) - goal * 60 - 15)} (contando ~15 min pra pegar no sono).`;
  }

  function drawSleepChart() {
    const box = $("#rtChart"), s = st.sleep, nights = s.nights;
    if (!nights.some((n) => n.hours)) { box.innerHTML = `<div class="chart-empty">As últimas 2 semanas aparecem aqui.</div>`; return; }
    const W = box.clientWidth || 340, H = 140, L = 26, R = 6, T = 12, B = 20;
    const max = Math.max(10, ...nights.map((n) => n.hours || 0));
    const bw = (W - L - R) / nights.length;
    const Y = (v) => T + (1 - v / max) * (H - T - B);
    let g = "";
    for (const v of [0, 4, 8]) g += `<line class="grid" x1="${L}" x2="${W - R}" y1="${Y(v)}" y2="${Y(v)}"/><text class="axis" x="${L - 5}" y="${Y(v) + 3}" text-anchor="end">${v}h</text>`;
    g += `<line class="goal" x1="${L}" x2="${W - R}" y1="${Y(s.goal)}" y2="${Y(s.goal)}"/>`;
    nights.forEach((n, i) => {
      const x = L + i * bw + 1, w = Math.max(2, bw - 2);  // 2px de respiro entre barras
      if (n.hours) {
        const y = Y(n.hours), hgt = H - B - y, r = Math.min(4, w / 2);
        g += `<path class="sbar ${n.hours < s.goal - 0.5 ? "low" : ""}" d="M${x},${H - B} V${y + r} q0,-${r} ${r},-${r} H${x + w - r} q${r},0 ${r},${r} V${H - B} Z"/>`;
      }
      if (i % 2 === 1 || i === nights.length - 1) g += `<text class="axis" x="${x + w / 2}" y="${H - 6}" text-anchor="middle">${n.date.slice(8)}</text>`;
      g += `<rect class="hit" x="${L + i * bw}" y="${T}" width="${bw}" height="${H - T - B}" data-i="${i}"/>`;
    });
    box.innerHTML = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="Horas de sono por noite">${g}</svg><div class="rt-tip muted small" id="rtTip">Toque numa barra · linha tracejada = meta</div>`;
    box.querySelectorAll(".hit").forEach((el) => {
      const show = () => {
        const n = nights[+el.dataset.i];
        $("#rtTip").innerHTML = n.hours
          ? `<b>${fmtH(n.hours)}</b> · ${new Date(n.date + "T12:00").toLocaleDateString("pt-BR", { weekday: "short", day: "numeric", month: "short" })} · ${n.bed}→${n.wake}${n.quality ? " " + FACES[n.quality - 1] : ""}`
          : `${n.date.slice(8)}/${n.date.slice(5, 7)}: sem registro`;
      };
      el.addEventListener("pointerdown", show);
      el.addEventListener("pointerenter", show);
    });
  }

  function bind() {
    const d = todayISO();
    root().querySelectorAll(".rt-faces button").forEach((b) => (b.onclick = () => {
      quality = +b.dataset.q;
      root().querySelectorAll(".rt-faces button").forEach((x) => x.classList.toggle("on", x === b));
    }));
    $("#rtSleep").onsubmit = async (e) => {
      e.preventDefault();
      const f = e.target;
      st = { ...st, sleep: await api(`/api/sleep/${d}`, { method: "PUT", body: JSON.stringify({ bed: f.elements.bed.value, wake: f.elements.wake.value, quality }) }) };
      render();
      toast(`Sono registrado: ${fmtH(st.sleep.today.hours)}`);
    };
    $("#rtGoal").onchange = async (e) => { st = { ...st, sleep: await api("/api/sleep-goal", { method: "PUT", body: JSON.stringify({ goal: +e.target.value }) }) }; render(); };
    $("#rtAlarmTime").oninput = bedHint;
    $("#rtAlarmDays").querySelectorAll("button").forEach((b) => (b.onclick = () => b.classList.toggle("on")));
    $("#rtSetAlarm").onclick = () => {
      const days = [...$("#rtAlarmDays").querySelectorAll("button")].map((b) => b.classList.contains("on"));
      setAlarm($("#rtAlarmTime").value, days);
    };
    $("#rtShowAlarms").onclick = () => (hasPlugin("MomoAlarm") ? P().MomoAlarm.showAlarms() : toast(native() ? OLD_APK : "Só no celular"));
    $("#rtNew").onclick = () => { editing = { time: nextHour(), days: Array(7).fill(true) }; render(); scrollTo("#rtEditor"); };
    root().querySelectorAll(".rt-row").forEach((row) => (row.onclick = (e) => {
      if (row.dataset.kind === "supp") return switchView("viewSupps");
      if (e.target.closest(".rt-bell")) return;
      editing = { ...st.all.find((r) => r.id === row.dataset.id) };
      render();
      scrollTo("#rtEditor");
    }));
    root().querySelectorAll(".rt-bell").forEach((b) => (b.onclick = async () => {
      const r = st.all.find((x) => x.id === b.closest(".rt-row").dataset.id);
      if (!r.remind && !(await askNotify())) return;
      post(`/api/routine?date=${d}`, { ...r, remind: !r.remind });
    }));
    const f = $("#rtForm");
    if (f) {
      $("#rtFormDays").querySelectorAll("button").forEach((b) => (b.onclick = () => b.classList.toggle("on")));
      f.onsubmit = async (e) => {
        e.preventDefault();
        const days = [...$("#rtFormDays").querySelectorAll("button")].map((b) => b.classList.contains("on"));
        if (!days.some(Boolean)) return toast("Escolhe pelo menos um dia");
        const remind = f.elements.remind.checked;
        if (remind && !(await askNotify())) return;
        const body = { id: editing.id, title: f.elements.title.value.trim(), time: f.elements.time.value, icon: f.elements.icon.value.trim(), days, remind };
        editing = null;
        await post(`/api/routine?date=${d}`, body);
      };
      $("#rtCancel").onclick = () => { editing = null; render(); };
      $("#rtDel")?.addEventListener("click", async () => { const id = editing.id; editing = null; await post(`/api/routine/${id}?date=${d}`, null, "DELETE"); });
    }
    exactHint();
  }

  function nextHour() { const n = new Date(); return fromMin((n.getHours() + 1) * 60); }
  function scrollTo(sel) { requestAnimationFrame(() => $(sel)?.scrollIntoView({ behavior: "smooth", block: "start" })); }

  async function setAlarm(time, days) {
    if (!time) return toast("Escolhe o horário");
    await api(`/api/alarm?date=${todayISO()}`, { method: "PUT", body: JSON.stringify({ time, days, pending: false }) });
    if (!hasPlugin("MomoAlarm")) { toast(native() ? OLD_APK : "O despertador é criado no Relógio do celular (só no app)"); return show(); }
    const [hour, minute] = time.split(":").map(Number);
    try {
      await P().MomoAlarm.setAlarm({ hour, minute, message: "Momo · bom dia ☀️", days: days.map((on, i) => (on ? androidDay(i) : null)).filter(Boolean) });
      toast(`⏰ Despertador ${time} criado no Relógio`);
    } catch (e) { toast("Não deu: " + e.message); }
    show();
  }

  /* ---------- lembretes (notificações agendadas, repetem toda semana) ---------- */

  async function askNotify() {
    if (!native()) { toast("Lembretes funcionam no app do celular"); return true; }
    if (!hasPlugin("LocalNotifications")) { toast(OLD_APK); return false; }
    const LN = P().LocalNotifications;
    const r = await LN.requestPermissions();
    if (r.display !== "granted") { toast("Sem permissão de notificação: libere nas configurações do celular"); return false; }
    return true;
  }

  async function exactHint() {
    const box = $("#rtExact");
    if (!box || !hasPlugin("LocalNotifications") || !st.all.some((r) => r.remind)) return;
    try {
      const r = await P().LocalNotifications.checkExactNotificationSetting();
      if (r.exact_alarm === "granted") return;
      box.innerHTML = `<button class="btn ghost sm wide">⚙️ Lembretes no minuto exato: ativar "Alarmes e lembretes"</button>`;
      box.querySelector("button").onclick = () => P().LocalNotifications.changeExactNotificationSetting();
    } catch { /* Android antigo: não precisa */ }
  }

  let syncing = false;
  async function syncReminders(state) {
    if (!hasPlugin("LocalNotifications") || syncing) return;
    syncing = true;
    try {
      const LN = P().LocalNotifications;
      const s = state || st || (await api(`/api/routine?date=${todayISO()}`));
      const pend = await LN.getPending();
      if (pend.notifications.length) await LN.cancel({ notifications: pend.notifications.map((n) => ({ id: n.id })) });
      const list = [];
      let id = 1000;
      for (const r of s.all.filter((x) => x.remind)) {
        const [hour, minute] = r.time.split(":").map(Number);
        r.days.forEach((on, i) => {
          if (on) list.push({ id: id++, title: `${r.icon || "🗓️"} ${r.title}`, body: `Agora: ${r.title} (${r.time})`,
            schedule: { on: { weekday: androidDay(i), hour, minute }, allowWhileIdle: true } });
        });
      }
      if (localStorage.getItem("momo.suppRemind") !== "0") {
        for (const sl of s.slots.filter((x) => x.time && x.used)) {
          const [hour, minute] = sl.time.split(":").map(Number);
          list.push({ id: id++, title: `💊 Suplementos · ${sl.label}`, body: "Hora de tomar os suplementos", schedule: { on: { hour, minute }, allowWhileIdle: true } });
        }
      }
      if (list.length) await LN.schedule({ notifications: list });
    } catch (e) { console.warn("lembretes:", e); } finally { syncing = false; }
  }

  window.Rotina = {
    show,
    sync: () => api(`/api/routine?date=${todayISO()}`).then(syncReminders).catch(() => {}),
    setAlarmFromChat: async () => { const s = await api(`/api/routine?date=${todayISO()}`); if (s.alarm) setAlarm(s.alarm.time, s.alarm.days); },
  };
})();
