window.MOMO_BUILD = {"version": "2026.10.12.1819", "updates": "https://raw.githubusercontent.com/victorguima12/momo-fit/main"};
